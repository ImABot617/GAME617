import React, { useEffect, useRef, useState } from 'react';
import { CONFIG, WEAPONS, WeaponType, MapKey, MAPS, Platform } from './types';
import { Player, Enemy, AIManager } from './entities';
import { db, auth } from '../firebase';
import { doc, setDoc, onSnapshot, getDoc, updateDoc } from 'firebase/firestore';

interface GameEngineProps {
  mapKey: MapKey;
  p1Weapon: WeaponType;
  p2Weapon: WeaponType;
  multiplayer: { active: boolean; roomId: string | null; role: 'p1' | 'p2' | null };
  onExit: () => void;
}

export const GameEngine: React.FC<GameEngineProps> = ({ mapKey, p1Weapon, p2Weapon, multiplayer, onExit }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameState, setGameState] = useState<'PLAYING' | 'MENU'>('PLAYING');
  const [p1Score, setP1Score] = useState(0);
  const [p2Score, setP2Score] = useState(0);
  const [wave, setWave] = useState(1);
  const [zombieCount, setZombieCount] = useState(0);
  const [aiGen, setAiGen] = useState(1);
  const [aliveBots, setAliveBots] = useState(0);
  const [topFitness, setTopFitness] = useState(0);

  const playersRef = useRef<Player[]>([]);
  const enemiesRef = useRef<Enemy[]>([]);
  const bulletsRef = useRef<any[]>([]);
  const shockwavesRef = useRef<any[]>([]);
  const particlesRef = useRef<any[]>([]);
  const platformsRef = useRef<Platform[]>([]);
  const aiManagerRef = useRef(new AIManager());
  const keysRef = useRef<Record<string, boolean>>({});
  const screenShakeRef = useRef(0);
  const waveCooldownRef = useRef(0);
  const camerasRef = useRef([{ x: 0, y: 0 }, { x: 0, y: 0 }]);

  const appId = 'combat-duo-app';

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      keysRef.current[e.code] = true;
      if (e.code === 'Escape') onExit();
    };
    const handleKeyUp = (e: KeyboardEvent) => keysRef.current[e.code] = false;
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [onExit]);

  useEffect(() => {
    const initGame = async () => {
      const map = MAPS[mapKey];
      platformsRef.current = map.platforms.map(p => ({ ...p, broken: false, startBreaking: false, breakTimer: 60 }));
      
      if (map.isPractice) {
        if (auth.currentUser) await aiManagerRef.current.load(auth.currentUser.uid);
        playersRef.current = [new Player('p1', '#3b82f6')];
        playersRef.current[0].weapon = p1Weapon;
        for (let i = 0; i < aiManagerRef.current.popSize; i++) {
          let b = new Player(`bot${i}`, `hsl(${280 + i * 8}, 80%, 60%)`);
          b.weapon = 'SWORD';
          playersRef.current.push(b);
        }
        playersRef.current[0].reset(100, 400, 1, mapKey);
        for (let i = 1; i <= aiManagerRef.current.popSize; i++) {
          playersRef.current[i].reset(map.width - 100 - (Math.random() * 300), 400, -1, mapKey);
        }
      } else if (map.isVsBest) {
        if (auth.currentUser) await aiManagerRef.current.load(auth.currentUser.uid);
        playersRef.current = [new Player('p1', '#3b82f6'), new Player('botBest', '#f97316')];
        playersRef.current[0].weapon = p1Weapon;
        playersRef.current[1].weapon = p2Weapon;
        playersRef.current[0].reset(100, 400, 1, mapKey);
        playersRef.current[1].reset(map.width - 100, 400, -1, mapKey);
      } else {
        playersRef.current = [new Player('p1', '#3b82f6'), new Player('p2', '#f43f5e')];
        playersRef.current[0].weapon = p1Weapon;
        playersRef.current[1].weapon = p2Weapon;
        playersRef.current[0].reset(map.isGraveyard ? 2450 : 100, 400, 1, mapKey);
        playersRef.current[1].reset(map.isGraveyard ? 2550 : map.width - 100, 400, -1, mapKey);
      }

      if (map.isGraveyard) spawnWave(1);
    };

    initGame();
  }, [mapKey, p1Weapon, p2Weapon]);

  const spawnWave = (w: number) => {
    const count = 5 + (w - 1) * 5;
    const map = MAPS[mapKey];
    for (let i = 0; i < count; i++) {
      const spawnX = (i % 2 === 0) ? 50 : map.width - 100;
      const types = ['NORMAL', 'NORMAL', 'BUFF', 'RANGED', 'NORMAL', 'ANIMAL'];
      enemiesRef.current.push(new Enemy(types[i % types.length], spawnX, 100));
    }
    setZombieCount(enemiesRef.current.length);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;

    const loop = () => {
      update();
      draw(ctx);
      animationFrameId = requestAnimationFrame(loop);
    };

    const update = () => {
      const map = MAPS[mapKey];
      const p1Controls = { up: 'KeyW', left: 'KeyA', right: 'KeyD', down: 'KeyS', dash: 'Space', sword: 'KeyE', ranged: 'KeyQ', block: 'ShiftLeft' };
      const p2Controls = { up: 'KeyO', left: 'KeyK', right: 'Semicolon', down: 'KeyL', dash: 'KeyN', sword: 'KeyI', ranged: 'KeyP', block: 'ShiftRight' };

      // Input handling
      let p1Inputs = {
        up: keysRef.current[p1Controls.up],
        left: keysRef.current[p1Controls.left],
        right: keysRef.current[p1Controls.right],
        down: keysRef.current[p1Controls.down],
        dash: keysRef.current[p1Controls.dash],
        sword: keysRef.current[p1Controls.sword],
        ranged: keysRef.current[p1Controls.ranged],
        block: keysRef.current[p1Controls.block]
      };

      if (map.isPractice) {
        playersRef.current[0].update(platformsRef.current, playersRef.current, p1Inputs);
        let botsAlive = 0;
        for (let i = 1; i < playersRef.current.length; i++) {
          const bot = playersRef.current[i];
          if (bot.hp > 0) {
            botsAlive++;
            const botInputs = aiManagerRef.current.predict(playersRef.current[0], bot, i - 1);
            bot.update(platformsRef.current, playersRef.current, botInputs);
          }
        }
        setAliveBots(botsAlive);
        if (botsAlive === 0 || playersRef.current[0].hp <= 0) {
          if (auth.currentUser) aiManagerRef.current.evolve(playersRef.current.slice(1).map(b => b.botFitness), auth.currentUser.uid);
          setAiGen(aiManagerRef.current.generation);
          playersRef.current[0].reset(100, 400, 1, mapKey);
          for (let i = 1; i < playersRef.current.length; i++) {
            playersRef.current[i].reset(map.width - 100 - (Math.random() * 300), 400, -1, mapKey);
          }
        }
      } else {
        // Standard 1v1 or Graveyard logic
        playersRef.current[0].update(platformsRef.current, playersRef.current, p1Inputs);
        if (playersRef.current[1]) {
           let p2Inputs = {
            up: keysRef.current[p2Controls.up],
            left: keysRef.current[p2Controls.left],
            right: keysRef.current[p2Controls.right],
            down: keysRef.current[p2Controls.down],
            dash: keysRef.current[p2Controls.dash],
            sword: keysRef.current[p2Controls.sword],
            ranged: keysRef.current[p2Controls.ranged],
            block: keysRef.current[p2Controls.block]
          };
          playersRef.current[1].update(platformsRef.current, playersRef.current, p2Inputs);
        }
      }

      // Enemy logic
      enemiesRef.current.forEach(en => en.update(playersRef.current, platformsRef.current));
      enemiesRef.current = enemiesRef.current.filter(en => en.hp > 0);
      setZombieCount(enemiesRef.current.length);

      // Camera logic
      const vw = canvas.width;
      camerasRef.current[0].x += (playersRef.current[0].x - vw / 2 - camerasRef.current[0].x) * 0.1;
      camerasRef.current[0].x = Math.max(0, Math.min(camerasRef.current[0].x, map.width - vw));
    };

    const draw = (ctx: CanvasRenderingContext2D) => {
      const map = MAPS[mapKey];
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      ctx.fillStyle = map.isMansion ? '#1a0505' : '#020617';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.save();
      ctx.translate(-camerasRef.current[0].x, -camerasRef.current[0].y);
      platformsRef.current.forEach(p => {
        if (!p.broken) {
          ctx.fillStyle = p.color;
          ctx.fillRect(p.x, p.y, p.w, p.h);
        }
      });
      playersRef.current.forEach(p => p.draw(ctx));
      enemiesRef.current.forEach(e => e.draw(ctx));
      ctx.restore();
    };

    loop();
    return () => cancelAnimationFrame(animationFrameId);
  }, [mapKey]);

  return (
    <div className="relative w-full h-full">
      <canvas ref={canvasRef} className="w-full h-full" />
      
      {/* UI Overlays */}
      <div className="absolute top-6 left-6 pointer-events-none text-white z-10 w-full pr-12">
        <div className="flex justify-between items-start">
          <div className="flex gap-8">
            <div>
              <div className="text-[10px] uppercase text-blue-400 font-bold">P1 (BLUE)</div>
              <div className="w-32 h-2 bg-white/10 rounded-full mt-1 overflow-hidden">
                <div className="h-full bg-blue-500 transition-all" style={{ width: `${(playersRef.current[0]?.hp / CONFIG.maxHP) * 100}%` }}></div>
              </div>
            </div>
            {playersRef.current[1] && !MAPS[mapKey].isPractice && (
              <div>
                <div className="text-[10px] uppercase text-rose-400 font-bold">P2 (RED)</div>
                <div className="w-32 h-2 bg-white/10 rounded-full mt-1 overflow-hidden">
                  <div className="h-full bg-rose-500 transition-all" style={{ width: `${(playersRef.current[1]?.hp / CONFIG.maxHP) * 100}%` }}></div>
                </div>
              </div>
            )}
          </div>

          {MAPS[mapKey].isPractice && (
            <div className="text-center bg-purple-900/60 px-6 py-2 rounded-xl border border-purple-500/30">
              <div className="text-xs text-purple-300 tracking-widest uppercase font-bold">AI Generation {aiGen}</div>
              <div className="text-sm font-bold text-white">Alive Bots: {aliveBots}/10</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
