import { CONFIG, WEAPONS, WeaponType, MapKey, MAPS } from './types';
import { db } from '../firebase';
import { doc, setDoc, getDoc } from 'firebase/firestore';

export class Enemy {
  type: string; x: number; y: number; vx: number; vy: number;
  hp: number; maxHP: number; w: number; h: number; speed: number;
  color: string; isRanged: boolean; shootCooldown: number; facing: number;

  constructor(type: string, x: number, y: number) {
    this.type = type; this.x = x; this.y = y; this.vx = 0; this.vy = 0;
    this.hp = 6; this.maxHP = 6; this.w = 32; this.h = 32; this.speed = 1.2;
    this.color = '#10b981'; this.isRanged = false; this.shootCooldown = 0; this.facing = 1;
    if (type === 'BUFF') { this.hp = 12; this.maxHP = 12; this.speed = 0.8; this.w = 48; this.h = 48; this.color = '#064e3b'; }
    else if (type === 'RANGED') { this.isRanged = true; this.color = '#8b5cf6'; }
    else if (type === 'ANIMAL') { this.speed = 2.5; this.w = 24; this.h = 24; this.color = '#78350f'; }
  }

  update(players: Player[], platforms: any[]) {
    const alivePlayers = players.filter(p => p.hp > 0);
    if (alivePlayers.length === 0) return;
    const closestPlayer = alivePlayers.reduce((prev, curr) => Math.abs(prev.x - this.x) < Math.abs(curr.x - this.x) ? prev : curr);
    const dist = Math.abs(closestPlayer.x - this.x);
    this.facing = closestPlayer.x > this.x ? 1 : -1;
    if (this.isRanged && dist < 400) { this.vx *= 0.8; if (this.shootCooldown <= 0) this.shoot(closestPlayer); }
    else { this.vx = this.facing * this.speed; }
    if (this.shootCooldown > 0) this.shootCooldown--;
    this.vy += CONFIG.gravity; this.x += this.vx; this.y += this.vy;
    platforms.forEach(p => {
      let prevBottom = (this.y - this.vy) + this.h;
      if (this.x < p.x + p.w && this.x + this.w > p.x && this.y + this.h > p.y && this.y < p.y + p.h && this.vy > 0 && prevBottom <= p.y + Math.max(10, this.vy + 5)) {
        this.y = p.y - this.h; this.vy = 0;
      }
    });
    if (dist < 30 && Math.abs(closestPlayer.y - this.y) < 30) closestPlayer.hp = Math.max(0, closestPlayer.hp - 0.05);
  }

  shoot(target: Player) {
    // Bullets are handled by the main loop
  }

  draw(ctx: CanvasRenderingContext2D) {
    ctx.fillStyle = this.color; ctx.beginPath(); ctx.roundRect(this.x, this.y, this.w, this.h, 4); ctx.fill();
    ctx.fillStyle = '#ef4444'; ctx.fillRect(this.facing === 1 ? this.x + this.w - 10 : this.x + 4, this.y + 6, 6, 6);
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(this.x, this.y - 10, this.w, 4);
    ctx.fillStyle = '#ef4444'; ctx.fillRect(this.x, this.y - 10, (this.hp / this.maxHP) * this.w, 4);
  }
}

export class Player {
  id: string; color: string; w: number; h: number; lives: number;
  weapon: WeaponType = 'SWORD'; x: number = 0; y: number = 0; vx: number = 0; vy: number = 0;
  facing: number = 1; grounded: boolean = false; dashCooldown: number = 0; isDashing: boolean = false;
  hp: number = CONFIG.maxHP; shieldDurability: number = CONFIG.shieldDurability;
  shieldCD: number = 0; isShieldBroken: boolean = false; isAttacking: boolean = false;
  isPlunging: boolean = false; hasHit: boolean = false; attackTimer: number = 0; isBlocking: boolean = false;
  plungeCooldown: number = 0; plungeStartY: number = 0; jumps: number = 0; prevUp: boolean = false;
  shotsFired: number = 0; remoteShotsFired: number = 0; shockwavesFired: number = 0;
  remoteShockwavesFired: number = 0; rangedCooldown: number = 0; botFitness: number = 0;
  jumpHoldTimer: number = 0; spawnX: number = 0; spawnY: number = 0; spawnFacing: number = 1;

  constructor(id: string, color: string) {
    this.id = id; this.color = color; this.w = 32; this.h = 32; this.lives = 0;
  }

  reset(x?: number, y?: number, facing?: number, mapKey?: MapKey) {
    this.x = x ?? this.spawnX; this.y = y ?? this.spawnY; this.facing = facing ?? this.spawnFacing;
    if (x !== undefined) this.spawnX = x; if (y !== undefined) this.spawnY = y; if (facing !== undefined) this.spawnFacing = facing;
    this.vx = 0; this.vy = 0; this.grounded = false; this.dashCooldown = 0; this.isDashing = false;
    this.hp = CONFIG.maxHP; this.shieldDurability = CONFIG.shieldDurability; this.shieldCD = 0;
    this.isShieldBroken = false; this.isAttacking = false; this.isPlunging = false; this.hasHit = false;
    this.attackTimer = 0; this.isBlocking = false; this.plungeCooldown = 0; this.plungeStartY = this.y;
    this.jumps = 0; this.prevUp = false; this.shotsFired = 0; this.remoteShotsFired = 0;
    this.shockwavesFired = 0; this.remoteShockwavesFired = 0; this.rangedCooldown = 0; this.botFitness = 0;
    if (mapKey && MAPS[mapKey].isGraveyard) this.lives = CONFIG.graveyardLives;
  }

  // Update logic will be in the main loop for better state management
  draw(ctx: CanvasRenderingContext2D) {
    if (this.hp <= 0) return;
    ctx.save();
    const hpWidth = 40; const hpHeight = 6;
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(this.x + this.w/2 - hpWidth/2, this.y - 15, hpWidth, hpHeight);
    ctx.fillStyle = this.color; ctx.fillRect(this.x + this.w/2 - hpWidth/2, this.y - 15, (Math.max(0, this.hp)/CONFIG.maxHP) * hpWidth, hpHeight);
    if (this.isBlocking || this.isShieldBroken) {
      ctx.globalAlpha = this.isShieldBroken ? 0.3 : 0.6; ctx.strokeStyle = this.isShieldBroken ? '#ef4444' : 'white';
      ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(this.x + this.w/2, this.y + this.h/2, this.w * 0.9, 0, Math.PI*2); ctx.stroke();
    }
    ctx.fillStyle = this.isDashing ? '#fff' : this.color; ctx.beginPath(); ctx.roundRect(this.x, this.y, this.w, this.h, 6); ctx.fill();
    ctx.fillStyle = 'white'; ctx.fillRect(this.facing === 1 ? this.x + 20 : this.x + 4, this.y + 6, 8, 8);
    ctx.restore();
  }
}

export class AIManager {
  popSize = 10; numWeights = 88; genomes: number[][] = []; generation = 1; bestWeights: number[] | null = null;
  appId = 'combat-duo-app';

  init(savedWeights?: number[]) {
    this.genomes = [];
    for (let i = 0; i < this.popSize; i++) {
      if (savedWeights && i === 0) this.genomes.push([...savedWeights]);
      else if (savedWeights && i < 5) this.genomes.push(this.mutate([...savedWeights], 0.2));
      else this.genomes.push(Array.from({length: this.numWeights}, () => (Math.random() - 0.5) * 2));
    }
  }

  predict(closestOpponent: Player, bot: Player, gIndex: number | 'best') {
    const inputs = [
      (closestOpponent.x - bot.x) / 1000, (closestOpponent.y - bot.y) / 1000,
      closestOpponent.vx / 15, closestOpponent.vy / 15, bot.vx / 15, bot.vy / 15,
      closestOpponent.isAttacking ? 1 : 0, bot.dashCooldown <= 0 ? 1 : 0,
      bot.attackTimer <= 0 ? 1 : 0, bot.facing, 1.0
    ];
    const w = gIndex === 'best' ? (this.bestWeights || this.genomes[0]) : this.genomes[gIndex];
    if (!w) return { up: false, left: false, right: false, down: false, dash: false, sword: false, ranged: false, block: false };
    const outs = [];
    for (let o = 0; o < 8; o++) {
      let sum = 0; for (let i = 0; i < 11; i++) sum += inputs[i] * w[o * 11 + i];
      outs.push(sum > 0);
    }
    return { up: outs[0], left: outs[1], right: outs[2], down: outs[3], dash: outs[4], sword: outs[5], ranged: outs[6], block: outs[7] };
  }

  evolve(fitnessScores: number[], userId: string) {
    let sorted = fitnessScores.map((val, idx) => ({val, idx})).sort((a,b) => b.val - a.val);
    let p1 = this.genomes[sorted[0].idx]; let p2 = this.genomes[sorted[1].idx];
    this.bestWeights = [...p1];
    let nextGen = [ [...p1], [...p2] ];
    for(let i=2; i<this.popSize; i++) nextGen.push(this.mutate(this.crossover(p1, p2), 0.15));
    this.genomes = nextGen;
    this.generation++; this.save(userId);
  }

  crossover(p1: number[], p2: number[]) { return p1.map((w, i) => Math.random() > 0.5 ? w : p2[i]); }
  mutate(genome: number[], rate: number) { return genome.map(w => Math.random() < rate ? w + (Math.random() - 0.5) * 0.5 : w); }

  async save(userId: string) {
    if(!this.bestWeights) return;
    try { await setDoc(doc(db, 'artifacts', this.appId, 'public', 'data', 'bot_ai', userId), { weights: this.bestWeights, generation: this.generation }); }
    catch(e) { console.error("Save AI error", e); }
  }

  async load(userId: string) {
    try {
      const snap = await getDoc(doc(db, 'artifacts', this.appId, 'public', 'data', 'bot_ai', userId));
      if(snap.exists()) { let d = snap.data(); this.generation = d.generation || 1; this.bestWeights = d.weights; this.init(d.weights); }
      else this.init();
    } catch(e) { this.init(); }
  }
}
