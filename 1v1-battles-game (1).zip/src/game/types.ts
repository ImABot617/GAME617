export const CONFIG = {
  gravity: 0.8,
  friction: 0.85,
  jumpForce: -13,
  jumpHoldExtra: -0.7,
  maxJumpHold: 10,
  moveSpeed: 1.6,
  maxSpeed: 11,
  dashPower: 28,
  dashCooldown: 50,
  playerSize: 32,
  bulletSpeed: 12,
  fireRate: 30,
  boatFireRate: 100,
  maxHP: 10,
  rangedDamage: 1,
  shockwaveDamage: 2,
  shieldDurability: 3,
  shieldCooldown: 240,
  plungeSpeed: 22,
  shockwaveMaxRadius: 120,
  graveyardLives: 3,
  winScore: 7
};

export type WeaponType = 'SWORD' | 'MACE' | 'HAMMER' | 'SPEAR';

export const WEAPONS = {
  SWORD: { dmg: 2, crit: 3, plunge: 4, range: 40, kb: 1, shieldBreak: false, maxJumps: 2, cooldown: 18, plungeCooldown: 45 },
  MACE: { dmg: 3, crit: 4, plunge: 5, range: 40, kb: 1, shieldBreak: true, maxJumps: 3, cooldown: 35, plungeCooldown: 80 },
  HAMMER: { dmg: 2, crit: 3, plunge: 4, range: 40, kb: 6, shieldBreak: false, maxJumps: 2, cooldown: 25, plungeCooldown: 55 },
  SPEAR: { dmg: 1.5, crit: 2, plunge: 3, range: 85, kb: 0.8, shieldBreak: false, maxJumps: 2, cooldown: 20, plungeCooldown: 45 }
};

export type MapKey = 'BASIC' | 'STANDARD' | 'MANSION' | 'GRAVEYARD' | 'PRACTICE' | 'VS_BEST';

export interface Platform {
  x: number;
  y: number;
  w: number;
  h: number;
  color: string;
  breakable?: boolean;
  portal?: boolean;
  broken?: boolean;
  startBreaking?: boolean;
  breakTimer?: number;
}

export const MAPS: Record<MapKey, { width: number; height: number; hasBoat?: boolean; isMansion?: boolean; isGraveyard?: boolean; isPractice?: boolean; isVsBest?: boolean; platforms: Platform[] }> = {
  'BASIC': { width: 2000, height: 800, platforms: [{ x: 0, y: 760, w: 2000, h: 40, color: '#1e293b' }] },
  'STANDARD': {
    width: 4000, height: 800, hasBoat: true, platforms: [
      { x: 0, y: 760, w: 4000, h: 40, color: '#1e293b' },
      { x: 200, y: 600, w: 300, h: 20, color: '#38bdf8' },
      { x: 1000, y: 550, w: 400, h: 20, color: '#38bdf8' }
    ]
  },
  'MANSION': {
    width: 3000, height: 800, isMansion: true, platforms: [
      { x: 0, y: 760, w: 3000, h: 40, color: '#2d0a0a' },
      { x: 200, y: 600, w: 200, h: 20, color: '#4c1d95', breakable: true, breakTimer: 60 },
      { x: 2700, y: 500, w: 100, h: 100, color: '#fbbf24', portal: true }
    ]
  },
  'GRAVEYARD': {
    width: 5000, height: 800, isGraveyard: true, platforms: [
      { x: 0, y: 760, w: 5000, h: 40, color: '#064e3b' },
      { x: 2300, y: 550, w: 400, h: 20, color: '#1e293b' },
      { x: 1800, y: 400, w: 300, h: 20, color: '#1e293b' },
      { x: 2900, y: 400, w: 300, h: 20, color: '#1e293b' }
    ]
  },
  'PRACTICE': {
    width: 2500, height: 800, isPractice: true, platforms: [
      { x: 0, y: 760, w: 2500, h: 40, color: '#1e293b' },
      { x: 500, y: 550, w: 1500, h: 20, color: '#4c1d95' }
    ]
  },
  'VS_BEST': {
    width: 2000, height: 800, isVsBest: true, platforms: [
      { x: 0, y: 760, w: 2000, h: 40, color: '#1e293b' },
      { x: 850, y: 500, w: 300, h: 20, color: '#f97316' }
    ]
  }
};
