import React, { useState, useEffect } from 'react';
import { MapKey, WeaponType, MAPS } from './game/types';
import { GameEngine } from './game/GameEngine';
import { auth, db } from './firebase';
import { signInAnonymously, onAuthStateChanged } from 'firebase/auth';
import { doc, setDoc, getDoc, onSnapshot, updateDoc } from 'firebase/firestore';

export default function App() {
  const [gameState, setGameState] = useState<'MENU' | 'PLAYING'>('MENU');
  const [selectedMap, setSelectedMap] = useState<MapKey>('STANDARD');
  const [p1Weapon, setP1Weapon] = useState<WeaponType>('SWORD');
  const [p2Weapon, setP2Weapon] = useState<WeaponType>('SWORD');
  const [roomId, setRoomId] = useState('');
  const [multiplayer, setMultiplayer] = useState<{ active: boolean; roomId: string | null; role: 'p1' | 'p2' | null }>({
    active: false,
    roomId: null,
    role: null
  });

  useEffect(() => {
    signInAnonymously(auth).catch(console.error);
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) console.log('Authenticated as', user.uid);
    });
    return () => unsubscribe();
  }, []);

  const handleJoinServer = async () => {
    if (!roomId.trim() || !auth.currentUser) return;
    const rid = roomId.trim();
    const appId = 'combat-duo-app';
    const roomRef = doc(db, 'artifacts', appId, 'public', 'data', 'rooms', rid);
    
    const snap = await getDoc(roomRef);
    if (!snap.exists()) {
      setMultiplayer({ active: true, roomId: rid, role: 'p1' });
      await setDoc(roomRef, { map: selectedMap, status: 'lobby', p1: auth.currentUser.uid, p1Score: 0, p2Score: 0 });
      alert("Waiting for P2...");
    } else {
      setMultiplayer({ active: true, roomId: rid, role: 'p2' });
      await updateDoc(roomRef, { p2: auth.currentUser.uid, status: 'playing' });
      setGameState('PLAYING');
    }
  };

  if (gameState === 'PLAYING') {
    return (
      <GameEngine 
        mapKey={selectedMap} 
        p1Weapon={p1Weapon} 
        p2Weapon={p2Weapon} 
        multiplayer={multiplayer}
        onExit={() => setGameState('MENU')}
      />
    );
  }

  return (
    <div id="main-menu" className="menu-screen p-8 overflow-y-auto">
      <h1 className="text-5xl md:text-7xl font-black mb-2 tracking-tighter italic text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">
        1v1 BATTLES GAME
      </h1>
      
      <div className="flex gap-4 mb-8 bg-slate-900/80 p-2 rounded-2xl border border-white/10">
        <input 
          value={roomId}
          onChange={(e) => setRoomId(e.target.value)}
          type="text" 
          placeholder="Enter Room ID..." 
          className="bg-transparent px-4 py-2 outline-none text-blue-400 font-bold w-40"
        />
        <button 
          onClick={handleJoinServer}
          className="bg-blue-600 hover:bg-blue-500 px-6 py-2 rounded-xl font-bold transition-colors"
        >
          Join Server
        </button>
      </div>

      <p className="text-blue-400 mb-2 uppercase tracking-widest text-sm font-bold">Select Mode</p>
      
      <div id="map-selection" className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6 max-w-6xl">
        {(Object.keys(MAPS) as MapKey[]).map((key) => (
          <div 
            key={key}
            className={`map-card p-4 rounded-xl bg-slate-800/50 ${selectedMap === key ? 'selected' : ''}`} 
            onClick={() => setSelectedMap(key)}
          >
            <div className="font-bold text-lg">{key}</div>
            <div className="text-xs opacity-60">{MAPS[key].isPractice ? 'AI Swarm' : 'Duel Arena'}</div>
          </div>
        ))}
      </div>

      <div className="flex gap-12 mb-8 bg-slate-800/50 p-4 rounded-xl border border-white/10">
        <div className="flex flex-col items-center">
          <label className="text-[10px] text-blue-400 uppercase font-bold mb-1">P1 Weapon</label>
          <select value={p1Weapon} onChange={(e) => setP1Weapon(e.target.value as WeaponType)}>
            <option value="SWORD">Sword (Balanced)</option>
            <option value="HAMMER">Hammer (High Knockback)</option>
            <option value="MACE">Mace (Shield Break)</option>
            <option value="SPEAR">Spear (Long Range)</option>
          </select>
        </div>
        <div className="flex flex-col items-center">
          <label className="text-[10px] text-rose-400 uppercase font-bold mb-1">P2 Weapon</label>
          <select value={p2Weapon} onChange={(e) => setP2Weapon(e.target.value as WeaponType)}>
            <option value="SWORD">Sword (Balanced)</option>
            <option value="HAMMER">Hammer (High Knockback)</option>
            <option value="MACE">Mace (Shield Break)</option>
            <option value="SPEAR">Spear (Long Range)</option>
          </select>
        </div>
      </div>

      <button 
        onClick={() => setGameState('PLAYING')}
        className="px-16 py-4 bg-blue-600 hover:bg-blue-500 transition-all rounded-full font-bold text-xl shadow-lg shadow-blue-500/40"
      >
        START LOCAL GAME
      </button>

      <div className="mt-8 grid grid-cols-2 gap-8 text-[10px] opacity-60 uppercase tracking-widest font-bold max-w-2xl text-center">
        <div className="border-r border-white/20 pr-6">
          P1 (WASD): E-Attack | Q-Bow | Shift-Block | Space-Dash<br />
          <span className="text-blue-300 font-black">Wx2: DOUBLE JUMP | AIR+S+E: PLUNGE</span>
        </div>
        <div className="pl-6">
          P2 (OKL;): I-Attack | P-Bow | Shift-Block | N/M-Dash<br />
          <span className="text-rose-300 font-black">Ox2: DOUBLE JUMP | AIR+L+I: PLUNGE</span><br />
          <span className="text-gray-400">PRESS [ESC] TO QUIT MATCH</span>
        </div>
      </div>
    </div>
  );
}
