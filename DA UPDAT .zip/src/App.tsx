import React, { useEffect, useRef, useState } from 'react';
import { GameController } from './game/GameController';

interface Achievement {
  title: string;
  desc: string;
  unlocked: boolean;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [game, setGame] = useState<GameController | null>(null);
  const [achievements, setAchievements] = useState<Record<string, Achievement>>({
    first_blood: { title: "First Blood", desc: "The journey begins. Vanquish the Mecha Sentinel.", unlocked: false },
    hacker: { title: "Hacker", desc: "Find the hidden backdoor. Some rules are meant to be broken...", unlocked: false },
    ad_blocker: { title: "Ad Blocker", desc: "Survive the system override and dismiss the digital distraction.", unlocked: false },
    god_slayer: { title: "God Slayer", desc: "Delete the system's architect. Conquer The Admin's ultimate form.", unlocked: false },
    admins_vanguard: { title: "The Admin's Vanguard", desc: "Attain absolute perfection. Clear the entire simulation without a single scratch, relying only on your pure, un-altered skill.", unlocked: false },
    dumber_than_a_rock: { title: "Dumber Than a Rock", desc: "Get beaten to a pulp by the Ancient Golem.", unlocked: false },
    wall_hugger: { title: "Wall Hugger", desc: "Meet a crushing end by dying inside a spawned wall.", unlocked: false },
    spiked: { title: "Spiked", desc: "Impale yourself on the bamboo forest spikes.", unlocked: false },
    found_a_dollar: { title: "Spare Change", desc: "You found a hidden dollar bill in the Admin's server room. Don't spend it all in one place.", unlocked: false },
    true_god_slayer: { title: "True God Slayer", desc: "You achieved the impossible. Defeated the True Admin in Awakened mode.", unlocked: false }
  });
  const [act1Completions, setAct1Completions] = useState(0);
  const [showAchievements, setShowAchievements] = useState(false);
  const [achievPopup, setAchievPopup] = useState<{ title: string, desc: string } | null>(null);
  const [upgrades, setUpgrades] = useState<any[]>([]);
  const [gameState, setGameState] = useState('MENU');
  const [showHitboxes, setShowHitboxes] = useState(false);
  const [isShopOpen, setIsShopOpen] = useState(false);
  const [shards, setShards] = useState(0);
  const [currentSkin, setCurrentSkin] = useState('default');
  const [ownedSkins, setOwnedSkins] = useState(['default']);

  const keys = useRef<Record<string, boolean>>({ w: false, a: false, s: false, d: false, ' ': false });
  const mouse = useRef({ x: 0, y: 0, down: false, rightDown: false });

  const unlockAchievement = (id: string) => {
    setAchievements(prev => {
      if (prev[id] && !prev[id].unlocked) {
        const newAchievements = { ...prev, [id]: { ...prev[id], unlocked: true } };
        const toast = document.getElementById('toast');
        if (toast) {
          toast.innerText = "🏆 Achievement Unlocked: " + prev[id].title;
          toast.classList.remove('hidden');
          setTimeout(() => toast.classList.add('hidden'), 3000);
        }
        return newAchievements;
      }
      return prev;
    });
  };

  useEffect(() => {
    const newGame = new GameController(achievements, unlockAchievement, act1Completions);
    
    // Add a way for GameController to update React state
    (newGame as any).onStateChange = (state: string) => {
      setGameState(state);
      if (state === 'UPGRADE') {
        generateUpgrades();
      }
    };
    (newGame as any).onShardsChange = (amt: number) => {
      setShards(amt);
    };
    
    setGame(newGame);

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key.toLowerCase() === 'h' && newGame) {
        newGame.showHitboxes = !newGame.showHitboxes;
        (window as any).showHitboxes = newGame.showHitboxes;
        setShowHitboxes(newGame.showHitboxes);
        console.log("Hitboxes: " + newGame.showHitboxes);
      }
      if (newGame.dialogueActive && (e.key === ' ' || e.key === 'Enter')) {
        newGame.advanceDialogue();
      } else if (keys.current.hasOwnProperty(e.key.toLowerCase())) {
        keys.current[e.key.toLowerCase()] = true;
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (keys.current.hasOwnProperty(e.key.toLowerCase())) {
        keys.current[e.key.toLowerCase()] = false;
      }
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (!canvasRef.current) return;
      const rect = canvasRef.current.getBoundingClientRect();
      mouse.current.x = (e.clientX - rect.left) * (canvasRef.current.width / rect.width);
      mouse.current.y = (e.clientY - rect.top) * (canvasRef.current.height / rect.height);
    };

    const handleMouseDown = (e: MouseEvent) => {
      if (newGame.dialogueActive) {
        newGame.advanceDialogue();
        return;
      }
      if (e.button === 0) mouse.current.down = true;
      else if (e.button === 2) mouse.current.rightDown = true;
    };

    const handleMouseUp = (e: MouseEvent) => {
      if (e.button === 0) mouse.current.down = false;
      else if (e.button === 2) mouse.current.rightDown = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('contextmenu', e => e.preventDefault());

    let animationFrameId: number;
    const loop = (time: number) => {
      newGame.loop(time, keys.current, mouse.current);
      animationFrameId = requestAnimationFrame(loop);
    };
    animationFrameId = requestAnimationFrame(loop);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  const handleStart = () => {
    if (game) {
      if (game.state === 'WIN') {
        const newGame = new GameController(achievements, unlockAchievement, act1Completions);
        setGame(newGame);
        newGame.start();
      } else if (game.state === 'GAMEOVER') {
        game.restartCurrentRoom();
      } else {
        game.start();
      }
    }
  };

  const handleBonus = () => {
    if (game) {
      const newGame = new GameController(achievements, unlockAchievement, act1Completions);
      setGame(newGame);
      newGame.startBonusRoom();
    }
  };

  const handleSave = () => {
    const saveData = {
      achievements,
      stackBugEnabled: (window as any).stackBugEnabled,
      act1Completions
    };
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(saveData));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "aoe_boss_rush_save.json");
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  const handleLoad = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const loadedData = JSON.parse(event.target?.result as string);
        if (loadedData.achievements) {
          setAchievements(prev => {
            const next = { ...prev };
            for (let key in loadedData.achievements) {
              if (next[key] && loadedData.achievements[key].unlocked) {
                next[key].unlocked = true;
              }
            }
            return next;
          });
        }
        if (loadedData.stackBugEnabled) (window as any).stackBugEnabled = true;
        if (loadedData.act1Completions !== undefined) setAct1Completions(loadedData.act1Completions);
      } catch (err) {
        console.error(err);
      }
    };
    reader.readAsText(file);
  };

  const generateUpgrades = () => {
    const baseUpgrades = [
      { id: 'hp', title: '+ Max HP', desc: 'Increases Max HP by 50<br>and heals fully.' },
      { id: 'dmg', title: '+ Damage', desc: 'Increases attack<br>damage by 5.' },
      { id: 'spd', title: '+ Speed', desc: 'Increases movement<br>speed by 15%.' },
      { id: 'firerate', title: '+ Fire Rate', desc: 'Shoot 20% faster.' }
    ];
    const guns: Record<string, any> = {
      'shotgun': { title: 'Gun: Shotgun', desc: 'Fires a spread<br>of 5 bullets.' },
      'minigun': { title: 'Gun: Minigun', desc: 'Extremely high fire<br>rate, slight spread.' },
      'laser': { title: 'Gun: Laser', desc: 'RARE!<br>Fires a fast, 200/s beam.' },
      'rocket': { title: 'Gun: Rocket Launcher', desc: 'Fires explosives that<br>detonate on impact.' }
    };
    const r = Math.random();
    let gunId = r < 0.1 ? 'laser' : r < 0.4 ? 'rocket' : r < 0.75 ? 'minigun' : 'shotgun';
    
    const selected = baseUpgrades.sort(() => Math.random() - 0.5).slice(0, 2);
    const final = [...selected, { id: gunId, ...guns[gunId] }].sort(() => Math.random() - 0.5);
    setUpgrades(final);
  };

  useEffect(() => {
    // No longer needed as onStateChange handles it
  }, [game?.state]);

  return (
    <div id="game-container">
      <div id="debug-info" style={{ position: 'absolute', top: '5px', left: '5px', color: '#fff', fontFamily: 'monospace', fontSize: '12px', pointerEvents: 'none', textShadow: '1px 1px 1px #000', zIndex: 1000 }}>
        HP: 0/0 | State: {gameState}
      </div>
      
      <button 
        onClick={() => {
          if (game) {
            game.showHitboxes = !game.showHitboxes;
            (window as any).showHitboxes = game.showHitboxes;
            setShowHitboxes(game.showHitboxes);
          }
        }}
        style={{
          position: 'absolute',
          top: '5px',
          right: '5px',
          zIndex: 1001,
          padding: '4px 8px',
          background: showHitboxes ? '#2ecc71' : '#333',
          color: '#fff',
          border: '1px solid #555',
          borderRadius: '4px',
          fontSize: '10px',
          cursor: 'pointer'
        }}
      >
        {showHitboxes ? 'Hide Hitboxes (H)' : 'Show Hitboxes (H)'}
      </button>

      <button 
        onClick={() => setIsShopOpen(true)}
        style={{
          position: 'absolute',
          top: '35px',
          right: '5px',
          zIndex: 1001,
          padding: '4px 8px',
          background: '#f1c40f',
          color: '#000',
          border: '1px solid #555',
          borderRadius: '4px',
          fontSize: '10px',
          cursor: 'pointer',
          fontWeight: 'bold'
        }}
      >
        💎 SHOP ({shards})
      </button>

      {isShopOpen && (
        <div style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: '300px',
          background: 'rgba(0,0,0,0.95)',
          border: '2px solid #f1c40f',
          borderRadius: '8px',
          padding: '20px',
          zIndex: 3000,
          color: '#fff',
          textAlign: 'center'
        }}>
          <h2 style={{ color: '#f1c40f', marginBottom: '15px' }}>SKIN SHOP</h2>
          <div style={{ marginBottom: '20px', fontSize: '14px' }}>Your Shards: {shards}</div>
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {[
              { id: 'default', name: 'Default Blue', price: 0 },
              { id: 'crimson', name: 'Crimson Fury', price: 200 },
              { id: 'gold', name: 'Golden Admin', price: 500 },
              { id: 'glitch', name: 'Glitch Master', price: 1000 }
            ].map(skin => (
              <div key={skin.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#222', padding: '8px', borderRadius: '4px' }}>
                <span>{skin.name}</span>
                {ownedSkins.includes(skin.id) ? (
                  <button 
                    onClick={() => {
                      setCurrentSkin(skin.id);
                      if (game?.player) game.player.skin = skin.id;
                    }}
                    style={{ background: currentSkin === skin.id ? '#2ecc71' : '#555', color: '#fff', border: 'none', padding: '4px 8px', borderRadius: '2px', cursor: 'pointer' }}
                  >
                    {currentSkin === skin.id ? 'Equipped' : 'Equip'}
                  </button>
                ) : (
                  <button 
                    onClick={() => {
                      if (shards >= skin.price) {
                        setShards(prev => prev - skin.price);
                        setOwnedSkins(prev => [...prev, skin.id]);
                        if (game?.player) game.player.shards -= skin.price;
                      } else {
                        alert("Not enough shards!");
                      }
                    }}
                    style={{ background: '#f1c40f', color: '#000', border: 'none', padding: '4px 8px', borderRadius: '2px', cursor: 'pointer', fontWeight: 'bold' }}
                  >
                    Buy ({skin.price})
                  </button>
                )}
              </div>
            ))}
          </div>
          
          <button 
            onClick={() => setIsShopOpen(false)}
            style={{ marginTop: '20px', background: '#e74c3c', color: '#fff', border: 'none', padding: '8px 16px', borderRadius: '4px', cursor: 'pointer' }}
          >
            Close
          </button>
        </div>
      )}

      <canvas id="gameCanvas" ref={canvasRef} width="600" height="600"></canvas>
      
      <div id="ui-layer">
        <div id="boss-health" className="health-bar-container hidden">
          <div id="boss-health-fill" className="health-bar-fill"></div>
          <div id="boss-health-text" className="health-bar-text">Boss Name</div>
        </div>

        <div style={{ flexGrow: 1 }}></div>

        <div id="player-health" className="health-bar-container">
          <div id="player-health-fill" className="health-bar-fill"></div>
          <div className="health-bar-text">Player HP</div>
        </div>
      </div>

      <div id="overlay" className="overlay-panel">
        <div id="menu-content" style={{ textAlign: 'center', maxWidth: '500px' }}>
          <h1 id="overlay-title" style={{ fontSize: '48px', marginBottom: '5px', textShadow: '0 0 10px #3498db' }}>AoE Boss Rush</h1>
          <p id="overlay-desc" style={{ fontSize: '16px', color: '#3498db', marginBottom: '30px', fontFamily: 'monospace', letterSpacing: '1px' }}>
            [ SYSTEM SIMULATION v1.0.4 ]
          </p>
          
          <div style={{ background: 'rgba(0,0,0,0.6)', border: '1px solid #3498db', padding: '20px', borderRadius: '4px', marginBottom: '30px', boxShadow: 'inset 0 0 15px rgba(52, 152, 219, 0.2)' }}>
            <h3 style={{ margin: '0 0 15px 0', color: '#3498db', fontSize: '18px', textTransform: 'uppercase' }}>Command Protocols</h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', fontSize: '13px', textAlign: 'left' }}>
              <div><span style={{ color: '#3498db' }}>WASD</span> : NAVIGATE</div>
              <div><span style={{ color: '#3498db' }}>L-CLICK</span> : FIRE</div>
              <div><span style={{ color: '#3498db' }}>R-CLICK</span> : MELEE</div>
              <div><span style={{ color: '#3498db' }}>SPACE</span> : DASH</div>
            </div>
          </div>

          <div style={{ marginBottom: '30px' }}>
            <div style={{ fontSize: '12px', color: '#666', marginBottom: '5px' }}>SIMULATION PROGRESS</div>
            <div style={{ width: '200px', height: '4px', background: '#222', margin: '0 auto 10px auto', borderRadius: '2px', overflow: 'hidden' }}>
              <div style={{ width: `${Math.min(100, (act1Completions / 10) * 100)}%`, height: '100%', background: '#f1c40f' }}></div>
            </div>
            <p style={{ margin: 0, color: '#f1c40f', fontWeight: 'bold', fontSize: '14px' }}>
              ACTS COMPLETED: {act1Completions}
            </p>
          </div>

          {!game ? (
            <div className="loading-spinner">Initializing...</div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', alignItems: 'center' }}>
              <button id="start-btn" style={{ width: '280px', fontSize: '22px', padding: '12px 0', background: '#3498db', border: '1px solid #fff' }} onClick={handleStart}>
                {game.state === 'GAMEOVER' ? 'REBOOT SYSTEM' : 'START SIMULATION'}
              </button>
              
              {achievements.god_slayer.unlocked && (
                <button id="bonus-btn" style={{ width: '280px', fontSize: '18px' }} onClick={handleBonus}>AWAKEN TRUE ADMIN</button>
              )}
              
              <div style={{ display: 'flex', gap: '8px', width: '280px' }}>
                <button id="achievements-btn" style={{ flex: 1, fontSize: '14px', background: '#2c3e50' }} onClick={() => setShowAchievements(true)}>DATA LOGS</button>
                <button id="save-btn" style={{ flex: 1, fontSize: '14px', background: '#27ae60' }} onClick={handleSave}>SAVE</button>
                <label htmlFor="load-file" style={{ flex: 1, background: '#8e44ad', padding: '10px', cursor: 'pointer', borderRadius: '5px', fontWeight: 'bold', textTransform: 'uppercase', fontSize: '14px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>LOAD</label>
                <input type="file" id="load-file" accept=".json" className="hidden" onChange={handleLoad} />
              </div>
            </div>
          )}
        </div>
        
        <div 
          style={{ position: 'absolute', bottom: '10px', right: '10px', opacity: 0.8, cursor: 'pointer', background: 'rgba(0,0,0,0.7)', padding: '6px 12px', borderRadius: '4px', color: '#fff', fontSize: '12px', zIndex: 2000, border: '1px solid #555' }}
          onClick={() => { 
            if (game?.player) {
              game.player.baseDamage += 500;
              game.player.maxHp += 5000;
              game.player.hp = game.player.maxHp;
              (window as any).stackBugEnabled = !(window as any).stackBugEnabled;
              alert("OP DEV MODE: " + ((window as any).stackBugEnabled ? "ON" : "OFF"));
            }
          }}
        >
          .sys_dbg
        </div>
      </div>

      {showAchievements && (
        <div id="achievements-screen" className="overlay-panel">
          <h1>Achievements</h1>
          <div id="achievements-list" style={{ maxHeight: '300px', overflowY: 'auto', marginBottom: '20px' }}>
            {Object.entries(achievements).map(([id, a]: [string, Achievement]) => (
              <div 
                key={id} 
                className={`achiev-item ${a.unlocked ? 'unlocked' : ''}`}
                onClick={() => setAchievPopup({ title: a.unlocked ? '🏆 ' + a.title : '🔒 Locked Achievement', desc: a.unlocked ? a.desc : 'Keep playing to discover this secret...' })}
              >
                <h4>{a.unlocked ? '🏆 ' : '🔒 '}{a.title}</h4>
                <p style={{ fontSize: '10px', color: '#aaa' }}>Click for details</p>
              </div>
            ))}
          </div>
          <button id="back-menu-btn" onClick={() => setShowAchievements(false)}>Back to Menu</button>
        </div>
      )}

      {achievPopup && (
        <div id="achiev-popup">
          <h3>{achievPopup.title}</h3>
          <p>{achievPopup.desc}</p>
          <button onClick={() => setAchievPopup(null)}>Close</button>
        </div>
      )}

      <div id="fake-ad" className="hidden">
        <button id="close-ad" onClick={() => {
          document.getElementById('fake-ad')?.classList.add('hidden');
          unlockAchievement('ad_blocker');
        }}>X</button>
        <h2 style={{ color: 'red', marginTop: '10px' }}>WARNING!</h2>
        <p style={{ color: 'black' }}>Your computer has a VIRUS!<br /><br />Click below to download Anti-Virus.</p>
        <button style={{ background: '#2ecc71', color: 'white', padding: '10px 20px', border: 'none', fontSize: '16px', cursor: 'pointer', animation: 'pulse 1s infinite' }}>DOWNLOAD NOW</button>
      </div>

      <div id="toast" className="hidden">Achievement Unlocked!</div>

      <div id="upgrade-screen" className={gameState === 'UPGRADE' ? '' : 'hidden'}>
        <h1>{game && game.pendingUpgrades > 1 ? 'Room Cleared! (Pick 2)' : 'Room Cleared!'}</h1>
        <p>Choose your reward:</p>
        <div className="upgrade-options">
          {upgrades.map(u => (
            <div 
              key={u.id} 
              className="upgrade-card" 
              style={['shotgun', 'minigun', 'laser', 'rocket'].includes(u.id) ? { borderColor: '#e74c3c' } : {}}
              onClick={() => game?.applyUpgrade(u.id)}
            >
              <h3>{u.title}</h3>
              <p dangerouslySetInnerHTML={{ __html: u.desc }}></p>
            </div>
          ))}
        </div>
      </div>

      <div id="dialogue-container" className="hidden">
        <div id="dialogue-speaker">Speaker</div>
        <div id="dialogue-text">Dialogue text goes here...</div>
        <div id="dialogue-prompt">Press SPACE or CLICK to continue</div>
      </div>
    </div>
  );
}
