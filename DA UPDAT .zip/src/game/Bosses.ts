import { MathUtils } from './MathUtils';
import { Telegraph } from './Telegraph';
import { Projectile } from './Projectile';
import { Hazard } from './Hazard';
import { Collectible } from './Collectible';

export class Boss {
    name: string;
    x: number;
    y: number;
    maxHp: number;
    hp: number;
    radius: number;
    color: string;
    state: string;
    stateTimer: number;

    constructor(name: string, x: number, y: number, maxHp: number, radius: number, color: string) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.maxHp = maxHp;
        this.hp = maxHp;
        this.radius = radius;
        this.color = color;
        this.state = 'IDLE';
        this.stateTimer = 2.0;

        const ui = document.getElementById('boss-health');
        if (ui) ui.classList.remove('hidden');
        const hpText = document.getElementById('boss-health-text');
        if (hpText) hpText.innerText = this.name;
        this.updateHealthUI();
    }

    updateHealthUI() {
        const hpFill = document.getElementById('boss-health-fill');
        if (hpFill) hpFill.style.width = `${Math.max(0, (this.hp / this.maxHp)) * 100}%`;
    }

    takeDamage(amt: number, game: any) {
        if (this.hp <= 0) return;
        
        const damageAmount = Number(amt);
        if (isNaN(damageAmount) || !isFinite(damageAmount)) {
            console.error("Invalid damage amount received by boss:", amt);
            return;
        }

        this.hp -= damageAmount;
        
        // Robust HP bounds and NaN safety
        if (isNaN(this.hp)) {
            console.error("Boss HP became NaN! Resetting to 0.");
            this.hp = 0;
        }
        if (this.hp < 0) this.hp = 0;

        this.updateHealthUI();

        // Visual feedback for taking damage
        if (game && damageAmount > 0) {
            if (game.player) {
                game.player.combo++;
                game.player.comboTimer = 3.0;
            }
            
            // Glitch effect on high damage
            if (damageAmount > 50) {
                game.runGlitched = true;
                if (game.applyShake) game.applyShake(10);
            }
        }

        if (this.hp <= 0) {
            this.hp = 0;
            if (game) game.spawnParticles(this.x, this.y, this.color, 100, 400, 1.5, 6);
            this.die(game);
        }
    }

    die(game: any) {
        const hpUI = document.getElementById('boss-health');
        if (hpUI) hpUI.classList.add('hidden');
        game.roomCleared();
    }

    update(dt: number, player: any, game: any) {}

    draw(ctx: CanvasRenderingContext2D, game: any = null, drawBody: boolean = true) {
        if (this.hp <= 0) return;
        if (drawBody) {
            ctx.fillStyle = this.color;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#000';
            ctx.lineWidth = 3;
            ctx.stroke();
        }

        // Draw Hitbox and Aimer for Debugging
        const isHitboxVisible = (game && game.showHitboxes) || (window as any).showHitboxes;
        if (isHitboxVisible) {
            ctx.strokeStyle = '#ff0000';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
            ctx.stroke();
            
            // Draw Aimer towards player
            const target = (game && game.player) || (window as any).game?.player;
            if (target) {
                const angle = Math.atan2(target.y - this.y, target.x - this.x);
                ctx.save();
                ctx.setLineDash([10, 5]);
                ctx.strokeStyle = 'rgba(255, 50, 50, 0.8)';
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.moveTo(this.x, this.y);
                ctx.lineTo(this.x + Math.cos(angle) * 1500, this.y + Math.sin(angle) * 1500);
                ctx.stroke();
                ctx.restore();
            }

            if (this.state === 'ATTACKING') {
                ctx.fillStyle = 'rgba(255, 0, 0, 0.2)';
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.radius * 1.5, 0, Math.PI * 2);
                ctx.fill();
                ctx.fillStyle = '#fff';
                ctx.font = 'bold 16px monospace';
                ctx.textAlign = 'center';
                ctx.fillText('ATTACKING!', this.x, this.y - this.radius - 15);
            }
        }
    }
}

export class Minion {
    x: number; y: number; type: string;
    r: number; hp: number; speed: number;
    color: string; active: boolean; hitCooldown: number;

    constructor(x: number, y: number, type: string) {
        this.x = x; this.y = y; this.type = type;
        this.r = type === 'big' ? 30 : 15;
        this.hp = type === 'big' ? 100 : 30;
        this.speed = type === 'big' ? 50 : 110;
        this.color = type === 'big' ? '#8e44ad' : '#e74c3c';
        this.active = false;
        this.hitCooldown = 0;
    }
    takeDamage(amt: number, game: any) {
        if (this.hp <= 0) return;
        this.hp -= amt;
        if (game && amt > 0) {
            game.spawnParticles(this.x, this.y, this.color, 5, 100, 0.2, 2);
        }
        if (this.hp <= 0) {
            this.hp = 0;
            if (game) game.spawnParticles(this.x, this.y, this.color, 20, 200, 0.5, 4);
        }
    }
    update(dt: number, player: any) {
        if (!this.active || this.hp <= 0) return;
        if (this.hitCooldown > 0) this.hitCooldown -= dt;
        const angle = Math.atan2(player.y - this.y, player.x - this.x);
        this.x += Math.cos(angle) * this.speed * dt;
        this.y += Math.sin(angle) * this.speed * dt;

        if (MathUtils.dist(this.x, this.y, player.x, player.y) < this.r + player.radius) {
            if (this.hitCooldown <= 0) {
                player.takeDamage(10, 'minion');
                this.hitCooldown = 0.5;
            }
        }
    }
    draw(ctx: CanvasRenderingContext2D) {
        if (this.hp <= 0) return;
        ctx.fillStyle = this.color;
        ctx.beginPath(); ctx.arc(this.x, this.y, this.r, 0, Math.PI*2); ctx.fill();
        ctx.strokeStyle = '#000'; ctx.lineWidth = 2; ctx.stroke();
    }
}

export class TutorialDirector extends Boss {
    tutorialState: number;
    friend: any;
    admin: any;
    gun: any;
    minions: Minion[];
    dungeonY: number;
    objective: string;

    constructor(x: number, y: number) {
        super("Tutorial", x, y, 1, 0, 'transparent');
        this.tutorialState = 0;
        this.friend = {x: 300, y: 650, active: false};
        this.admin = {x: 300, y: -50, active: false};
        this.gun = {x: 300, y: 300, active: false, pickedUp: false};
        this.minions = [];
        this.dungeonY = -200;
        this.objective = "WASD to Move. Walk forward.";
        
        setTimeout(() => {
            const hpUI = document.getElementById('boss-health');
            if (hpUI) hpUI.classList.add('hidden');
        }, 10);
    }

    takeDamage(amt: number, game: any) {}

    update(dt: number, player: any, game: any) {
        if (this.tutorialState === 0) {
            if (player.y < game.ROOM_SIZE * 0.6) {
                this.tutorialState = 1;
                game.playDialogue([
                    {speaker: 'Friend', text: 'What is that thing?!'},
                    {speaker: 'Player', text: 'Get back!'}
                ], () => {
                    this.tutorialState = 2;
                });
            }
        } else if (this.tutorialState === 2) {
            this.dungeonY += (game.ROOM_SIZE * 0.2 - this.dungeonY) * 5 * dt;
            if (Math.abs(this.dungeonY - game.ROOM_SIZE * 0.2) < 2) {
                this.friend.active = true;
                this.friend.y = game.ROOM_SIZE - 20;
                this.tutorialState = 3;
                game.playDialogue([
                    {speaker: 'Friend', text: "It's pulling me! Help!"},
                    {speaker: 'The Admin', text: "SUBJECT ACQUIRED. INITIATING EXTRACTION."},
                    {speaker: 'Player', text: "Let them go!"}
                ], () => {
                    this.tutorialState = 4;
                    this.admin.active = true;
                    this.admin.y = this.friend.y;
                });
            }
        } else if (this.tutorialState === 4) {
            this.friend.y -= 200 * dt;
            this.admin.y -= 200 * dt;
            if (this.friend.y < -50) {
                this.tutorialState = 5;
                game.playDialogue([
                    {speaker: 'The Admin', text: 'Engaging defensive protocols.'},
                    {speaker: 'System', text: 'ANOMALY DETECTED. WEAPONIZED PAYLOAD SECURED.'}
                ], () => {
                    this.tutorialState = 6;
                    this.gun.active = true;
                    this.minions.push(new Minion(100, 200, 'small'));
                    this.minions.push(new Minion(game.ROOM_SIZE-100, 200, 'small'));
                    this.minions.push(new Minion(game.ROOM_SIZE/2, 150, 'big'));
                    this.objective = "Grab the glowing weapon in the center!";
                });
            }
        } else if (this.tutorialState === 6) {
            this.dungeonY -= 100 * dt;
            if (!this.gun.pickedUp && MathUtils.dist(player.x, player.y, this.gun.x, this.gun.y) < 30) {
                this.gun.pickedUp = true;
                this.gun.active = false;
                player.hasWeapon = true;
                this.tutorialState = 7;
                game.playDialogue([
                    {speaker: 'Player', text: "Let's see what this can do."},
                    {speaker: 'System', text: 'Left Click: Shoot. Space: Dash. Right Click: Melee.'}
                ], () => {
                    this.tutorialState = 8;
                    this.minions.forEach(m => m.active = true);
                    this.objective = "Defeat the firewall guards!";
                });
            }
        } else if (this.tutorialState === 8) {
            let alive = false;
            for (let m of this.minions) {
                m.update(dt, player);
                if (m.hp > 0) alive = true;
            }
            if (!alive) {
                this.tutorialState = 9;
                game.playDialogue([
                    {speaker: 'System', text: 'BREACH SUCCESSFUL. PROCEED TO NEXT SECTOR.'}
                ], () => {
                    this.hp = 0;
                    this.die(game);
                    this.objective = "Enter the portal.";
                });
            }
        }
    }

    draw(ctx: CanvasRenderingContext2D) {
        const ROOM_SIZE = 600;
        if (this.tutorialState >= 1) {
            ctx.fillStyle = '#2c3e50';
            ctx.fillRect(ROOM_SIZE*0.2, this.dungeonY - 100, ROOM_SIZE*0.6, 200);
            ctx.fillStyle = '#1a252f';
            ctx.fillRect(ROOM_SIZE*0.4, this.dungeonY + 20, ROOM_SIZE*0.2, 80);
            ctx.fillStyle = '#8e44ad';
            ctx.fillRect(ROOM_SIZE*0.45, this.dungeonY + 40, ROOM_SIZE*0.1, 60);
        }

        if (this.friend.active) {
            ctx.fillStyle = '#ffb8b8';
            ctx.beginPath(); ctx.arc(this.friend.x, this.friend.y, 10, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle = '#e74c3c';
            ctx.fillRect(this.friend.x - 5, this.friend.y - 12, 10, 4);
        }
        if (this.admin.active) {
            ctx.fillStyle = '#00ff00';
            ctx.fillRect(this.admin.x - 15, this.admin.y - 15, 30, 30);
            ctx.fillStyle = '#000';
            ctx.font = 'bold 12px Arial';
            ctx.textAlign = 'center';
            ctx.fillText("010", this.admin.x, this.admin.y+5);
        }
        if (this.gun.active) {
            ctx.fillStyle = '#f1c40f';
            ctx.fillRect(this.gun.x - 10, this.gun.y - 5, 20, 10);
            ctx.strokeStyle = `rgba(241, 196, 15, ${Math.abs(Math.sin(performance.now()/200))})`;
            ctx.lineWidth = 3;
            ctx.beginPath(); ctx.arc(this.gun.x, this.gun.y, 25, 0, Math.PI*2); ctx.stroke();
        }

        for (let m of this.minions) m.draw(ctx);

        ctx.fillStyle = '#fff';
        ctx.font = 'bold 20px "Segoe UI", sans-serif';
        ctx.textAlign = 'center';
        ctx.shadowColor = 'black';
        ctx.shadowBlur = 4;
        ctx.fillText(this.objective, ROOM_SIZE/2, ROOM_SIZE - 20);
        ctx.shadowBlur = 0;
    }
}

export class RobotBoss extends Boss {
    speed: number;

    constructor(x: number, y: number) {
        super("Mecha Sentinel", x, y, 1800, 45, '#95a5a6');
        this.speed = 100;
    }

    update(dt: number, player: any, game: any) {
        if (this.hp <= 0) return;

        if (this.state === 'IDLE') {
            const angle = Math.atan2(player.y - this.y, player.x - this.x);
            this.x += Math.cos(angle) * this.speed * dt;
            this.y += Math.sin(angle) * this.speed * dt;

            this.stateTimer -= dt;
            if (this.stateTimer <= 0) {
                this.pickAttack(player, game);
            }
        } else if (this.state === 'ATTACKING') {
            this.stateTimer -= dt;
            if (this.stateTimer <= 0) {
                this.state = 'IDLE';
                this.stateTimer = 0.3 + Math.random() * 0.3;
            }
        }
    }

    pickAttack(player: any, game: any) {
        this.state = 'ATTACKING';
        const r = Math.random();
        if (r < 0.2) this.attackRotatingLaser(game);
        else if (r < 0.4) this.attackHomingMissiles(player, game);
        else if (r < 0.6) this.attackGearThrow(player, game);
        else if (r < 0.8) this.attackLaserGrid(game);
        else this.attackBullets(player, game);
    }

    attackLaserGrid(game: any) {
        this.stateTimer = 2.0;
        for(let i = 1; i < 5; i++) {
            const y = (game.ROOM_SIZE / 5) * i;
            game.telegraphs.push(new Telegraph('line', {
                x1: 0, y1: y, x2: game.ROOM_SIZE, y2: y, w: 40
            }, 1.2, 42, null, '⚡'));
        }
        for(let i = 1; i < 5; i++) {
            const x = (game.ROOM_SIZE / 5) * i;
            game.telegraphs.push(new Telegraph('line', {
                x1: x, y1: 0, x2: x, y2: game.ROOM_SIZE, w: 40
            }, 1.2, 42, null, '⚡'));
        }
    }

    attackRotatingLaser(game: any) {
        this.stateTimer = 4.8;
        const startAngle = Math.random() * Math.PI * 2;
        for (let i = 0; i < 30; i++) {
            setTimeout(() => {
                if (this.hp <= 0 || game.state !== 'PLAYING' || game.room.boss !== this) return;
                const angle = startAngle + (i * 0.15);
                const endX = this.x + Math.cos(angle) * 800;
                const endY = this.y + Math.sin(angle) * 800;
                game.telegraphs.push(new Telegraph('line', {
                    x1: this.x, y1: this.y, x2: endX, y2: endY, w: 45
                }, 0.5, 12, null, '⚡')); 
            }, i * 150);
        }
    }

    attackHomingMissiles(player: any, game: any) {
        this.stateTimer = 2.0; 
        for (let i = 0; i < 12; i++) {
            setTimeout(() => {
                if (this.hp <= 0 || game.state !== 'PLAYING' || game.room.boss !== this) return;
                const angle = Math.random() * Math.PI * 2;
                const proj = new Projectile(this.x, this.y, angle, false, 'bomb', 17);
                proj.speed = 140;
                proj.vx = Math.cos(angle) * proj.speed;
                proj.vy = Math.sin(angle) * proj.speed;
                proj.homingTarget = player;
                proj.lifetime = 4.0;
                proj.maxRange = Infinity;
                
                const ogUpdate = proj.update.bind(proj);
                proj.update = (dt: number, room: any, game: any) => {
                    ogUpdate(dt, room, game);
                    if (!proj.active) {
                        game.telegraphs.push(new Telegraph('circle', {x: proj.x, y: proj.y, r: 70}, 0.5, 33, null, '💥'));
                    }
                };
                game.projectiles.push(proj);
            }, i * 150); 
        }
    }

    attackGearThrow(player: any, game: any) {
        this.stateTimer = 1.0;
        const baseAngle = Math.atan2(player.y - this.y, player.x - this.x);
        for (let i = 0; i < 8; i++) {
            const angle = baseAngle + (i * Math.PI / 4);
            const proj = new Projectile(this.x, this.y, angle, false, 'gear', 18);
            game.projectiles.push(proj);
        }
    }

    attackBullets(player: any, game: any) {
        this.stateTimer = 1.5;
        const baseAngle = Math.atan2(player.y - this.y, player.x - this.x);
        for (let i = 0; i < 25; i++) {
            setTimeout(() => {
                if (this.hp <= 0 || game.state !== 'PLAYING' || game.room.boss !== this) return;
                const angle = baseAngle + (Math.random() - 0.5) * 0.5;
                const proj = new Projectile(this.x, this.y, angle, false, 'default', 13);
                proj.vx = Math.cos(angle) * 550;
                proj.vy = Math.sin(angle) * 550;
                game.projectiles.push(proj);
            }, i * 30);
        }
    }

    draw(ctx: CanvasRenderingContext2D, game: any = null) {
        if (this.hp <= 0) return;
        ctx.fillStyle = this.color;
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.beginPath();
        (ctx as any).roundRect(-this.radius, -this.radius, this.radius*2, this.radius*2, 10);
        ctx.fill();
        ctx.strokeStyle = '#2c3e50';
        ctx.lineWidth = 3;
        ctx.stroke();
        ctx.fillStyle = '#34495e';
        ctx.fillRect(-this.radius - 8, -this.radius * 0.8, 8, this.radius * 1.6);
        ctx.fillRect(this.radius, -this.radius * 0.8, 8, this.radius * 1.6);
        ctx.fillStyle = '#e74c3c';
        ctx.beginPath();
        ctx.fillRect(-15, -8, 30, 8);
        ctx.fill();
        ctx.restore();

        // Draw debug info on top
        super.draw(ctx, game, false);
    }
}

export class GolemBoss extends Boss {
    spikePhase: number;

    constructor(x: number, y: number) {
        super("Ancient Golem", x, y, 1500, 35, '#7f8c8d');
        this.spikePhase = 0;
    }

    update(dt: number, player: any, game: any) {
        if (this.hp <= 0) return;

        if (this.state === 'IDLE') {
            const angle = Math.atan2(player.y - this.y, player.x - this.x);
            this.x += Math.cos(angle) * 50 * dt;
            this.y += Math.sin(angle) * 50 * dt;

            this.stateTimer -= dt;
            if (this.stateTimer <= 0) {
                this.pickAttack(player, game);
            }
        } else if (this.state === 'ATTACKING') {
            this.stateTimer -= dt;
            if (this.stateTimer <= 0) {
                this.state = 'IDLE';
                this.stateTimer = 0.3 + Math.random() * 0.3;
            }
        }
    }

    pickAttack(player: any, game: any) {
        this.state = 'ATTACKING';
        this.stateTimer = 2.0; 
        const r = Math.random();
        if (r < 0.2) this.attackSpikeWave(game);
        else if (r < 0.4) this.attackDeleteBattlefield(game);
        else if (r < 0.6) this.attackCreateWall(player, game);
        else if (r < 0.8) this.attackEarthMissile(player, game);
        else this.attackBoulderToss(player, game);
    }

    attackBoulderToss(player: any, game: any) {
        const baseAngle = Math.atan2(player.y - this.y, player.x - this.x);
        for (let i = -1; i <= 1; i++) {
            const angle = baseAngle + (i * 0.3);
            const proj = new Projectile(this.x, this.y, angle, false, 'earth', 33);
            proj.radius = 15;
            proj.speed = 180;
            proj.vx = Math.cos(angle) * proj.speed;
            proj.vy = Math.sin(angle) * proj.speed;
            game.projectiles.push(proj);
        }
        this.stateTimer = 1.0;
    }

    attackSpikeWave(game: any) {
        let rings = [];
        if (this.spikePhase === 0) {
            rings = [[20, 80], [140, 200], [260, 320]];
        } else {
            rings = [[80, 140], [200, 260], [320, 380]];
        }
        this.spikePhase = 1 - this.spikePhase;

        rings.forEach((r) => {
            game.telegraphs.push(new Telegraph('ring', {
                x: this.x, y: this.y, innerR: r[0], outerR: r[1]
            }, 2.0, 39, null, '🪨'));
        });
    }

    attackDeleteBattlefield(game: any) {
        const edges = [
            {x: 0, y: 0, w: 100, h: game.ROOM_SIZE},
            {x: game.ROOM_SIZE-100, y: 0, w: 100, h: game.ROOM_SIZE},
            {x: 0, y: 0, w: game.ROOM_SIZE, h: 100},
            {x: 0, y: game.ROOM_SIZE-100, w: game.ROOM_SIZE, h: 100}
        ];
        const edge = edges[Math.floor(Math.random() * edges.length)];

        game.telegraphs.push(new Telegraph('rect', {
            x: edge.x, y: edge.y, w: edge.w, h: edge.h
        }, 2.5, 55, () => {
            if (MathUtils.circleRectCollide(game.player.x, game.player.y, game.player.radius, edge.x, edge.y, edge.w, edge.h)) {
                game.player.x = game.ROOM_SIZE/2;
                game.player.y = game.ROOM_SIZE/2;
            }
            game.room.walls.push(edge);
        }, '🧱', 'wall'));
        this.stateTimer = 2.5;
    }

    attackCreateWall(player: any, game: any) {
        const dx = player.x - this.x;
        const dy = player.y - this.y;
        const len = Math.sqrt(dx*dx + dy*dy);
        const midX = this.x + (dx/len) * (len/2);
        const midY = this.y + (dy/len) * (len/2);
        const rect = { x: midX - 50, y: midY - 20, w: 100, h: 40 };

        game.telegraphs.push(new Telegraph('rect', rect, 1.5, 33, () => {
            game.room.walls.push(rect);
            setTimeout(() => {
                const idx = game.room.walls.indexOf(rect);
                if (idx > -1) game.room.walls.splice(idx, 1);
            }, 8000);
        }, '🧱', 'wall'));
        this.stateTimer = 1.5;
    }

    attackEarthMissile(player: any, game: any) {
        for(let i=-1; i<=1; i+=2) {
            const angle = Math.atan2(player.y - this.y, player.x - this.x) + (i * 0.2);
            const proj = new Projectile(this.x, this.y, angle, false, 'earth', 22);
            const ogUpdate = proj.update.bind(proj);
            proj.update = (dt: number, room: any, game: any) => {
                ogUpdate(dt, room, game);
                if (!proj.active) {
                    game.telegraphs.push(new Telegraph('circle', {
                        x: proj.x, y: proj.y, r: 60
                    }, 1.0, 28, null, '💥'));
                }
            };
            game.projectiles.push(proj);
        }
    }
    
    draw(ctx: CanvasRenderingContext2D, game: any = null) {
        if (this.hp <= 0) return;
        // Draw as a blocky polygon for Golem (Stone Texture)
        ctx.fillStyle = '#7f8c8d';
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.beginPath();
        ctx.moveTo(-this.radius, -this.radius);
        ctx.lineTo(this.radius, -this.radius*0.8);
        ctx.lineTo(this.radius*0.9, this.radius);
        ctx.lineTo(-this.radius*0.8, this.radius*0.9);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = '#2c3e50';
        ctx.lineWidth = 3;
        ctx.stroke();
        ctx.restore();

        // Draw debug info on top
        super.draw(ctx, game, false);
    }
}

export class DragonBoss extends Boss {
    speed: number;
    dashTarget: any;
    lastX: number;
    lastY: number;
    facingAngle: number;

    constructor(x: number, y: number) {
        super("Crimson Dragon", x, y, 2500, 50, '#c0392b');
        this.speed = 180;
        this.dashTarget = null;
        this.lastX = x;
        this.lastY = y;
        this.facingAngle = 0;
    }

    update(dt: number, player: any, game: any) {
        if (this.hp <= 0) return;

        if (this.x !== this.lastX || this.y !== this.lastY) {
            this.facingAngle = Math.atan2(this.y - this.lastY, this.x - this.lastX);
            this.lastX = this.x;
            this.lastY = this.y;
        }

        if (this.state === 'IDLE') {
            const angle = Math.atan2(player.y - this.y, player.x - this.x);
            const dist = MathUtils.dist(this.x, this.y, player.x, player.y);
            if (dist > 150) {
                this.x += Math.cos(angle) * this.speed * dt;
                this.y += Math.sin(angle) * this.speed * dt;
            }
            this.stateTimer -= dt;
            if (this.stateTimer <= 0) this.pickAttack(player, game);
        } else if (this.state === 'ATTACKING') {
            this.stateTimer -= dt;
            if (this.stateTimer <= 0) {
                this.state = 'IDLE';
                this.stateTimer = 0.05 + Math.random() * 0.1;
            }
        } else if (this.state === 'DASHING') {
            const angle = Math.atan2(this.dashTarget.y - this.y, this.dashTarget.x - this.x);
            this.x += Math.cos(angle) * 800 * dt;
            this.y += Math.sin(angle) * 800 * dt;
            if (MathUtils.dist(this.x, this.y, this.dashTarget.x, this.dashTarget.y) < 20) {
                this.x = this.dashTarget.x;
                this.y = this.dashTarget.y;
                this.state = 'IDLE';
                this.stateTimer = 0.5;
            }
        }
    }

    pickAttack(player: any, game: any) {
        this.state = 'ATTACKING';
        this.stateTimer = 1.2;
        const attacks = [
            this.attackBreath, this.attackFireRain, this.attackClaw, 
            this.attackDash, this.attackTailSweep, this.attackFireWhirl, this.attackWingGust,
            this.attackHomingFireballs, this.attackFireballSpread
        ];
        const chosen = attacks[Math.floor(Math.random() * attacks.length)];
        chosen.call(this, player, game);
    }

    attackFireballSpread(player: any, game: any) {
        const baseAngle = Math.atan2(player.y - this.y, player.x - this.x);
        for (let i = -6; i <= 6; i++) {
            const angle = baseAngle + (i * 0.12);
            const proj = new Projectile(this.x, this.y, angle, false, 'fire', 22);
            proj.speed = 350;
            proj.vx = Math.cos(angle) * proj.speed;
            proj.vy = Math.sin(angle) * proj.speed;
            game.projectiles.push(proj);
        }
        this.stateTimer = 0.8;
    }

    attackHomingFireballs(player: any, game: any) {
        this.stateTimer = 3.0;
        for (let i = 0; i < 50; i++) {
            setTimeout(() => {
                if (this.hp <= 0 || game.state !== 'PLAYING' || game.room.boss !== this) return;
                const angle = Math.random() * Math.PI * 2;
                const proj = new Projectile(this.x, this.y, angle, false, 'fire', 9);
                proj.speed = 220;
                proj.vx = Math.cos(angle) * proj.speed;
                proj.vy = Math.sin(angle) * proj.speed;
                proj.homingTarget = player;
                proj.lifetime = 5.0;
                proj.maxRange = Infinity;
                game.projectiles.push(proj);
            }, i * 50);
        }
        game.telegraphs.push(new Telegraph('circle', { x: this.x, y: this.y, r: 60 }, 3.0, 0, null, '☄️'));
    }

    attackBreath(player: any, game: any) {
        const dx = player.x - this.x;
        const dy = player.y - this.y;
        const len = Math.sqrt(dx*dx + dy*dy);
        const endX = this.x + (dx/len) * 800;
        const endY = this.y + (dy/len) * 800;
        game.telegraphs.push(new Telegraph('line', { x1: this.x, y1: this.y, x2: endX, y2: endY, w: 90 }, 1.0, 39, null, '🔥'));
    }

    attackFireRain(player: any, game: any) {
        for (let i = 0; i < 35; i++) {
            const bx = player.x + (Math.random() - 0.5) * 400;
            const by = player.y + (Math.random() - 0.5) * 400;
            game.telegraphs.push(new Telegraph('circle', {
                x: Math.max(20, Math.min(game.ROOM_SIZE-20, bx)), 
                y: Math.max(20, Math.min(game.ROOM_SIZE-20, by)), 
                r: 50
            }, 0.8 + (i * 0.03), 28, null, '☄️'));
        }
    }

    attackClaw(player: any, game: any) {
        const dx = player.x - this.x;
        const dy = player.y - this.y;
        const len = Math.sqrt(dx*dx + dy*dy);
        const cx = this.x + (dx/len) * 70;
        const cy = this.y + (dy/len) * 70;
        game.telegraphs.push(new Telegraph('circle', { x: cx, y: cy, r: 100 }, 0.6, 44, null, '🐾'));
        this.stateTimer = 0.6;
    }

    attackDash(player: any, game: any) {
        const dx = player.x - this.x;
        const dy = player.y - this.y;
        const len = Math.sqrt(dx*dx + dy*dy);
        const dashDist = 450;
        let endX = Math.max(this.radius, Math.min(game.ROOM_SIZE - this.radius, this.x + (dx/len) * dashDist));
        let endY = Math.max(this.radius, Math.min(game.ROOM_SIZE - this.radius, this.y + (dy/len) * dashDist));
        game.telegraphs.push(new Telegraph('line', { x1: this.x, y1: this.y, x2: endX, y2: endY, w: 80 }, 0.8, 55, () => {
            this.state = 'DASHING';
            this.dashTarget = {x: endX, y: endY};
        }, '💨'));
        this.stateTimer = 0.8;
    }

    attackTailSweep(player: any, game: any) {
        game.telegraphs.push(new Telegraph('ring', { x: this.x, y: this.y, innerR: this.radius, outerR: this.radius + 100 }, 0.9, 39, null, '🌪️'));
        this.stateTimer = 0.9;
    }

    attackFireWhirl(player: any, game: any) {
        for (let i = 0; i < 14; i++) {
            const angle = (i / 14) * Math.PI * 4;
            const dist = 80 + i * 20;
            const bx = this.x + Math.cos(angle) * dist;
            const by = this.y + Math.sin(angle) * dist;
            game.telegraphs.push(new Telegraph('circle', { x: bx, y: by, r: 40 }, 1.0 + (i * 0.08), 28, null, '🔥'));
        }
    }

    attackWingGust(player: any, game: any) {
        game.telegraphs.push(new Telegraph('circle', { x: game.ROOM_SIZE/2, y: game.ROOM_SIZE/2, r: 250 }, 1.5, 33, null, '🦅'));
        this.stateTimer = 1.5;
    }

    draw(ctx: CanvasRenderingContext2D, game: any = null) {
        if (this.hp <= 0) return;
        
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.rotate(this.facingAngle);
        let flap = Math.sin(performance.now() / 150) * 0.5;
        ctx.fillStyle = '#922b21';
        ctx.beginPath(); ctx.moveTo(0, -this.radius*0.5); ctx.lineTo(-this.radius*1.5, -this.radius*1.8 - flap*15); ctx.lineTo(-this.radius*0.8, -this.radius*0.8); ctx.fill();
        ctx.strokeStyle = '#000'; ctx.lineWidth = 2; ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, this.radius*0.5); ctx.lineTo(-this.radius*1.5, this.radius*1.8 + flap*15); ctx.lineTo(-this.radius*0.8, this.radius*0.8); ctx.fill();
        ctx.stroke();
        ctx.fillStyle = this.color;
        ctx.beginPath(); ctx.moveTo(-this.radius*0.8, -this.radius*0.3); ctx.lineTo(-this.radius*2, 0); ctx.lineTo(-this.radius*0.8, this.radius*0.3); ctx.fill();
        ctx.stroke();
        ctx.beginPath(); ctx.arc(0, 0, this.radius, 0, Math.PI * 2); ctx.fill();
        ctx.lineWidth = 3; ctx.stroke();
        
        // Eyes
        ctx.fillStyle = '#fff';
        ctx.beginPath(); ctx.arc(this.radius * 0.4, -this.radius * 0.3, 8, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(this.radius * 0.4, this.radius * 0.3, 8, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#000';
        ctx.beginPath(); ctx.arc(this.radius * 0.5, -this.radius * 0.3, 4, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(this.radius * 0.5, this.radius * 0.3, 4, 0, Math.PI * 2); ctx.fill();
        
        ctx.restore();

        // Draw debug info on top
        super.draw(ctx, game, false);
    }
}
