import { MathUtils } from './MathUtils';
import { Telegraph } from './Telegraph';
import { Projectile } from './Projectile';
import { Hazard } from './Hazard';
import { Boss } from './Bosses';

export class NagaBoss extends Boss {
    speed: number;
    hidden: boolean;
    trail: {x: number, y: number}[];
    dashTarget: any;

    constructor(x: number, y: number) {
        super("Venomous Naga", x, y, 2000, 40, '#2ecc71');
        this.speed = 125;
        this.hidden = false;
        this.trail = [];
        for(let i=0; i<30; i++) this.trail.push({x: this.x, y: this.y + i*5});
    }

    update(dt: number, player: any, game: any) {
        if (this.hp <= 0) return;
        if (this.state !== 'DIGGING') {
            const distMoved = MathUtils.dist(this.x, this.y, this.trail[0].x, this.trail[0].y);
            if (distMoved > 2) {
                this.trail.unshift({x: this.x, y: this.y});
                if (this.trail.length > 35) this.trail.pop();
            }
        }
        if (this.state === 'IDLE') {
            if(!this.hidden) {
                const angle = Math.atan2(player.y - this.y, player.x - this.x);
                this.x += Math.cos(angle) * this.speed * dt;
                this.y += Math.sin(angle) * this.speed * dt;
            }
            this.stateTimer -= dt;
            if (this.stateTimer <= 0) this.pickAttack(player, game);
        } else if (this.state === 'ATTACKING') {
            this.stateTimer -= dt;
            if (this.stateTimer <= 0) {
                this.state = 'IDLE';
                this.stateTimer = 0.4 + Math.random() * 0.4;
            }
        } else if (this.state === 'DIGGING') {
            this.stateTimer -= dt;
            if(this.stateTimer <= 0) {
                this.hidden = false;
                this.state = 'IDLE';
                this.stateTimer = 1.0;
                this.trail = [];
                for(let i=0; i<30; i++) this.trail.push({x: this.x, y: this.y});
            }
        } else if (this.state === 'CHARGING') {
            const angle = Math.atan2(this.dashTarget.y - this.y, this.dashTarget.x - this.x);
            this.x += Math.cos(angle) * 750 * dt;
            this.y += Math.sin(angle) * 750 * dt;
            if (Math.random() < 0.4) {
                game.telegraphs.push(new Telegraph('circle', {x: this.x, y: this.y, r: 30}, 3.0, 15, null, '🟢'));
            }
            if (MathUtils.dist(this.x, this.y, this.dashTarget.x, this.dashTarget.y) < 20) {
                this.x = this.dashTarget.x;
                this.y = this.dashTarget.y;
                this.state = 'IDLE';
                this.stateTimer = 1.0;
            }
        }
    }

    pickAttack(player: any, game: any) {
        this.state = 'ATTACKING';
        this.stateTimer = 1.5;
        const r = Math.random();
        if (r < 0.2) this.attackPoisonBullets(game);
        else if (r < 0.4) this.attackDig(player, game);
        else if (r < 0.6) this.attackAcidRain(player, game);
        else if (r < 0.8) this.attackCharge(player, game);
        else this.attackVenomVolley(player, game);
    }

    attackVenomVolley(player: any, game: any) {
        for(let w = 0; w < 5; w++) {
            setTimeout(() => {
                if (this.hp <= 0 || game.state !== 'PLAYING' || game.room.boss !== this) return;
                const baseAngle = Math.atan2(player.y - this.y, player.x - this.x);
                for(let i = -2; i <= 2; i++) {
                    const angle = baseAngle + (i * 0.2) + (Math.random()*0.1 - 0.05);
                    const proj = new Projectile(this.x, this.y, angle, false, 'poison', 24);
                    game.projectiles.push(proj);
                }
            }, w * 250);
        }
        this.stateTimer = 1.0;
    }

    attackPoisonBullets(game: any) {
        for(let i=0; i<24; i++) {
            const angle = (i / 24) * Math.PI * 2;
            const proj = new Projectile(this.x, this.y, angle, false, 'poison', 22);
            game.projectiles.push(proj);
        }
    }

    attackDig(player: any, game: any) {
        this.hidden = true;
        this.state = 'DIGGING';
        this.stateTimer = 2.0;
        const targetX = player.x;
        const targetY = player.y;
        game.telegraphs.push(new Telegraph('circle', {x: targetX, y: targetY, r: 80}, 1.9, 55, () => {
            this.x = targetX;
            this.y = targetY;
        }, '💥'));
    }

    attackAcidRain(player: any, game: any) {
        for(let i=0; i<20; i++) {
            const bx = player.x + (Math.random() - 0.5) * 500;
            const by = player.y + (Math.random() - 0.5) * 500;
            game.telegraphs.push(new Telegraph('circle', {
                x: Math.max(30, Math.min(game.ROOM_SIZE-30, bx)), 
                y: Math.max(30, Math.min(game.ROOM_SIZE-30, by)), 
                r: 40
            }, 4.0, 28, null, '🟢'));
        }
    }

    attackCharge(player: any, game: any) {
        const dx = player.x - this.x;
        const dy = player.y - this.y;
        const len = Math.sqrt(dx*dx + dy*dy);
        const dashDist = 500;
        let endX = Math.max(this.radius, Math.min(game.ROOM_SIZE - this.radius, this.x + (dx/len) * dashDist));
        let endY = Math.max(this.radius, Math.min(game.ROOM_SIZE - this.radius, this.y + (dy/len) * dashDist));
        game.telegraphs.push(new Telegraph('line', {x1: this.x, y1: this.y, x2: endX, y2: endY, w: 60}, 1.0, 44, () => {
            this.state = 'CHARGING';
            this.dashTarget = {x: endX, y: endY};
        }, '🐍'));
        this.stateTimer = 1.0;
    }

    draw(ctx: CanvasRenderingContext2D, game: any = null) {
        if (this.hp <= 0 || this.hidden) return;
        super.draw(ctx, game);
        for(let i = this.trail.length - 1; i >= 0; i--) {
            let p = this.trail[i];
            let r = this.radius * (1 - (i/40));
            ctx.fillStyle = '#27ae60';
            ctx.beginPath(); ctx.arc(p.x, p.y, Math.max(5, r), 0, Math.PI*2); ctx.fill();
            ctx.strokeStyle = '#1e8449'; ctx.lineWidth = 2; ctx.stroke();
        }
        ctx.fillStyle = this.color;
        ctx.beginPath(); ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#000'; ctx.lineWidth = 3; ctx.stroke();
        let angle = 0;
        if (this.trail.length > 5) angle = Math.atan2(this.trail[0].y - this.trail[5].y, this.trail[0].x - this.trail[5].x);
        ctx.save(); ctx.translate(this.x, this.y); ctx.rotate(angle);
        ctx.strokeStyle = '#e74c3c'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(this.radius, 0); ctx.lineTo(this.radius + 15, 0); ctx.lineTo(this.radius + 20, -5); ctx.moveTo(this.radius + 15, 0); ctx.lineTo(this.radius + 20, 5); ctx.stroke();
        ctx.fillStyle = '#f1c40f'; ctx.beginPath(); ctx.arc(10, -12, 5, 0, Math.PI*2); ctx.fill(); ctx.beginPath(); ctx.arc(10, 12, 5, 0, Math.PI*2); ctx.fill();
        ctx.fillStyle = '#000'; ctx.fillRect(9, -15, 2, 6); ctx.fillRect(9, 9, 2, 6);
        ctx.restore();
    }
}

export class BombGolemBoss extends Boss {
    speed: number;

    constructor(x: number, y: number) {
        super("Bomb Golem", x, y, 2200, 45, '#34495e');
        this.speed = 85;
    }

    update(dt: number, player: any, game: any) {
        if (this.hp <= 0) return;
        if (this.state === 'IDLE') {
            const angle = Math.atan2(player.y - this.y, player.x - this.x);
            this.x += Math.cos(angle) * this.speed * dt;
            this.y += Math.sin(angle) * this.speed * dt;
            this.stateTimer -= dt;
            if (this.stateTimer <= 0) this.pickAttack(player, game);
        } else if (this.state === 'ATTACKING') {
            this.stateTimer -= dt;
            if (this.stateTimer <= 0) {
                this.state = 'IDLE';
                this.stateTimer = 0.2 + Math.random() * 0.2; 
            }
        }
    }

    pickAttack(player: any, game: any) {
        this.state = 'ATTACKING';
        this.stateTimer = 0.8; 
        const r = Math.random();
        if (r < 0.2) this.attackBombShower(game);
        else if (r < 0.4) this.attackBombThrow(player, game);
        else if (r < 0.6) this.attackLargeExplosion(game);
        else if (r < 0.8) this.attackBombRain(player, game);
        else this.attackBombLine(player, game);
    }

    attackBombLine(player: any, game: any) {
        const baseAngle = Math.atan2(player.y - this.y, player.x - this.x);
        for (let j = -1; j <= 1; j++) {
            const angle = baseAngle + (j * 0.3);
            const dx = Math.cos(angle);
            const dy = Math.sin(angle);
            for(let i = 1; i <= 6; i++) {
                game.telegraphs.push(new Telegraph('circle', {
                    x: this.x + dx * (i * 80), y: this.y + dy * (i * 80), r: 45
                }, 0.5 + (i * 0.1), 36, null, '💣'));
            }
        }
        this.stateTimer = 0.8;
    }

    attackBombShower(game: any) {
        for (let i = 0; i < 20; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = 50 + Math.random() * 250;
            game.telegraphs.push(new Telegraph('circle', {
                x: Math.max(30, Math.min(game.ROOM_SIZE-30, this.x + Math.cos(angle) * dist)),
                y: Math.max(30, Math.min(game.ROOM_SIZE-30, this.y + Math.sin(angle) * dist)),
                r: 45
            }, 0.6 + Math.random() * 0.5, 33, null, '💣'));
        }
    }

    attackBombThrow(player: any, game: any) {
        for(let i=-3; i<=3; i++) {
            const angle = Math.atan2(player.y - this.y, player.x - this.x) + (i * 0.2);
            const proj = new Projectile(this.x, this.y, angle, false, 'bomb', 17);
            proj.speed = 450;
            proj.vx = Math.cos(angle) * proj.speed;
            proj.vy = Math.sin(angle) * proj.speed;
            const ogUpdate = proj.update.bind(proj);
            proj.update = (dt: number, room: any, game: any) => {
                ogUpdate(dt, room, game);
                if (!proj.active) { 
                    game.telegraphs.push(new Telegraph('circle', { x: proj.x, y: proj.y, r: 70 }, 0.5, 44, null, '💥'));
                }
            };
            game.projectiles.push(proj);
        }
    }

    attackLargeExplosion(game: any) {
        game.telegraphs.push(new Telegraph('circle', { x: this.x, y: this.y, r: 240 }, 0.9, 55, null, '☢️'));
        this.stateTimer = 0.9;
    }

    attackBombRain(player: any, game: any) {
        for (let i = 0; i < 24; i++) {
            const bx = player.x + (Math.random() - 0.5) * 400;
            const by = player.y + (Math.random() - 0.5) * 400;
            game.telegraphs.push(new Telegraph('circle', {
                x: Math.max(30, Math.min(game.ROOM_SIZE-30, bx)), 
                y: Math.max(30, Math.min(game.ROOM_SIZE-30, by)), 
                r: 45
            }, 0.3 + (i * 0.08), 33, null, '💣'));
        }
        this.stateTimer = 0.8;
    }
    
    draw(ctx: CanvasRenderingContext2D, game: any = null) {
        if (this.hp <= 0) return;
        super.draw(ctx, game);
        ctx.fillStyle = this.color;
        ctx.save(); ctx.translate(this.x, this.y);
        ctx.beginPath();
        for (let i = 0; i < 6; i++) {
            const angle = (i * Math.PI) / 3;
            const px = Math.cos(angle) * this.radius;
            const py = Math.sin(angle) * this.radius;
            if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
        }
        ctx.closePath(); ctx.fill();
        ctx.strokeStyle = '#2c3e50'; ctx.lineWidth = 4; ctx.stroke();
        ctx.fillStyle = '#2c3e50'; ctx.beginPath(); ctx.arc(0, 0, this.radius * 0.6, 0, Math.PI*2); ctx.fill();
        let fuseAngle = (performance.now() / 200) % (Math.PI * 2);
        let fx = Math.cos(fuseAngle) * this.radius * 0.8;
        let fy = Math.sin(fuseAngle) * this.radius * 0.8;
        ctx.fillStyle = '#e74c3c'; ctx.beginPath(); ctx.arc(fx, fy, 8, 0, Math.PI*2); ctx.fill();
        ctx.fillStyle = '#f1c40f'; ctx.beginPath(); ctx.arc(fx, fy, 4, 0, Math.PI*2); ctx.fill();
        ctx.strokeStyle = '#bdc3c7'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(fx, fy); ctx.stroke();
        ctx.restore();
    }
}
