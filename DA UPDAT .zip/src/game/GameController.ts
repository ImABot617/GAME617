import { Particle } from './Particle';
import { Player } from './Player';
import { Room } from './Room';
import { MathUtils } from './MathUtils';
import { TutorialDirector, RobotBoss, GolemBoss, DragonBoss } from './Bosses';
import { NagaBoss, BombGolemBoss } from './Bosses2';
import { SamuraiBoss, AdminBoss } from './Bosses3';
import { LabCoreBoss, TrueAdminBoss } from './Bosses4';

export class GameController {
    telegraphs: any[];
    projectiles: any[];
    hazards: any[];
    particles: Particle[];
    collectibles: any[];
    roomIndex: number;
    rooms: any[];
    ROOM_SIZE: number;
    player: Player;
    room: Room;
    lastTime: number;
    state: string;
    runDamaged: boolean;
    runGlitched: boolean;
    isGlitchModalOpen: boolean;
    pendingUpgrades: number;
    dialogueActive: boolean;
    dialogueQueue: any[];
    dialogueCallback: (() => void) | null;
    act1Completions: number;
    achievements: any;
    unlockAchievement: (id: string) => void;
    showHitboxes: boolean;

    constructor(achievements: any, unlockAchievement: (id: string) => void, act1Completions: number) {
        this.telegraphs = [];
        this.projectiles = [];
        this.hazards = [];
        this.particles = [];
        this.collectibles = [];
        this.roomIndex = 0;
        this.rooms = [TutorialDirector, RobotBoss, GolemBoss, DragonBoss, NagaBoss, BombGolemBoss, SamuraiBoss, AdminBoss, LabCoreBoss, TrueAdminBoss, null]; 
        this.ROOM_SIZE = 600;
        this.setupRoomSize();
        this.player = new Player(this.ROOM_SIZE/2, this.ROOM_SIZE - 50);
        this.room = new Room(this.rooms[this.roomIndex], this.ROOM_SIZE);
        this.lastTime = performance.now();
        this.state = 'MENU';
        this.runDamaged = false;
        this.runGlitched = false;
        this.isGlitchModalOpen = false;
        this.pendingUpgrades = 0;
        this.dialogueActive = false;
        this.dialogueQueue = [];
        this.dialogueCallback = null;
        this.achievements = achievements;
        this.unlockAchievement = unlockAchievement;
        this.act1Completions = act1Completions;
        this.showHitboxes = false;
    }

    spawnParticles(x: number, y: number, color: string, count: number, speed: number, life: number, size: number) {
        for (let i = 0; i < count; i++) {
            this.particles.push(new Particle(x, y, color, speed, life, size));
        }
    }

    getRoomDialogue(index: number) {
        switch(index) {
            case 0: return [{speaker: 'Player', text: 'Something feels off...'}];
            case 1: return [
                {speaker: 'The Admin', text: 'Applying final patches to the Sentinel...'},
                {speaker: 'Player', text: 'Shutting you down, Admin!'},
                {speaker: 'The Admin', text: 'A minor glitch. Sentinel, erase them.'}
            ];
            case 2: return [{speaker: 'Player', text: "A giant rock monster. Time to make some gravel."}];
            case 3: return [{speaker: 'Player', text: 'A dragon? In a mainframe?'}];
            case 4: return [{speaker: 'Player', text: 'Venomous. I need to keep my distance.'}];
            case 5: return [{speaker: 'Player', text: "Walking ordnance. One wrong move and I'm done."}];
            case 6: return [{speaker: 'Player', text: 'Fast. I need to watch their blade.'}];
            case 7: return [
                {speaker: 'Player', text: 'Where are they?!'},
                {speaker: 'The Admin', text: 'Welcome to the core.'},
                {speaker: 'The Admin', text: "I've been monitoring your progress..."},
                {speaker: 'The Admin', text: "But your search ends here."},
                {speaker: 'The Admin', text: "You will be deleted."},
                {speaker: 'Player', text: "We'll see about that."}
            ];
            case 8: return [
                {speaker: 'Player', text: 'The main laboratory. They have to be here.'},
                {speaker: 'Lab Core', text: 'UNAUTHORIZED ACCESS. INITIATING PURGE.'}
            ];
            case 9: return [
                {speaker: 'The Admin (True Form)', text: 'YOU SURVIVED.'},
                {speaker: 'The Admin (True Form)', text: 'BUT I AM NO LONGER CONSTRAINED BY THAT SHELL.'},
                {speaker: 'The Admin (True Form)', text: 'THIS IS MY REALM. I AM THE CODE.'},
                {speaker: 'The Admin (True Form)', text: 'EVERY PIXEL, EVERY BIT... IT ALL OBEYS ME.'},
                {speaker: 'Player', text: 'Then I guess I just have to delete the source code.'},
                {speaker: 'The Admin (True Form)', text: 'TRY IT. I WILL OVERWRITE YOUR VERY EXISTENCE.'}
            ];
            default: return [];
        }
    }

    playDialogue(lines: any[], onComplete: (() => void) | null = null) {
        this.dialogueQueue = [...lines];
        this.dialogueCallback = onComplete;
        this.dialogueActive = true;
        this.advanceDialogue();
    }

    getSpeakerColor(speaker: string) {
        if (speaker === 'Player') return '#3498db';
        if (speaker === 'Friend') return '#ffb8b8';
        if (speaker === 'The Admin (Phase 2)' || speaker === 'The Admin (True Form)') return '#ff0000';
        if (speaker.includes('Admin')) return '#00ff00';
        if (speaker === 'System' || speaker === 'Lab Core') return '#f1c40f';
        if (speaker === 'Mysterious Person') return '#8e44ad';
        return '#fff';
    }

    advanceDialogue() {
        if (this.dialogueQueue.length > 0) {
            const line = this.dialogueQueue.shift();
            const box = document.getElementById('dialogue-container');
            const speakerElem = document.getElementById('dialogue-speaker');
            const textElem = document.getElementById('dialogue-text');
            
            if (speakerElem) {
                speakerElem.innerText = line.speaker;
                speakerElem.style.color = this.getSpeakerColor(line.speaker);
            }
            if (textElem) textElem.innerText = line.text;
            if (box) box.classList.remove('hidden');
        } else {
            document.getElementById('dialogue-container')?.classList.add('hidden');
            this.dialogueActive = false;
            if (this.dialogueCallback) this.dialogueCallback();
        }
    }

    setupRoomSize() {
        if (this.rooms[this.roomIndex] === RobotBoss || this.rooms[this.roomIndex] === LabCoreBoss) {
            this.ROOM_SIZE = 800;
        } else if (this.rooms[this.roomIndex] === AdminBoss || this.rooms[this.roomIndex] === TrueAdminBoss) {
            this.ROOM_SIZE = 1000;
        } else {
            this.ROOM_SIZE = 600;
        }
        const canvas = document.getElementById('gameCanvas') as HTMLCanvasElement;
        if (canvas) {
            canvas.width = this.ROOM_SIZE;
            canvas.height = this.ROOM_SIZE;
        }
    }

    start() {
        document.getElementById('overlay')?.classList.add('hidden');
        document.getElementById('achievements-btn')?.classList.add('hidden');
        document.getElementById('fake-ad')?.classList.add('hidden');
        this.player.hasWeapon = false;
        this.collectibles = [];
        this.state = 'PLAYING';
        if ((this as any).onStateChange) (this as any).onStateChange('PLAYING');
        this.lastTime = performance.now();
        const introLines = this.getRoomDialogue(this.roomIndex);
        if (introLines.length > 0) this.playDialogue(introLines);
    }

    startBonusRoom() {
        document.getElementById('overlay')?.classList.add('hidden');
        document.getElementById('achievements-btn')?.classList.add('hidden');
        document.getElementById('fake-ad')?.classList.add('hidden');
        this.roomIndex = 9;
        this.setupRoomSize();
        this.room = new Room(this.rooms[this.roomIndex], this.ROOM_SIZE);
        this.player.maxHp = 2500;
        this.player.hp = 2500;
        this.player.speed = 350;
        this.player.baseDamage = 50;
        this.player.weapon = 'god_gun';
        this.player.fireRate = 0.05;
        this.player.hasWeapon = true;
        this.player.x = this.ROOM_SIZE/2;
        this.player.y = this.ROOM_SIZE - 50;
        this.telegraphs = [];
        this.projectiles = [];
        this.hazards = [];
        this.particles = [];
        this.collectibles = [];
        this.state = 'PLAYING';
        if ((this as any).onStateChange) (this as any).onStateChange('PLAYING');
        document.getElementById('boss-health')?.classList.remove('hidden');
        this.player.takeDamage(0);
        this.lastTime = performance.now();
        const introLines = this.getRoomDialogue(this.roomIndex);
        if (introLines.length > 0) this.playDialogue(introLines);
    }

    restartCurrentRoom() {
        document.getElementById('fake-ad')?.classList.add('hidden');
        this.setupRoomSize();
        this.room = new Room(this.rooms[this.roomIndex], this.ROOM_SIZE);
        this.player.hp = this.player.maxHp / 2;
        this.player.x = this.ROOM_SIZE/2;
        this.player.y = this.ROOM_SIZE - 50;
        this.player.hasWeapon = (this.roomIndex > 0);
        if (this.roomIndex === 9) {
            this.player.maxHp = 2500; this.player.hp = 2500;
            this.player.speed = 350; this.player.baseDamage = 50;
            this.player.weapon = 'god_gun'; this.player.fireRate = 0.05;
            this.player.hasWeapon = true;
        }
        this.telegraphs = [];
        this.projectiles = [];
        this.hazards = [];
        this.particles = [];
        this.collectibles = [];
        this.state = 'PLAYING';
        if ((this as any).onStateChange) (this as any).onStateChange('PLAYING');
        document.getElementById('overlay')?.classList.add('hidden');
        document.getElementById('boss-health')?.classList.remove('hidden');
        this.player.takeDamage(0);
        this.lastTime = performance.now();
        const introLines = this.getRoomDialogue(this.roomIndex);
        if (introLines.length > 0) this.playDialogue(introLines);
    }

    roomCleared() {
        this.telegraphs = [];
        this.projectiles = [];
        this.hazards = [];
        this.collectibles = [];
        this.room.cleared = true;
        if (this.player) {
            this.player.shards += 100;
            if ((this as any).onShardsChange) (this as any).onShardsChange(this.player.shards);
            console.log("Awarded 100 shards! Total: " + this.player.shards);
        }
        if (this.rooms[this.roomIndex] === RobotBoss) this.unlockAchievement('first_blood');
    }

    showUpgrades() {
        this.state = 'UPGRADE';
        if ((this as any).onStateChange) (this as any).onStateChange('UPGRADE');
        const screen = document.getElementById('upgrade-screen');
        if (screen) screen.classList.remove('hidden');
    }

    applyUpgrade(type: string) {
        if (type === 'hp') {
            this.player.maxHp += 50;
            this.player.hp = this.player.maxHp;
        } else if (type === 'dmg') {
            this.player.baseDamage += 5;
        } else if (type === 'spd') {
            this.player.speed *= 1.15;
        } else if (type === 'firerate') {
            this.player.fireRate *= 0.8;
        } else if (['shotgun', 'minigun', 'laser', 'rocket'].includes(type)) {
            this.player.weapon = type;
        }
        this.player.takeDamage(0);
        this.pendingUpgrades--;
        if (this.pendingUpgrades > 0) {
            this.showUpgrades();
        } else {
            document.getElementById('upgrade-screen')?.classList.add('hidden');
            if (this.room.cleared) {
                this.nextRoom();
            } else {
                this.state = 'PLAYING';
                if ((this as any).onStateChange) (this as any).onStateChange('PLAYING');
                this.lastTime = performance.now();
            }
        }
    }

    nextRoom() {
        this.roomIndex++;
        if (this.rooms[this.roomIndex]) {
            this.setupRoomSize();
            this.room = new Room(this.rooms[this.roomIndex], this.ROOM_SIZE);
            this.player.x = this.ROOM_SIZE/2;
            this.player.y = this.ROOM_SIZE - 50;
            this.state = 'PLAYING';
            if ((this as any).onStateChange) (this as any).onStateChange('PLAYING');
            this.lastTime = performance.now();
            const introLines = this.getRoomDialogue(this.roomIndex);
            if (introLines.length > 0) this.playDialogue(introLines);
        }
    }

    gameOver(won: boolean, source: string | null = null) {
        this.state = won ? 'WIN' : 'GAMEOVER';
        if ((this as any).onStateChange) (this as any).onStateChange(this.state);
        const overlay = document.getElementById('overlay');
        const title = document.getElementById('overlay-title');
        const desc = document.getElementById('overlay-desc');
        const btn = document.getElementById('start-btn');
        
        if (overlay) overlay.classList.remove('hidden');
        if (title) title.innerText = won ? "Victory!" : "You Died";
        if (desc) desc.innerText = won ? "You defeated all the bosses!" : "You will respawn at the start of the current room.";
        if (btn) btn.innerText = "Restart Checkpoint";
        
        document.getElementById('boss-health')?.classList.add('hidden');
        document.getElementById('achievements-btn')?.classList.remove('hidden');

        if (!won) {
            if (this.room.boss instanceof GolemBoss) this.unlockAchievement('dumber_than_a_rock');
            if (source === 'wall') this.unlockAchievement('wall_hugger');
            if (source === 'spike') this.unlockAchievement('spiked');
        }
    }

    gameWin() {
        if (this.roomIndex === 8) {
            this.unlockAchievement('god_slayer');
            this.act1Completions++;
            const compCount = document.getElementById('comp-count');
            if (compCount) compCount.innerText = this.act1Completions.toString();
        }
        if (!this.runDamaged && !this.runGlitched) {
            this.unlockAchievement('admins_vanguard');
        }
        this.gameOver(true);
    }

    loop(currentTime: number, keys: any, mouse: any) {
        // Update Debug Info
        const debugInfo = document.getElementById('debug-info');
        if (debugInfo) {
            debugInfo.innerText = `HP: ${Math.round(this.player.hp)}/${this.player.maxHp} | Room: ${this.roomIndex} | State: ${this.state} | i-Frames: ${this.player.dashTime > 0 ? 'YES' : 'NO'}`;
        }

        const dt = Math.min((currentTime - this.lastTime) / 1000, 0.1);
        this.lastTime = currentTime;

        if (this.state === 'PLAYING' && !this.dialogueActive && !this.isGlitchModalOpen) {
            this.player.update(dt, this.room, this, keys, mouse);
            if (this.room.boss) this.room.boss.update(dt, this.player, this);

            if (this.room.cleared && MathUtils.dist(this.player.x, this.player.y, this.ROOM_SIZE/2, this.ROOM_SIZE/2) < 40) {
                if (this.roomIndex === 8) {
                    this.gameWin();
                } else if (this.roomIndex === 9) {
                    this.unlockAchievement('true_god_slayer');
                    this.gameWin();
                } else if (this.roomIndex < this.rooms.length - 2) {
                    this.pendingUpgrades = (this.roomIndex === 4) ? 2 : 1;
                    this.showUpgrades();
                    this.player.x = 0;
                }
            }

            this.telegraphs = this.telegraphs.filter(t => !t.update(dt, this.player));
            this.projectiles.forEach(p => p.update(dt, this.room, this));
            this.projectiles = this.projectiles.filter(p => p.active);
            this.hazards = this.hazards.filter(h => h.update(dt, this.player));
            this.collectibles = this.collectibles.filter(c => c.update(dt, this.player, this));
            this.particles.forEach(p => p.update(dt));
            this.particles = this.particles.filter(p => p.life > 0);

            if (this.room.dollar && !this.room.dollar.collected) {
                if (MathUtils.circleRectCollide(this.player.x, this.player.y, this.player.radius, this.room.dollar.x, this.room.dollar.y, this.room.dollar.w, this.room.dollar.h)) {
                    this.room.dollar.collected = true;
                    this.unlockAchievement('found_a_dollar');
                }
            }
        }

        const canvas = document.getElementById('gameCanvas') as HTMLCanvasElement;
        const ctx = canvas?.getContext('2d');
        if (ctx) {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            this.room.draw(ctx);
            this.collectibles.forEach(c => c.draw(ctx));
            this.hazards.forEach(h => h.draw(ctx));
            this.telegraphs.forEach(t => t.draw(ctx));
            if (this.room.boss) this.room.boss.draw(ctx, this);
            this.projectiles.forEach(p => p.draw(ctx, this));
            this.particles.forEach(p => p.draw(ctx));
            this.player.draw(ctx, mouse, this);
        }
    }
}
