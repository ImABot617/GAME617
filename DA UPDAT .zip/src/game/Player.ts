import { MathUtils } from './MathUtils';
import { Projectile } from './Projectile';

export class Player {
    x: number;
    y: number;
    radius: number;
    speed: number;
    maxHp: number;
    hp: number;
    fireCooldown: number;
    fireRate: number;
    baseDamage: number;
    weapon: string;
    hasWeapon: boolean;
    dashCooldown: number;
    dashTime: number;
    dashDir: {x: number, y: number};
    meleeCooldown: number;
    spikeCooldown: number;
    speedBuffTimer: number;
    speedMultiplier: number;
    isInvincible: boolean;
    combo: number;
    comboTimer: number;
    medkits: number;
    shards: number;
    skin: string;
    parryTime: number;
    parryCooldown: number;

    constructor(x: number, y: number) {
        this.x = x;
        this.y = y;
        this.radius = 12;
        this.speed = 200;
        this.maxHp = 200;
        this.hp = this.maxHp;
        this.fireCooldown = 0;
        this.fireRate = 0.25;
        this.baseDamage = 5;
        this.weapon = 'default';
        this.hasWeapon = false;
        this.dashCooldown = 0;
        this.dashTime = 0;
        this.dashDir = {x: 0, y: 0};
        this.meleeCooldown = 0;
        this.spikeCooldown = 0;
        this.speedBuffTimer = 0;
        this.speedMultiplier = 1;
        this.isInvincible = false;
        this.combo = 0;
        this.comboTimer = 0;
        this.medkits = 0;
        this.shards = 0;
        this.skin = 'default';
        this.parryTime = 0;
        this.parryCooldown = 0;
    }

    update(dt: number, room: any, game: any, keys: any, mouse: any) {
        if (this.dashCooldown > 0) this.dashCooldown -= dt;
        if (this.dashTime > 0) this.dashTime -= dt;
        if (this.parryTime > 0) this.parryTime -= dt;
        if (this.parryCooldown > 0) this.parryCooldown -= dt;

        if (keys[' '] && this.parryCooldown <= 0 && this.dashTime <= 0) {
            this.parryTime = 0.25;
            this.parryCooldown = 1.5;
            if (game) game.spawnParticles(this.x, this.y, '#ffffff', 15, 120, 0.3, 3);
        }

        this.meleeCooldown -= dt;
        this.fireCooldown -= dt;
        this.spikeCooldown -= dt;
        if (this.speedBuffTimer > 0) this.speedBuffTimer -= dt;

        if (this.comboTimer > 0) {
            this.comboTimer -= dt;
            if (this.comboTimer <= 0) this.combo = 0;
        }

        // Death check
        if (this.hp <= 0 && game && game.state === 'PLAYING') {
            console.log("Player died (HP <= 0 in update)");
            game.gameOver(false);
        }

        this.isInvincible = this.dashTime > 0;

        if (!(window as any).stackBugEnabled && this.fireCooldown < 0) {
            this.fireCooldown = 0;
        }

        let dx = 0; let dy = 0;

        if (this.dashTime > 0) {
            dx = this.dashDir.x;
            dy = this.dashDir.y;
            this.speedMultiplier = 3.5;
            if (game) game.spawnParticles(this.x, this.y, '#3498db', 1, 20, 0.2, 4);
        } else {
            this.speedMultiplier = 1;
            if (keys.w) dy -= 1;
            if (keys.s) dy += 1;
            if (keys.a) dx -= 1;
            if (keys.d) dx += 1;

            if (dx !== 0 && dy !== 0) {
                const length = Math.sqrt(dx * dx + dy * dy);
                dx /= length; dy /= length;
            }

            if (this.hasWeapon && keys[' '] && this.dashCooldown <= 0 && (dx !== 0 || dy !== 0)) {
                this.dashCooldown = 1.5;
                this.dashTime = 0.15;
                this.dashDir = {x: dx, y: dy};
            }
        }

        let activeSpeed = this.speed;
        if (game && game.roomIndex === 7) activeSpeed *= 1.5;
        else if (game && game.roomIndex === 8) activeSpeed *= 1.3;
        
        if (this.speedBuffTimer > 0) activeSpeed *= 1.6;

        let nextX = this.x + dx * (activeSpeed * this.speedMultiplier) * dt;
        let nextY = this.y + dy * (activeSpeed * this.speedMultiplier) * dt;

        nextX = Math.max(this.radius, Math.min(game.ROOM_SIZE - this.radius, nextX));
        nextY = Math.max(this.radius, Math.min(game.ROOM_SIZE - this.radius, nextY));

        let canMoveX = true;
        let canMoveY = true;

        for (const wall of room.walls) {
            if (MathUtils.circleRectCollide(nextX, this.y, this.radius, wall.x, wall.y, wall.w, wall.h)) canMoveX = false;
            if (MathUtils.circleRectCollide(this.x, nextY, this.radius, wall.x, wall.y, wall.w, wall.h)) canMoveY = false;
        }
        for (const pillar of room.pillars) {
            if (MathUtils.dist(nextX, this.y, pillar.x, pillar.y) < this.radius + pillar.r) canMoveX = false;
            if (MathUtils.dist(this.x, nextY, pillar.x, pillar.y) < this.radius + pillar.r) canMoveY = false;
        }
        for (const spike of room.spikes) {
            if (MathUtils.dist(nextX, this.y, spike.x, spike.y) < this.radius + spike.r) canMoveX = false;
            if (MathUtils.dist(this.x, nextY, spike.x, spike.y) < this.radius + spike.r) canMoveY = false;

            if (MathUtils.dist(this.x, this.y, spike.x, spike.y) < this.radius + spike.r + 2) {
                if (this.spikeCooldown <= 0) {
                    this.takeDamage(15, 'spike', game);
                    this.spikeCooldown = 1.0;
                }
            }
        }

        if (canMoveX) this.x = nextX;
        if (canMoveY) this.y = nextY;

        if (this.hasWeapon) {
            if (mouse.down) {
                let actualFireRate = this.fireRate;
                if (this.weapon === 'minigun') actualFireRate *= 0.3;
                else if (this.weapon === 'shotgun') actualFireRate *= 1.5;
                else if (this.weapon === 'rocket') actualFireRate *= 2.0;
                else if (this.weapon === 'laser') actualFireRate = 0.005;
                else if (this.weapon === 'god_gun') actualFireRate = 0.05;

                if (this.fireCooldown <= 0) {
                    let shotsFired = 0;
                    let maxShots = (window as any).stackBugEnabled ? 50 : 10;
                    
                    while (this.fireCooldown <= 0 && shotsFired < maxShots) {
                        shotsFired++;
                        this.fireCooldown += actualFireRate;
                        const angle = Math.atan2(mouse.y - this.y, mouse.x - this.x);

                        if (game && this.weapon !== 'laser' && this.weapon !== 'god_gun') {
                            const barrelX = this.x + Math.cos(angle) * 15;
                            const barrelY = this.y + Math.sin(angle) * 15;
                            game.spawnParticles(barrelX, barrelY, '#f1c40f', 2, 80, 0.15, 2);
                        }

                        if (this.weapon === 'shotgun') {
                            for (let i = -2; i <= 2; i++) {
                                const spreadAngle = angle + (i * 0.15);
                                game.projectiles.push(new Projectile(this.x, this.y, spreadAngle, true, 'magic', this.baseDamage));
                            }
                        } else if (this.weapon === 'minigun') {
                            const spreadAngle = angle + (Math.random() - 0.5) * 0.2;
                            game.projectiles.push(new Projectile(this.x, this.y, spreadAngle, true, 'magic', this.baseDamage * 0.7));
                        } else if (this.weapon === 'laser') {
                            const proj = new Projectile(this.x, this.y, angle, true, 'player_laser', this.baseDamage * 0.5); 
                            proj.speed = 1500;
                            proj.vx = Math.cos(angle) * proj.speed;
                            proj.vy = Math.sin(angle) * proj.speed;
                            proj.maxRange = 600;
                            game.projectiles.push(proj);
                        } else if (this.weapon === 'rocket') {
                            const proj = new Projectile(this.x, this.y, angle, true, 'rocket', this.baseDamage);
                            proj.speed = 500;
                            proj.vx = Math.cos(angle) * proj.speed;
                            proj.vy = Math.sin(angle) * proj.speed;
                            proj.maxRange = 600;
                            game.projectiles.push(proj);
                        } else if (this.weapon === 'god_gun') {
                            const projL = new Projectile(this.x, this.y, angle, true, 'player_laser', this.baseDamage); 
                            projL.speed = 2000; projL.vx = Math.cos(angle) * projL.speed; projL.vy = Math.sin(angle) * projL.speed;
                            projL.maxRange = 1200;
                            game.projectiles.push(projL);

                            for(let i of [-1, 1]) {
                                const spread = angle + i * 0.4;
                                const projR = new Projectile(this.x, this.y, spread, true, 'magic', this.baseDamage * 2);
                                projR.speed = 700; projR.vx = Math.cos(spread) * projR.speed; projR.vy = Math.sin(spread) * projR.speed;
                                projR.homingTarget = room.boss;
                                game.projectiles.push(projR);
                            }
                        } else {
                            game.projectiles.push(new Projectile(this.x, this.y, angle, true, 'magic', this.baseDamage));
                        }
                    }
                    if (this.fireCooldown < 0 && !(window as any).stackBugEnabled) this.fireCooldown = 0;
                }
            }

            if (mouse.rightDown && this.meleeCooldown <= 0) {
                this.meleeCooldown = 0.6;
                const angle = Math.atan2(mouse.y - this.y, mouse.x - this.x);
                game.projectiles.push(new Projectile(this.x, this.y, angle, true, 'melee', this.baseDamage * 3));
            }
        }
    }

    takeDamage(amount: number, source: string | null = null, game: any = null) {
        if (this.isInvincible) {
            if (game) game.spawnParticles(this.x, this.y, '#ffffff', 5, 100, 0.2, 2);
            return;
        }

        const damageAmount = Number(amount);
        if (isNaN(damageAmount) || !isFinite(damageAmount)) {
            console.error("Invalid damage amount received:", amount);
            return;
        }

        if (damageAmount > 0) {
            if (game) {
                game.runDamaged = true;
                game.spawnParticles(this.x, this.y, '#e74c3c', 10, 150, 0.3, 3);
            }
            this.combo = 0;
            this.comboTimer = 0;
            
            // Log damage for debugging
            console.log(`Player took ${damageAmount} damage from ${source || 'unknown'}. HP: ${this.hp} -> ${this.hp - damageAmount}`);
        }

        this.hp -= damageAmount;
        
        // Robust HP bounds and NaN safety
        if (isNaN(this.hp) || !isFinite(this.hp)) {
            console.error("Player HP became invalid! Resetting to 0.");
            this.hp = 0;
        }
        
        if (this.hp < 0) this.hp = 0;
        if (this.hp > this.maxHp) this.hp = this.maxHp;

        const hpFill = document.getElementById('player-health-fill');
        if (hpFill) hpFill.style.width = `${(this.hp / this.maxHp) * 100}%`;
        
        if (this.hp <= 0 && game && game.state === 'PLAYING') {
            game.gameOver(false, source);
        }
    }

    getDamageMultiplier() {
        return 1.0 + (this.combo * 0.05);
    }

    draw(ctx: CanvasRenderingContext2D, mouse: any, game: any = null) {
        if (this.parryTime > 0) {
            ctx.strokeStyle = '#fff';
            ctx.lineWidth = 4;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius + 10, 0, Math.PI * 2);
            ctx.stroke();
            
            ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
            ctx.fill();
        }

        if (this.dashTime > 0) {
            ctx.fillStyle = 'rgba(52, 152, 219, 0.4)';
            ctx.beginPath(); ctx.arc(this.x - this.dashDir.x * 15, this.y - this.dashDir.y * 15, this.radius, 0, Math.PI * 2); ctx.fill();
            ctx.globalAlpha = 0.5;
        }

        let bodyColor = '#3498db';
        let strokeColor = '#2980b9';

        if (this.skin === 'glitch') {
            bodyColor = Math.random() > 0.5 ? '#ff00ff' : '#00ffff';
            strokeColor = '#fff';
        } else if (this.skin === 'gold') {
            bodyColor = '#f1c40f';
            strokeColor = '#f39c12';
        } else if (this.skin === 'crimson') {
            bodyColor = '#e74c3c';
            strokeColor = '#c0392b';
        }

        ctx.fillStyle = bodyColor;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = 2;
        ctx.stroke();

        if (this.skin === 'glitch') {
            for(let i=0; i<3; i++) {
                ctx.fillStyle = '#fff';
                ctx.fillRect(this.x + (Math.random()-0.5)*20, this.y + (Math.random()-0.5)*20, 4, 4);
            }
        }

        ctx.globalAlpha = 1.0;

        // Draw Hitbox for Debugging
        if (game && game.showHitboxes) {
            ctx.strokeStyle = '#00ff00';
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
            ctx.stroke();
        }

        if (this.hasWeapon) {
            const angle = Math.atan2(mouse.y - this.y, mouse.x - this.x);
            
            // Draw Aimer Line for Debugging
            if (game && game.showHitboxes) {
                ctx.save();
                ctx.setLineDash([5, 5]);
                ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)';
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.moveTo(this.x, this.y);
                ctx.lineTo(this.x + Math.cos(angle) * 1000, this.y + Math.sin(angle) * 1000);
                ctx.stroke();
                ctx.restore();
            }

            ctx.beginPath();
            ctx.moveTo(this.x, this.y);
            const aimDist = 25;
            ctx.lineTo(this.x + Math.cos(angle) * aimDist, this.y + Math.sin(angle) * aimDist);
            ctx.strokeStyle = '#fff';
            ctx.lineWidth = 2;
            ctx.stroke();
        }
    }
}
