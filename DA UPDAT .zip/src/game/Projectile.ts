import { MathUtils } from './MathUtils';
import { Telegraph } from './Telegraph';

export class Projectile {
    x: number;
    y: number;
    vx: number;
    vy: number;
    radius: number;
    isPlayer: boolean;
    active: boolean;
    damage: number;
    type: string;
    hitCooldown: number;
    distanceTraveled: number;
    maxRange: number;
    speed: number;
    homingTarget: any;
    lifetime: number;

    constructor(x: number, y: number, angle: number, isPlayer = true, type = 'default', damage = 5) {
        this.x = x;
        this.y = y;
        this.vx = Math.cos(angle) * 400;
        this.vy = Math.sin(angle) * 400;
        this.radius = 5;
        this.isPlayer = isPlayer;
        this.active = true;
        this.damage = damage;
        this.type = type;
        this.hitCooldown = 0;
        this.distanceTraveled = 0;
        this.maxRange = isPlayer ? 800 : Infinity; 
        this.homingTarget = null;
        this.lifetime = Infinity;

        if (this.type === 'poison') {
            this.vx = Math.cos(angle) * 200;
            this.vy = Math.sin(angle) * 200;
            this.radius = 6;
        } else if (this.type === 'earth') {
            this.vx = Math.cos(angle) * 150;
            this.vy = Math.sin(angle) * 150;
            this.radius = 8;
        } else if (this.type === 'bomb') {
            this.vx = Math.cos(angle) * 250;
            this.vy = Math.sin(angle) * 250;
            this.radius = 8;
        } else if (this.type === 'melee') {
            this.vx = Math.cos(angle) * 500;
            this.vy = Math.sin(angle) * 500;
            this.radius = 28;
            this.maxRange = 70;
        } else if (this.type === 'gear') {
            this.vx = Math.cos(angle) * 180;
            this.vy = Math.sin(angle) * 180;
            this.radius = 18;
            this.lifetime = 4.0;
        } else if (this.type === 'slash') {
            this.vx = Math.cos(angle) * 550;
            this.vy = Math.sin(angle) * 550;
            this.radius = 20;
            this.maxRange = Infinity;
        }

        this.speed = Math.sqrt(this.vx * this.vx + this.vy * this.vy);
    }

    explode(room: any, game: any) {
        let radius = 90;
        let dmgMult = 6;
        
        const t = new Telegraph('circle', {x: this.x, y: this.y, r: radius}, 0.2, 0, null, '💥');
        t.resolved = true; 
        game.telegraphs.push(t);
        
        if (game) game.spawnParticles(this.x, this.y, '#e67e22', 30, 300, 0.6, 5);
        
        if (room.boss && room.boss.hp > 0) {
            if (MathUtils.dist(this.x, this.y, room.boss.x, room.boss.y) <= radius + room.boss.radius) {
                room.boss.takeDamage(this.damage * dmgMult);
            }
        }
    }

    update(dt: number, room: any, game: any) {
        if (this.lifetime !== Infinity) {
            this.lifetime -= dt;
            if (this.lifetime <= 0) {
                this.active = false;
                return;
            }
        }

        if (this.hitCooldown > 0) {
            this.hitCooldown -= dt;
        }

        if (this.type === 'gear' && this.lifetime < 2.5) {
            if (room.boss && room.boss.hp > 0) {
                const angle = Math.atan2(room.boss.y - this.y, room.boss.x - this.x);
                this.vx = Math.cos(angle) * 250;
                this.vy = Math.sin(angle) * 250;
                if (MathUtils.dist(this.x, this.y, room.boss.x, room.boss.y) < 30) this.active = false;
            }
        }

        if (this.homingTarget && this.homingTarget.hp > 0) {
            const angleToTarget = Math.atan2(this.homingTarget.y - this.y, this.homingTarget.x - this.x);
            const currentAngle = Math.atan2(this.vy, this.vx);
            const turnRate = this.type === 'special_missile' ? 1.5 : 2.5;
            let diff = angleToTarget - currentAngle;
            while (diff < -Math.PI) diff += Math.PI * 2;
            while (diff > Math.PI) diff -= Math.PI * 2;
            const newAngle = currentAngle + Math.sign(diff) * Math.min(Math.abs(diff), turnRate * dt);
            this.vx = Math.cos(newAngle) * this.speed;
            this.vy = Math.sin(newAngle) * this.speed;
        }
        
        const dx = this.vx * dt;
        const dy = this.vy * dt;
        this.x += dx;
        this.y += dy;
        this.distanceTraveled += Math.sqrt(dx*dx + dy*dy);

        if (this.distanceTraveled >= this.maxRange) {
            if (this.type === 'rocket') this.explode(room, game);
            this.active = false;
            return;
        }

        if (this.x < 0 || this.x > game.ROOM_SIZE || this.y < 0 || this.y > game.ROOM_SIZE) {
            if (this.type === 'rocket') this.explode(room, game);
            if (this.type !== 'gear') {
                this.active = false;
                if (game) game.spawnParticles(this.x, this.y, '#95a5a6', 3, 40, 0.2, 2);
            }
            return;
        }

        if (this.type !== 'gear' && this.type !== 'melee' && this.type !== 'player_laser' && this.type !== 'special_missile') {
            let hitWall = false;
            for (const wall of room.walls) {
                if (this.x > wall.x && this.x < wall.x + wall.w && this.y > wall.y && this.y < wall.y + wall.h) {
                    hitWall = true; break;
                }
            }
            if (!hitWall) {
                for (const pillar of room.pillars) {
                    if (MathUtils.dist(this.x, this.y, pillar.x, pillar.y) <= this.radius + pillar.r) {
                        hitWall = true; break;
                    }
                }
            }

            if (hitWall) {
                if (this.type === 'rocket') {
                    this.explode(room, game);
                } else {
                    if (game) game.spawnParticles(this.x, this.y, '#95a5a6', 4, 50, 0.2, 3);
                }
                this.active = false;
                return;
            }
        }

        if (this.isPlayer) {
            // Check Boss
            if (room.boss && room.boss.hp > 0) {
                if (MathUtils.dist(this.x, this.y, room.boss.x, room.boss.y) < this.radius + room.boss.radius) {
                    if (this.hitCooldown <= 0) {
                        if (this.type === 'rocket') {
                            this.explode(room, game);
                            this.active = false;
                        } else {
                            const dmgMult = game.player ? game.player.getDamageMultiplier() : 1.0;
                            room.boss.takeDamage(this.damage * dmgMult, game);
                            if (game) game.spawnParticles(this.x, this.y, room.boss.color, 6, 80, 0.3, 3);
                            if (this.type === 'melee') {
                                this.hitCooldown = 0.5;
                            } else {
                                this.active = false;
                            }
                        }
                    }
                }
            }

            // Check Minions (e.g. in Tutorial)
            if (room.boss && room.boss.minions) {
                for (const m of room.boss.minions) {
                    if (m.hp > 0 && MathUtils.dist(this.x, this.y, m.x, m.y) < this.radius + m.r) {
                        if (this.hitCooldown <= 0) {
                            const dmgMult = game.player ? game.player.getDamageMultiplier() : 1.0;
                            if (m.takeDamage) m.takeDamage(this.damage * dmgMult, game);
                            else m.hp -= this.damage * dmgMult;
                            
                            if (game) game.spawnParticles(this.x, this.y, m.color, 6, 80, 0.3, 3);
                            if (this.type === 'melee') {
                                this.hitCooldown = 0.5;
                            } else {
                                this.active = false;
                            }
                        }
                    }
                }
            }

            // Check Lab Core Generators
            if (room.boss && room.boss.generators) {
                for (const g of room.boss.generators) {
                    if (g.active && MathUtils.dist(this.x, this.y, g.x, g.y) < this.radius + g.r) {
                        if (this.hitCooldown <= 0) {
                            // Normal bullets don't damage generators, but they should hit them
                            if (game) game.spawnParticles(this.x, this.y, '#ffffff', 5, 100, 0.2, 2);
                            if (this.type === 'melee') {
                                this.hitCooldown = 0.5;
                            } else {
                                this.active = false;
                            }
                        }
                    }
                }
            }

            // Check Boss Trail (e.g. Naga)
            if (room.boss && room.boss.trail && room.boss.hp > 0) {
                for (let i = 0; i < room.boss.trail.length; i++) {
                    const p = room.boss.trail[i];
                    const r = room.boss.radius * (1 - (i / 40));
                    if (MathUtils.dist(this.x, this.y, p.x, p.y) < this.radius + Math.max(5, r)) {
                        if (this.hitCooldown <= 0) {
                            const dmgMult = game.player ? game.player.getDamageMultiplier() : 1.0;
                            // Trail takes reduced damage
                            room.boss.takeDamage(this.damage * dmgMult * 0.5, game);
                            if (game) game.spawnParticles(this.x, this.y, room.boss.color, 4, 60, 0.2, 2);
                            if (this.type === 'melee') {
                                this.hitCooldown = 0.5;
                            } else {
                                this.active = false;
                            }
                            return;
                        }
                    }
                }
            }
        } else {
            if (MathUtils.dist(this.x, this.y, game.player.x, game.player.y) < this.radius + game.player.radius) {
                if (this.hitCooldown <= 0) {
                    if (game.player.parryTime > 0) {
                        // Reflect!
                        this.isPlayer = true;
                        this.vx *= -1.5;
                        this.vy *= -1.5;
                        this.damage *= 2;
                        game.spawnParticles(this.x, this.y, '#ffffff', 15, 200, 0.4, 4);
                        game.player.parryTime = 0; // Reset parry on success
                        game.player.shards += 5; // Reward for parry
                        if (game.onShardsChange) game.onShardsChange(game.player.shards);
                    } else {
                        game.player.takeDamage(this.damage);
                        if (this.type !== 'gear') {
                            this.active = false;
                        } else {
                            this.hitCooldown = 0.5; 
                        }
                    }
                }
            }
        }
    }

    draw(ctx: CanvasRenderingContext2D, game: any = null) {
        if (this.type === 'magic') {
            ctx.fillStyle = '#f1c40f';
            ctx.beginPath(); ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2); ctx.fill();
        } else if (this.type === 'melee') {
            ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
            ctx.beginPath(); ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2); ctx.fill();
        } else if (this.type === 'fire') {
            ctx.fillStyle = '#e67e22';
            ctx.beginPath(); ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#f1c40f';
            ctx.beginPath(); ctx.arc(this.x, this.y, this.radius*0.5, 0, Math.PI * 2); ctx.fill();
        } else if (this.type === 'poison') {
            ctx.fillStyle = '#2ecc71';
            ctx.beginPath(); ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#27ae60';
            ctx.beginPath(); ctx.arc(this.x-2, this.y-2, this.radius*0.3, 0, Math.PI * 2); ctx.fill();
        } else if (this.type === 'earth') {
            ctx.fillStyle = '#7f8c8d';
            ctx.beginPath();
            ctx.moveTo(this.x - this.radius, this.y - this.radius);
            ctx.lineTo(this.x + this.radius, this.y - this.radius*0.8);
            ctx.lineTo(this.x + this.radius*0.9, this.y + this.radius);
            ctx.lineTo(this.x - this.radius*0.8, this.y + this.radius*0.9);
            ctx.closePath();
            ctx.fill();
        } else if (this.type === 'bomb') {
            ctx.fillStyle = '#2c3e50';
            ctx.beginPath(); ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#e74c3c';
            ctx.beginPath(); ctx.arc(this.x, this.y-this.radius, this.radius*0.4, 0, Math.PI * 2); ctx.fill();
        } else if (this.type === 'gear') {
            ctx.fillStyle = '#95a5a6';
            ctx.beginPath();
            for (let i = 0; i < 8; i++) {
                const angle = (i * Math.PI) / 4 + (performance.now() / 200);
                const r = (i % 2 === 0) ? this.radius : this.radius * 0.6;
                const px = this.x + Math.cos(angle) * r;
                const py = this.y + Math.sin(angle) * r;
                if (i === 0) ctx.moveTo(px, py);
                else ctx.lineTo(px, py);
            }
            ctx.closePath();
            ctx.fill();
            ctx.fillStyle = '#34495e';
            ctx.beginPath(); ctx.arc(this.x, this.y, this.radius*0.3, 0, Math.PI * 2); ctx.fill();
        } else if (this.type === 'slash') {
            ctx.fillStyle = '#8e44ad';
            ctx.beginPath();
            const angle = Math.atan2(this.vy, this.vx);
            ctx.arc(this.x, this.y, this.radius, angle - Math.PI/2, angle + Math.PI/2);
            ctx.lineTo(this.x + Math.cos(angle) * this.radius * 1.5, this.y + Math.sin(angle) * this.radius * 1.5);
            ctx.closePath();
            ctx.fill();
        } else if (this.type === 'player_laser') {
            ctx.fillStyle = '#00ffff';
            ctx.beginPath();
            const angle = Math.atan2(this.vy, this.vx);
            ctx.arc(this.x, this.y, this.radius, angle - Math.PI/2, angle + Math.PI/2);
            ctx.lineTo(this.x + Math.cos(angle) * this.radius * 8, this.y + Math.sin(angle) * this.radius * 8);
            ctx.closePath();
            ctx.fill();
        } else if (this.type === 'rocket') {
            ctx.fillStyle = '#bdc3c7';
            ctx.beginPath(); ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2); ctx.fill();
            ctx.fillStyle = '#e74c3c';
            ctx.beginPath(); ctx.arc(this.x - (this.vx/this.speed)*this.radius, this.y - (this.vy/this.speed)*this.radius, this.radius*0.5, 0, Math.PI * 2); ctx.fill();
        } else {
            ctx.fillStyle = this.isPlayer ? '#f1c40f' : '#e67e22';
            ctx.beginPath(); ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2); ctx.fill();
        }

        // Draw Hitbox for Debugging
        if (game && game.showHitboxes) {
            ctx.strokeStyle = '#00ff00';
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
            ctx.stroke();
        }
    }
}
