# AoE Boss Rush - Local Setup

This project was built using React, TypeScript, and Vite. To run it on your computer, follow these steps:

## Prerequisites
- **Node.js**: You must have Node.js installed. Download it at [nodejs.org](https://nodejs.org/).

## How to Run (Automated)
1. **Extract the ZIP**: Unzip the downloaded files into a folder.
2. **Run the Script**:
   - **Windows**: Double-click `start_game.bat`.
   - **macOS/Linux**: Open a terminal in the folder and run `bash start_game.sh`.
3. **Wait**: The script will check for Node.js, install the game, and start it for you!

## Manual Setup (If scripts fail)
1. **Install Node.js**: Download it at [nodejs.org](https://nodejs.org/).
2. **Open a Terminal**: Open your terminal or command prompt in that folder.
3. **Install Dependencies**:
   ```bash
   npm install
   ```
4. **Start the Game**:
   ```bash
   npm run dev
   ```
5. **Open the Link**: The terminal will give you a link (usually `http://localhost:3000`). Open that in your browser to play!

## Why is index.html blank?
Modern web apps use "Modules" and "JSX" which browsers cannot read directly from your hard drive (`file://` protocol). The `npm run dev` command starts a local server that translates the code so the browser can understand it.
