import { MathUtils } from './MathUtils';
import { Telegraph } from './Telegraph';
import { Projectile } from './Projectile';
import { Hazard } from './Hazard';
import { Boss } from './Bosses';
import { Collectible } from './Collectible';

export class SamuraiBoss extends Boss {
    speed: number;
    dashCount: number;
    isTeleporting: boolean;
    spikeCooldown: number;
    facingAngle: number;
    dashTarget: any;

    constructor(x: number, y: number) {
        super("Shadow Samurai", x, y, 3500, 25, '#2c3e50');
        this.speed = 130;
        this.dashCount = 0;
        this.isTeleporting = false;
        this.spikeCooldown = 0;
        this.facingAngle = 0;
    }

    update(dt: number, player: any, game: any) {
        if (this.hp <= 0) return;
        if (this.spikeCooldown > 0) this.spikeCooldown -= dt;
        if (!this.isTeleporting) {
            for (const spike of game.room.spikes) {
                if (MathUtils.dist(this.x, this.y, spike.x, spike.y) < this.radius + spike.r) {
                    if (this.spikeCooldown <= 0) {
                        this.takeDamage(100, game);
                        this.spikeCooldown = 0.5;
                        const t = new Telegraph('circle', {x: this.x, y: this.y, r: this.radius*1.5}, 0.2, 0, null, '🩸');
                        t.resolved = true;
                        game.telegraphs.push(t);
                    }
                }
            }
        }
        if (this.isTeleporting) return;
        if (this.state === 'IDLE') {
            this.facingAngle = Math.atan2(player.y - this.y, player.x - this.x);
            this.x += Math.cos(this.facingAngle) * this.speed * dt;
            this.y += Math.sin(this.facingAngle) * this.speed * dt;
            this.stateTimer -= dt;
            if (this.stateTimer <= 0) this.pickAttack(player, game);
        } else if (this.state === 'ATTACKING') {
            this.stateTimer -= dt;
            if (this.stateTimer <= 0) {
                this.state = 'IDLE';
                this.stateTimer = 0.4 + Math.random() * 0.3;
            }
        } else if (this.state === 'DASHING') {
            this.facingAngle = Math.atan2(this.dashTarget.y - this.y, this.dashTarget.x - this.x);
            const step = 1400 * dt;
            const dist = MathUtils.dist(this.x, this.y, this.dashTarget.x, this.dashTarget.y);
            if (dist < step || dist < 30) {
                this.x = this.dashTarget.x;
                this.y = this.dashTarget.y;
                this.dashCount--;
                if (this.dashCount > 0) {
                    this.state = 'ATTACKING';
                    this.performDash(game.player, game);
                } else {
                    this.state = 'IDLE';
                    this.stateTimer = 0.6;
                }
            } else {
                this.x += Math.cos(this.facingAngle) * step;
                this.y += Math.sin(this.facingAngle) * step;
            }
        }
    }
    
    pickAttack(player: any, game: any) {
        this.state = 'ATTACKING';
        this.stateTimer = 0.8;
        const dist = MathUtils.dist(this.x, this.y, player.x, player.y);
        const r = Math.random();
        if (dist < 120) {
            if (r < 0.4) this.attackMelee(game);
            else if (r < 0.7) this.attackTeleport(player, game);
            else this.attackLightningSlash(game);
        } else {
            if (r < 0.3) this.attackAirSlash(player, game);
            else if (r < 0.6) this.initComboDash(player, game);
            else if (r < 0.8) this.attackKunaiThrow(player, game);
            else this.attackLightningSlash(game);
        }
    }

    attackKunaiThrow(player: any, game: any) {
        const baseAngle = Math.atan2(player.y - this.y, player.x - this.x);
        for(let i = -3; i <= 3; i++) {
            const angle = baseAngle + (i * 0.1);
            const proj = new Projectile(this.x, this.y, angle, false, 'slash', 28);
            proj.radius = 8;
            proj.speed = 600;
            proj.vx = Math.cos(angle) * proj.speed;
            proj.vy = Math.sin(angle) * proj.speed;
            game.projectiles.push(proj);
        }
        this.stateTimer = 0.6;
    }

    attackMelee(game: any) {
        game.telegraphs.push(new Telegraph('circle', {x: this.x, y: this.y, r: 120}, 0.4, 55, null, '⚔️'));
        this.stateTimer = 0.5;
    }

    attackAirSlash(player: any, game: any) {
        const baseAngle = Math.atan2(player.y - this.y, player.x - this.x);
        for(let i = -1; i <= 1; i++) {
            const angle = baseAngle + (i * 0.25);
            const proj = new Projectile(this.x, this.y, angle, false, 'slash', 28);
            game.projectiles.push(proj);
        }
        this.stateTimer = 0.7;
    }

    attackLightningSlash(game: any) {
        this.stateTimer = 1.0;
        for(let i=0; i<5; i++) {
            setTimeout(() => {
                if (this.hp <= 0 || game.state !== 'PLAYING' || game.room.boss !== this) return;
                const isHorizontal = Math.random() > 0.5;
                let x1, y1, x2, y2;
                if (isHorizontal) {
                    y1 = y2 = Math.random() * game.ROOM_SIZE;
                    x1 = 0; x2 = game.ROOM_SIZE;
                } else {
                    x1 = x2 = Math.random() * game.ROOM_SIZE;
                    y1 = 0; y2 = game.ROOM_SIZE;
                }
                game.telegraphs.push(new Telegraph('line', {x1, y1, x2, y2, w: 50}, 0.5, 44, null, '⚡'));
            }, i * 150);
        }
    }

    initComboDash(player: any, game: any) {
        this.dashCount = 3;
        this.performDash(player, game);
    }

    performDash(player: any, game: any) {
        const angle = Math.atan2(player.y - this.y, player.x - this.x);
        const dashDist = 450;
        let endX = Math.max(this.radius, Math.min(game.ROOM_SIZE - this.radius, this.x + Math.cos(angle) * dashDist));
        let endY = Math.max(this.radius, Math.min(game.ROOM_SIZE - this.radius, this.y + Math.sin(angle) * dashDist));
        game.telegraphs.push(new Telegraph('line', {x1: this.x, y1: this.y, x2: endX, y2: endY, w: 70}, 0.5, 49, () => {
            this.state = 'DASHING';
            this.dashTarget = {x: endX, y: endY};
        }, '💨'));
        this.stateTimer = 1.0; 
    }

    attackTeleport(player: any, game: any) {
        this.isTeleporting = true;
        this.stateTimer = 1.5;
        game.telegraphs.push(new Telegraph('circle', {x: this.x, y: this.y, r: 40}, 0.4, 0, () => {
            if (this.hp <= 0 || game.room.boss !== this) return;
            const offsetAngle = Math.random() * Math.PI * 2;
            this.x = Math.max(this.radius, Math.min(game.ROOM_SIZE - this.radius, player.x + Math.cos(offsetAngle) * 50));
            this.y = Math.max(this.radius, Math.min(game.ROOM_SIZE - this.radius, player.y + Math.sin(offsetAngle) * 50));
            this.isTeleporting = false;
            this.attackMelee(game);
        }, '🥷'));
    }

    draw(ctx: CanvasRenderingContext2D) {
        if (this.hp <= 0 || this.isTeleporting) return;
        ctx.save(); ctx.translate(this.x, this.y);
        ctx.fillStyle = this.color;
        ctx.beginPath(); ctx.arc(0, 0, this.radius, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#000'; ctx.lineWidth = 3; ctx.stroke();
        ctx.rotate(this.facingAngle);
        ctx.fillStyle = '#bdc3c7'; ctx.fillRect(this.radius * 0.8, -4, 40, 8);
        ctx.fillStyle = '#c0392b'; ctx.fillRect(this.radius * 0.6, -8, 8, 16);
        ctx.beginPath(); ctx.moveTo(this.radius * 0.8 + 40, -4); ctx.lineTo(this.radius * 0.8 + 48, 0); ctx.lineTo(this.radius * 0.8 + 40, 4); ctx.fill();
        ctx.restore();
        ctx.fillStyle = '#f39c12';
        ctx.beginPath(); (ctx as any).ellipse(this.x, this.y, this.radius * 1.4, this.radius * 0.8, 0, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#d35400'; ctx.lineWidth = 2; ctx.stroke();
    }
}

export class AdminBoss extends Boss {
    phase: number;
    moveAngle: number;
    speed: number;

    constructor(x: number, y: number) {
        super("The Admin", x, y, 12000, 40, '#000000');
        this.speed = 300;
        this.phase = 1;
        this.moveAngle = Math.random() * Math.PI * 2;
    }

    takeDamage(amt: number, game: any) {
        if (this.hp <= 0) return;
        this.hp -= amt;
        this.updateHealthUI();
        if (this.hp <= 0) {
            if (this.phase === 1) {
                this.phase = 2;
                this.hp = this.maxHp;
                this.updateHealthUI();
                this.name = "The Admin (Phase 2)";
                const hpText = document.getElementById('boss-health-text');
                if (hpText) hpText.innerText = this.name;
                this.speed = 450;
                const t = new Telegraph('circle', {x: game.ROOM_SIZE/2, y: game.ROOM_SIZE/2, r: game.ROOM_SIZE}, 0.5, 0, null, '⚠️');
                t.resolved = true;
                game.telegraphs.push(t);
                game.playDialogue([
                    {speaker: 'The Admin (Phase 2)', text: 'NICE TRY, MALWARE.'},
                    {speaker: 'System', text: 'SYSTEM OVERRIDE INITIATED. FULL RESTORE & UPGRADE GRANTED.'}
                ], () => {
                    game.player.hp = game.player.maxHp;
                    game.player.takeDamage(0);
                    game.pendingUpgrades = 1;
                    game.showUpgrades();
                    this.stateTimer = 1.0;
                });
            } else {
                this.hp = 0;
                this.die(game);
            }
        }
    }

    update(dt: number, player: any, game: any) {
        if (this.hp <= 0) return;
        if (this.state === 'IDLE') {
            if (Math.random() < 0.05) this.moveAngle += (Math.random() - 0.5) * Math.PI;
            let nx = this.x + Math.cos(this.moveAngle) * this.speed * dt;
            let ny = this.y + Math.sin(this.moveAngle) * this.speed * dt;
            if (nx < this.radius || nx > game.ROOM_SIZE - this.radius) {
                this.moveAngle = Math.PI - this.moveAngle;
                nx = this.x + Math.cos(this.moveAngle) * this.speed * dt;
            }
            if (ny < this.radius || ny > game.ROOM_SIZE - this.radius) {
                this.moveAngle = -this.moveAngle;
                ny = this.y + Math.sin(this.moveAngle) * this.speed * dt;
            }
            this.x = nx; this.y = ny;
            this.stateTimer -= dt;
            if (this.stateTimer <= 0) this.pickAttack(player, game);
        } else if (this.state === 'ATTACKING') {
            this.stateTimer -= dt;
            if (this.stateTimer <= 0) {
                this.state = 'IDLE';
                this.stateTimer = 0.15 + Math.random() * 0.2; 
            }
        }
    }

    pickAttack(player: any, game: any) {
        this.state = 'ATTACKING';
        this.stateTimer = 0.4;
        const r = Math.random();
        const adHidden = document.getElementById('fake-ad')?.classList.contains('hidden');
        if (this.phase === 2 && r < 0.20 && adHidden) this.attackFakeAd();
        else if (r < 0.2) this.attackHackGround(player, game);
        else if (r < 0.4) this.attackMissileSwarm(player, game);
        else if (r < 0.6) this.attackGlitchExplosions(player, game);
        else if (r < 0.8) this.attackLaserGrid(game);
        else this.attackDataStream(player, game); 
    }

    attackFakeAd() {
        document.getElementById('fake-ad')?.classList.remove('hidden');
        this.stateTimer = 1.0;
    }

    attackHackGround(player: any, game: any) {
        for(let i=0; i<8; i++) {
            const hx = player.x + (Math.random()-0.5)*500;
            const hy = player.y + (Math.random()-0.5)*500;
            const size = 100;
            game.telegraphs.push(new Telegraph('circle', {
                x: Math.max(size, Math.min(game.ROOM_SIZE-size, hx)), 
                y: Math.max(size, Math.min(game.ROOM_SIZE-size, hy)), 
                r: size
            }, 0.8, 10, () => {
                if (this.hp > 0 && game.state === 'PLAYING') {
                    game.hazards.push(new Hazard(hx, hy, size, 8.0, 18, 'rgba(0, 255, 0, 0.4)'));
                }
            }, '💻'));
        }
    }

    attackMissileSwarm(player: any, game: any) {
        for (let i = 0; i < 40; i++) {
            setTimeout(() => {
                if (this.hp <= 0 || game.state !== 'PLAYING' || game.room.boss !== this) return;
                const angle = Math.random() * Math.PI * 2;
                const proj = new Projectile(this.x, this.y, angle, false, 'bomb', 20);
                proj.speed = 180; 
                proj.vx = Math.cos(angle) * proj.speed; proj.vy = Math.sin(angle) * proj.speed;
                proj.homingTarget = player; proj.lifetime = 4.0; proj.maxRange = Infinity;
                const ogUpdate = proj.update.bind(proj);
                proj.update = (dt: number, room: any, game: any) => {
                    ogUpdate(dt, room, game);
                    if (!proj.active) game.telegraphs.push(new Telegraph('circle', {x: proj.x, y: proj.y, r: 80}, 0.4, 40, null, '💥'));
                };
                game.projectiles.push(proj);
            }, i * 60); 
        }
    }

    attackGlitchExplosions(player: any, game: any) {
        for (let i = 0; i < 40; i++) {
            const bx = player.x + (Math.random() - 0.5) * 800;
            const by = player.y + (Math.random() - 0.5) * 800;
            game.telegraphs.push(new Telegraph('circle', {
                x: Math.max(40, Math.min(game.ROOM_SIZE-40, bx)), 
                y: Math.max(40, Math.min(game.ROOM_SIZE-40, by)), 
                r: 60
            }, 0.4 + (i * 0.05), 45, null, '☠️'));
        }
    }

    attackLaserGrid(game: any) {
        for(let i = 1; i < 8; i++) {
            const y = (game.ROOM_SIZE / 8) * i;
            game.telegraphs.push(new Telegraph('line', { x1: 0, y1: y, x2: game.ROOM_SIZE, y2: y, w: 45 }, 0.8, 50, null, '⚡'));
        }
        for(let i = 1; i < 8; i++) {
            const x = (game.ROOM_SIZE / 8) * i;
            game.telegraphs.push(new Telegraph('line', { x1: x, y1: 0, x2: x, y2: game.ROOM_SIZE, w: 45 }, 0.8, 50, null, '⚡'));
        }
    }

    attackDataStream(player: any, game: any) {
        const dx = player.x - this.x;
        const dy = player.y - this.y;
        const len = Math.sqrt(dx*dx + dy*dy);
        const endX = this.x + (dx/len) * 1500;
        const endY = this.y + (dy/len) * 1500;
        game.telegraphs.push(new Telegraph('line', { x1: this.x, y1: this.y, x2: endX, y2: endY, w: 200 }, 1.2, 80, null, '💻'));
    }

    draw(ctx: CanvasRenderingContext2D) {
        if (this.hp <= 0) return;
        if (this.phase === 1) ctx.fillStyle = (Math.random() > 0.8) ? '#ff0000' : (Math.random() > 0.5 ? '#00ff00' : '#0000ff');
        else ctx.fillStyle = (Math.random() > 0.5) ? '#ffffff' : '#ff0000';
        ctx.fillRect(this.x - this.radius, this.y - this.radius, this.radius*2, this.radius*2);
        ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 3; ctx.strokeRect(this.x - this.radius, this.y - this.radius, this.radius*2, this.radius*2);
    }
}
