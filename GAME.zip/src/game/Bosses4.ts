import { MathUtils } from './MathUtils';
import { Telegraph } from './Telegraph';
import { Projectile } from './Projectile';
import { Hazard } from './Hazard';
import { Boss } from './Bosses';
import { Collectible } from './Collectible';

export class LabCoreBoss extends Boss {
    phase: string;
    generators: any[];
    button: any;
    mysteryDisappeared: boolean;
    buffSpawnTimer: number;

    constructor(x: number, y: number) {
        super("Lab Core", x, y, 9999, 60, '#9b59b6');
        this.phase = 'GENERATORS';
        this.generators = [
            {x: 100, y: 100, r: 35, active: true},
            {x: 700, y: 100, r: 35, active: true},
            {x: 100, y: 700, r: 35, active: true},
            {x: 700, y: 700, r: 35, active: true}
        ];
        this.button = {x: 400 - 100, y: 400 + 80, w: 200, h: 60, hp: 150, maxHp: 150, active: false};
        this.mysteryDisappeared = false;
        this.buffSpawnTimer = 0;
        setTimeout(() => document.getElementById('boss-health')?.classList.add('hidden'), 10);
    }

    takeDamage(amt: number, game: any) {}
    updateHealthUI() {}

    update(dt: number, player: any, game: any) {
        if (this.phase === 'ENDING') return;
        if (this.phase === 'GENERATORS') {
            let hasMissile = game.projectiles.some((p: any) => p.type === 'special_missile');
            if (!hasMissile && Math.random() < 0.05) this.fireSpecialMissile(player, game);
        }
        this.buffSpawnTimer -= dt;
        if (this.buffSpawnTimer <= 0) {
            this.buffSpawnTimer = 1.5;
            let type: 'health' | 'speed' = Math.random() < 0.5 ? 'health' : 'speed';
            let cx = 100 + Math.random() * (game.ROOM_SIZE - 200);
            let cy = 100 + Math.random() * (game.ROOM_SIZE - 200);
            game.collectibles.push(new Collectible(cx, cy, type));
        }
        this.stateTimer -= dt;
        if (this.stateTimer <= 0) this.pickAttack(player, game);
    }

    fireSpecialMissile(player: any, game: any) {
        const angle = Math.random() * Math.PI * 2;
        const proj = new Projectile(this.x, this.y, angle, false, 'special_missile', 20);
        proj.speed = 130; proj.radius = 18; proj.vx = Math.cos(angle) * proj.speed; proj.vy = Math.sin(angle) * proj.speed;
        proj.homingTarget = player; proj.maxRange = Infinity;
        
        const ogUpdate = proj.update.bind(proj);
        proj.update = (dt: number, room: any, game: any) => {
            ogUpdate(dt, room, game);
            if (this.phase === 'GENERATORS') {
                for (let g of this.generators) {
                    if (g.active && MathUtils.dist(proj.x, proj.y, g.x, g.y) < proj.radius + g.r) {
                        g.active = false;
                        proj.active = false;
                        game.telegraphs.push(new Telegraph('circle', {x: g.x, y: g.y, r: 80}, 0.2, 0, null, '💥'));
                        game.spawnParticles(g.x, g.y, '#f1c40f', 40, 250, 0.8, 6);
                        if (this.generators.every(gen => !gen.active)) {
                            this.phase = 'BUTTON';
                            this.button.active = true;
                            game.playDialogue([
                                {speaker: 'System', text: 'WARNING: GENERATORS DESTROYED. EMERGENCY RELEASE BUTTON EXPOSED.'},
                                {speaker: 'Player', text: 'There it is! I just have to blast that button!'}
                            ]);
                        }
                        return;
                    }
                }
            }
        };
        game.projectiles.push(proj);
    }

    pickAttack(player: any, game: any) {
        this.state = 'ATTACKING';
        this.stateTimer = 1.5;
        const r = Math.random();
        if (r < 0.25) this.attackShockwave(game);
        else if (r < 0.5) this.attackDisappearingFloor(game);
        else if (r < 0.75) this.attackLasers(game);
        else this.attackHomingBombs(player, game);
    }

    attackShockwave(game: any) {
        game.telegraphs.push(new Telegraph('ring', {x: this.x, y: this.y, innerR: 0, outerR: 300}, 1.5, 30, null, '🌊'));
        game.telegraphs.push(new Telegraph('ring', {x: this.x, y: this.y, innerR: 300, outerR: 600}, 2.0, 30, null, '🌊'));
    }

    attackDisappearingFloor(game: any) {
        const safeIndex = Math.floor(Math.random() * 4);
        const quadrants = [
            {x: 0, y: 0, w: game.ROOM_SIZE/2, h: game.ROOM_SIZE/2},
            {x: game.ROOM_SIZE/2, y: 0, w: game.ROOM_SIZE/2, h: game.ROOM_SIZE/2},
            {x: 0, y: game.ROOM_SIZE/2, w: game.ROOM_SIZE/2, h: game.ROOM_SIZE/2},
            {x: game.ROOM_SIZE/2, y: game.ROOM_SIZE/2, w: game.ROOM_SIZE/2, h: game.ROOM_SIZE/2}
        ];
        for(let i=0; i<4; i++) if (i !== safeIndex) game.telegraphs.push(new Telegraph('rect', quadrants[i], 2.5, 40, null, '⚠️'));
        this.stateTimer = 2.5;
    }

    attackLasers(game: any) {
        for(let i = 0; i < 4; i++) {
            const angle = (i * Math.PI) / 4;
            const dx = Math.cos(angle) * game.ROOM_SIZE;
            const dy = Math.sin(angle) * game.ROOM_SIZE;
            game.telegraphs.push(new Telegraph('line', { x1: this.x - dx, y1: this.y - dy, x2: this.x + dx, y2: this.y + dy, w: 50 }, 1.5, 45, null, '⚡'));
        }
    }

    attackHomingBombs(player: any, game: any) {
        for (let i = 0; i < 5; i++) {
            setTimeout(() => {
                if (this.phase === 'ENDING' || game.state !== 'PLAYING') return;
                const angle = Math.random() * Math.PI * 2;
                const proj = new Projectile(this.x, this.y, angle, false, 'bomb', 25);
                proj.speed = 160; proj.vx = Math.cos(angle) * proj.speed; proj.vy = Math.sin(angle) * proj.speed;
                proj.homingTarget = player; proj.lifetime = 4.0; proj.maxRange = Infinity;
                const ogUpdate = proj.update.bind(proj);
                proj.update = (dt: number, room: any, game: any) => {
                    ogUpdate(dt, room, game);
                    if (!proj.active) game.telegraphs.push(new Telegraph('circle', {x: proj.x, y: proj.y, r: 80}, 0.5, 40, null, '💥'));
                };
                game.projectiles.push(proj);
            }, i * 200); 
        }
    }

    startEndingCutscene(game: any) {
        this.phase = 'ENDING';
        game.projectiles = []; game.telegraphs = [];
        game.spawnParticles(this.x, this.y, '#9b59b6', 200, 500, 2.0, 6);
        game.spawnParticles(this.x, this.y, '#ffffff', 100, 600, 1.0, 4);
        this.color = '#333';
        game.playDialogue([
            {speaker: 'Friend', text: 'You found me... thank you.'},
            {speaker: 'Mysterious Person', text: "The core is shattered. But the system's true architect remains hidden."},
            {speaker: 'Player', text: 'Who are you?'},
            {speaker: 'Mysterious Person', text: '...'}
        ], () => {
            this.mysteryDisappeared = true;
            game.spawnParticles(game.ROOM_SIZE/2 + 30, game.ROOM_SIZE/2 + 50, '#8e44ad', 50, 150, 1.0, 3);
            setTimeout(() => {
                this.hp = 0;
                document.getElementById('boss-health')?.classList.add('hidden');
                game.gameWin(); 
            }, 1500);
        });
    }

    draw(ctx: CanvasRenderingContext2D) {
        ctx.fillStyle = this.color;
        ctx.beginPath();
        for(let i=0; i<8; i++) {
            const angle = (i * Math.PI)/4 + performance.now()/1000;
            const r = (i%2 === 0) ? this.radius : this.radius*0.7;
            const px = this.x + Math.cos(angle)*r;
            const py = this.y + Math.sin(angle)*r;
            if(i===0) ctx.moveTo(px,py); else ctx.lineTo(px,py);
        }
        ctx.closePath(); ctx.fill();
        ctx.strokeStyle = this.phase === 'ENDING' ? '#111' : '#8e44ad'; ctx.lineWidth = 4; ctx.stroke();
        ctx.fillStyle = '#2c3e50'; ctx.beginPath(); ctx.arc(this.x, this.y, this.radius*0.5, 0, Math.PI*2); ctx.fill();
        if (this.phase !== 'ENDING') {
            ctx.fillStyle = '#e74c3c';
            let corePulsing = Math.sin(performance.now()/150) * 5;
            ctx.beginPath(); ctx.arc(this.x, this.y, 10 + corePulsing, 0, Math.PI*2); ctx.fill();
        }
        if (this.phase === 'GENERATORS') {
            for (let g of this.generators) {
                if (g.active) {
                    ctx.fillStyle = '#f1c40f'; ctx.beginPath(); ctx.arc(g.x, g.y, g.r, 0, Math.PI*2); ctx.fill();
                    ctx.strokeStyle = '#e67e22'; ctx.lineWidth = 3; ctx.stroke();
                    ctx.fillStyle = '#000'; ctx.font = '16px Arial'; ctx.textAlign = 'center'; ctx.fillText('⚡', g.x, g.y + 5);
                }
            }
        }
        if (this.phase === 'BUTTON' && this.button.active) {
            ctx.fillStyle = '#e74c3c'; ctx.fillRect(this.button.x, this.button.y, this.button.w, this.button.h);
            ctx.strokeStyle = '#c0392b'; ctx.lineWidth = 4; ctx.strokeRect(this.button.x, this.button.y, this.button.w, this.button.h);
            ctx.fillStyle = '#fff'; ctx.font = 'bold 18px Arial'; ctx.textAlign = 'center'; ctx.fillText("FREE PRISONERS", this.button.x + this.button.w/2, this.button.y + 25);
            ctx.font = '14px Arial'; ctx.fillText(`Integrity: ${Math.ceil(Math.max(0, this.button.hp))} / ${this.button.maxHp}`, this.button.x + this.button.w/2, this.button.y + 45);
        }
        if (this.phase === 'ENDING') {
            const ROOM_SIZE = 800;
            ctx.fillStyle = '#ffb8b8'; ctx.beginPath(); ctx.arc(ROOM_SIZE/2 - 30, ROOM_SIZE/2 + 50, 10, 0, Math.PI*2); ctx.fill();
            ctx.fillStyle = '#e74c3c'; ctx.fillRect(ROOM_SIZE/2 - 35, ROOM_SIZE/2 + 38, 10, 4);
            if (!this.mysteryDisappeared) {
                ctx.fillStyle = '#333'; ctx.beginPath(); ctx.arc(ROOM_SIZE/2 + 30, ROOM_SIZE/2 + 50, 10, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle = '#fff'; ctx.fillRect(ROOM_SIZE/2 + 25, ROOM_SIZE/2 + 48, 3, 3); ctx.fillRect(ROOM_SIZE/2 + 32, ROOM_SIZE/2 + 48, 3, 3);
            }
        }
    }
}

export class TrueAdminBoss extends Boss {
    speed: number;

    constructor(x: number, y: number) {
        super("The Admin (True Form)", x, y, 60000, 60, '#ff00ff');
        this.speed = 300;
    }

    update(dt: number, player: any, game: any) {
        if (this.hp <= 0) return;
        if (this.state === 'IDLE') {
            const angle = Math.atan2(player.y - this.y, player.x - this.x);
            this.x += Math.cos(angle) * this.speed * dt;
            this.y += Math.sin(angle) * this.speed * dt;
            this.stateTimer -= dt;
            if (this.stateTimer <= 0) this.pickAttack(player, game);
        } else if (this.state === 'ATTACKING') {
            this.stateTimer -= dt;
            if (this.stateTimer <= 0) {
                this.state = 'IDLE';
                this.stateTimer = 0.05;
            }
        }
    }

    pickAttack(player: any, game: any) {
        this.state = 'ATTACKING';
        this.stateTimer = 0.3;
        const r = Math.random();
        if (r < 0.15 && document.getElementById('fake-ad')?.classList.contains('hidden')) this.attackFakeAd();
        else if (r < 0.3) this.attackHackGround(player, game);
        else if (r < 0.5) this.attackMissileSwarm(player, game);
        else if (r < 0.7) this.attackGlitchExplosions(player, game);
        else if (r < 0.85) this.attackLaserGrid(game);
        else this.attackDataStar(player, game); 
    }

    attackFakeAd() {
        document.getElementById('fake-ad')?.classList.remove('hidden');
    }

    attackHackGround(player: any, game: any) {
        for(let i=0; i<15; i++) {
            const hx = player.x + (Math.random()-0.5)*800;
            const hy = player.y + (Math.random()-0.5)*800;
            const size = 150;
            game.telegraphs.push(new Telegraph('circle', {
                x: Math.max(size, Math.min(game.ROOM_SIZE-size, hx)), y: Math.max(size, Math.min(game.ROOM_SIZE-size, hy)), r: size
            }, 0.5, 30, () => {
                if (this.hp > 0 && game.state === 'PLAYING') game.hazards.push(new Hazard(hx, hy, size, 5.0, 40, 'rgba(255, 0, 255, 0.5)'));
            }, '☣️'));
        }
    }

    attackMissileSwarm(player: any, game: any) {
        for (let i = 0; i < 60; i++) {
            setTimeout(() => {
                if (this.hp <= 0 || game.state !== 'PLAYING' || game.room.boss !== this) return;
                const angle = Math.random() * Math.PI * 2;
                const proj = new Projectile(this.x, this.y, angle, false, 'bomb', 35);
                proj.speed = 350; proj.vx = Math.cos(angle) * proj.speed; proj.vy = Math.sin(angle) * proj.speed;
                proj.homingTarget = player; proj.lifetime = 5.0; proj.maxRange = Infinity;
                const ogUpdate = proj.update.bind(proj);
                proj.update = (dt: number, room: any, game: any) => {
                    ogUpdate(dt, room, game);
                    if (!proj.active) game.telegraphs.push(new Telegraph('circle', {x: proj.x, y: proj.y, r: 100}, 0.3, 50, null, '💥'));
                };
                game.projectiles.push(proj);
            }, i * 40);
        }
    }

    attackGlitchExplosions(player: any, game: any) {
        for (let i = 0; i < 100; i++) {
            const bx = player.x + (Math.random() - 0.5) * 1000;
            const by = player.y + (Math.random() - 0.5) * 1000;
            game.telegraphs.push(new Telegraph('circle', {
                x: Math.max(40, Math.min(game.ROOM_SIZE-40, bx)), y: Math.max(40, Math.min(game.ROOM_SIZE-40, by)), r: 80
            }, 0.3 + (i * 0.02), 60, null, '☠️'));
        }
    }

    attackLaserGrid(game: any) {
        for(let i = 1; i < 10; i++) {
            const y = (game.ROOM_SIZE / 10) * i;
            game.telegraphs.push(new Telegraph('line', {x1: 0, y1: y, x2: game.ROOM_SIZE, y2: y, w: 60}, 0.6, 80, null, '⚡'));
        }
        for(let i = 1; i < 10; i++) {
            const x = (game.ROOM_SIZE / 10) * i;
            game.telegraphs.push(new Telegraph('line', {x1: x, y1: 0, x2: x, y2: game.ROOM_SIZE, w: 60}, 0.6, 80, null, '⚡'));
        }
    }

    attackDataStar(player: any, game: any) {
        const px = player.x, py = player.y;
        game.telegraphs.push(new Telegraph('line', {x1: 0, y1: py, x2: game.ROOM_SIZE, y2: py, w: 120}, 0.8, 100, null, '💻'));
        game.telegraphs.push(new Telegraph('line', {x1: px, y1: 0, x2: px, y2: game.ROOM_SIZE, w: 120}, 0.8, 100, null, '💻'));
        game.telegraphs.push(new Telegraph('line', {x1: px - 1200, y1: py - 1200, x2: px + 1200, y2: py + 1200, w: 120}, 0.8, 100, null, '💻'));
        game.telegraphs.push(new Telegraph('line', {x1: px - 1200, y1: py + 1200, x2: px + 1200, y2: py - 1200, w: 120}, 0.8, 100, null, '💻'));
    }

    draw(ctx: CanvasRenderingContext2D) {
        if (this.hp <= 0) return;
        ctx.fillStyle = (Math.random() > 0.5) ? '#ff00ff' : '#000000';
        ctx.fillRect(this.x - this.radius, this.y - this.radius, this.radius*2, this.radius*2);
        ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 4;
        ctx.strokeRect(this.x - this.radius, this.y - this.radius, this.radius*2, this.radius*2);
    }
}
