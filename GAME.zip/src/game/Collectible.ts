import { MathUtils } from './MathUtils';

export class Collectible {
    x: number;
    y: number;
    type: 'health' | 'speed';
    r: number;
    active: boolean;
    lifetime: number;

    constructor(x: number, y: number, type: 'health' | 'speed') {
        this.x = x; this.y = y; this.type = type;
        this.r = 15;
        this.active = true;
        this.lifetime = 10.0;
    }

    update(dt: number, player: any, game: any) {
        if (!this.active) return false;
        this.lifetime -= dt;
        if (this.lifetime <= 0) return false;
        
        if (MathUtils.dist(this.x, this.y, player.x, player.y) < this.r + player.radius) {
            if (this.type === 'health') {
                player.hp = Math.min(player.maxHp, player.hp + 100);
                player.takeDamage(0);
            } else if (this.type === 'speed') {
                player.speedBuffTimer = 5.0;
            }
            this.active = false;
            if (game) game.spawnParticles(this.x, this.y, this.type==='health'?'#2ecc71':'#f1c40f', 15, 100, 0.5, 3);
        }
        return this.active;
    }

    draw(ctx: CanvasRenderingContext2D) {
        if (this.lifetime < 2.0 && Math.sin(this.lifetime * 20) > 0) return;
        ctx.fillStyle = this.type === 'health' ? '#e74c3c' : '#f1c40f';
        ctx.beginPath(); ctx.arc(this.x, this.y, this.r, 0, Math.PI*2); ctx.fill();
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.stroke();
        ctx.fillStyle = '#fff';
        ctx.font = '14px Arial'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(this.type === 'health' ? '❤️' : '⚡', this.x, this.y+1);
    }
}
