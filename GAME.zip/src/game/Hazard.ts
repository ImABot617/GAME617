import { MathUtils } from './MathUtils';

export class Hazard {
    x: number;
    y: number;
    r: number;
    lifetime: number;
    dps: number;
    color: string;
    tickTimer: number;

    constructor(x: number, y: number, r: number, lifetime: number, dps: number, color: string) {
        this.x = x; this.y = y; this.r = r;
        this.lifetime = lifetime;
        this.dps = dps;
        this.color = color;
        this.tickTimer = 0;
    }

    update(dt: number, player: any) {
        this.lifetime -= dt;
        this.tickTimer -= dt;
        if (this.tickTimer <= 0) {
            if (MathUtils.dist(this.x, this.y, player.x, player.y) < this.r + player.radius) {
                player.takeDamage(this.dps);
            }
            this.tickTimer = 0.5;
        }
        return this.lifetime > 0;
    }

    draw(ctx: CanvasRenderingContext2D) {
        ctx.fillStyle = (Math.random() > 0.1) ? this.color : 'rgba(255, 255, 255, 0.4)';
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#00ff00';
        ctx.stroke();
    }
}
