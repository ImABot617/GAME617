export const MathUtils = {
    dist: (x1: number, y1: number, x2: number, y2: number) => Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2),
    
    circleRectCollide: (cx: number, cy: number, cr: number, rx: number, ry: number, rw: number, rh: number) => {
        let testX = cx;
        let testY = cy;
        if (cx < rx) testX = rx; else if (cx > rx + rw) testX = rx + rw;
        if (cy < ry) testY = ry; else if (cy > ry + rh) testY = ry + rh;
        let distX = cx - testX;
        let distY = cy - testY;
        return (distX * distX + distY * distY) <= (cr * cr);
    },

    circleLineCollide: (cx: number, cy: number, cr: number, x1: number, y1: number, x2: number, y2: number, width: number) => {
        const L2 = (x2 - x1) ** 2 + (y2 - y1) ** 2;
        if (L2 === 0) return MathUtils.dist(cx, cy, x1, y1) <= cr;
        let t = ((cx - x1) * (x2 - x1) + (cy - y1) * (y2 - y1)) / L2;
        t = Math.max(0, Math.min(1, t));
        const projX = x1 + t * (x2 - x1);
        const projY = y1 + t * (y2 - y1);
        return MathUtils.dist(cx, cy, projX, projY) <= (cr + width / 2);
    },

    circleRingCollide: (cx: number, cy: number, cr: number, rx: number, ry: number, innerR: number, outerR: number) => {
        const d = MathUtils.dist(cx, cy, rx, ry);
        return (d + cr >= innerR && d - cr <= outerR);
    }
};
