export class Particle {
    x: number;
    y: number;
    vx: number;
    vy: number;
    color: string;
    maxLife: number;
    life: number;
    size: number;

    constructor(x: number, y: number, color: string, speed: number, life: number, size: number) {
        this.x = x; 
        this.y = y;
        const angle = Math.random() * Math.PI * 2;
        const v = Math.random() * speed;
        this.vx = Math.cos(angle) * v;
        this.vy = Math.sin(angle) * v;
        this.color = color;
        this.maxLife = life;
        this.life = life;
        this.size = size;
    }

    update(dt: number) {
        this.x += this.vx * dt;
        this.y += this.vy * dt;
        this.life -= dt;
        return this.life > 0;
    }

    draw(ctx: CanvasRenderingContext2D) {
        ctx.globalAlpha = Math.max(0, this.life / this.maxLife);
        ctx.fillStyle = this.color;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1.0;
    }
}
