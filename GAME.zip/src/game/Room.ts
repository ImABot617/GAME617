import { MathUtils } from './MathUtils';
import { TutorialDirector, RobotBoss, GolemBoss, DragonBoss } from './Bosses';
import { NagaBoss, BombGolemBoss } from './Bosses2';
import { SamuraiBoss, AdminBoss } from './Bosses3';
import { LabCoreBoss, TrueAdminBoss } from './Bosses4';

export class Room {
    walls: any[];
    pillars: any[];
    spikes: any[];
    cleared: boolean;
    boss: any;
    dollar: any;
    ROOM_SIZE: number;
    GRID_CELL_SIZE: number;

    constructor(bossClass: any, ROOM_SIZE: number) {
        this.ROOM_SIZE = ROOM_SIZE;
        this.GRID_CELL_SIZE = ROOM_SIZE / 30;
        this.walls = [];
        this.pillars = [];
        this.spikes = [];
        this.cleared = false;
        this.dollar = null;
        
        this.boss = bossClass ? new bossClass(ROOM_SIZE/2, ROOM_SIZE/4) : null;
        
        if (this.boss instanceof TutorialDirector) {
            this.walls.push({x: 0, y: 0, w: 50, h: ROOM_SIZE});
            this.walls.push({x: ROOM_SIZE-50, y: 0, w: 50, h: ROOM_SIZE});
            this.walls.push({x: 0, y: ROOM_SIZE-this.GRID_CELL_SIZE, w: ROOM_SIZE, h: this.GRID_CELL_SIZE});
            this.walls.push({x: 0, y: 0, w: ROOM_SIZE, h: 50});
        } else {
            this.walls.push({x: 0, y: 0, w: ROOM_SIZE, h: this.GRID_CELL_SIZE});
            this.walls.push({x: 0, y: ROOM_SIZE-this.GRID_CELL_SIZE, w: ROOM_SIZE, h: this.GRID_CELL_SIZE});
            this.walls.push({x: 0, y: 0, w: this.GRID_CELL_SIZE, h: ROOM_SIZE});
            this.walls.push({x: ROOM_SIZE-this.GRID_CELL_SIZE, y: 0, w: this.GRID_CELL_SIZE, h: ROOM_SIZE});
        }
        
        if (this.boss instanceof RobotBoss) {
            this.pillars.push({x: ROOM_SIZE*0.33, y: ROOM_SIZE*0.33, r: 35});
            this.pillars.push({x: ROOM_SIZE*0.66, y: ROOM_SIZE*0.33, r: 35});
            this.pillars.push({x: ROOM_SIZE*0.33, y: ROOM_SIZE*0.66, r: 35});
            this.pillars.push({x: ROOM_SIZE*0.66, y: ROOM_SIZE*0.66, r: 35});
        } else if (this.boss instanceof GolemBoss) {
            this.walls.push({x: ROOM_SIZE*0.25, y: ROOM_SIZE*0.33, w: 60, h: 60});
            this.walls.push({x: ROOM_SIZE*0.75 - 60, y: ROOM_SIZE*0.33, w: 60, h: 60});
            this.walls.push({x: ROOM_SIZE/2 - 30, y: ROOM_SIZE*0.75, w: 60, h: 60});
        } else if (this.boss instanceof DragonBoss) {
            this.pillars.push({x: ROOM_SIZE*0.16, y: ROOM_SIZE*0.16, r: 30});
            this.pillars.push({x: ROOM_SIZE*0.84, y: ROOM_SIZE*0.16, r: 30});
            this.pillars.push({x: ROOM_SIZE*0.16, y: ROOM_SIZE*0.84, r: 30});
            this.pillars.push({x: ROOM_SIZE*0.84, y: ROOM_SIZE*0.84, r: 30});
        } else if (this.boss instanceof NagaBoss) {
            this.pillars.push({x: ROOM_SIZE/2 - ROOM_SIZE*0.15, y: ROOM_SIZE/2, r: 40});
            this.pillars.push({x: ROOM_SIZE/2 + ROOM_SIZE*0.15, y: ROOM_SIZE/2, r: 40});
            this.walls.push({x: ROOM_SIZE*0.16, y: ROOM_SIZE*0.5, w: 80, h: 20});
            this.walls.push({x: ROOM_SIZE*0.84 - 80, y: ROOM_SIZE*0.5, w: 80, h: 20});
        } else if (this.boss instanceof BombGolemBoss) {
            this.walls.push({x: ROOM_SIZE*0.25, y: ROOM_SIZE*0.25, w: 60, h: 20});
            this.walls.push({x: ROOM_SIZE*0.75 - 60, y: ROOM_SIZE*0.25, w: 60, h: 20});
            this.walls.push({x: ROOM_SIZE*0.25, y: ROOM_SIZE*0.75 - 20, w: 60, h: 20});
            this.walls.push({x: ROOM_SIZE*0.75 - 60, y: ROOM_SIZE*0.75 - 20, w: 60, h: 20});
        } else if (this.boss instanceof SamuraiBoss) {
            this.pillars.push({x: ROOM_SIZE*0.25, y: ROOM_SIZE*0.25, r: 15});
            this.pillars.push({x: ROOM_SIZE*0.75, y: ROOM_SIZE*0.25, r: 15});
            this.pillars.push({x: ROOM_SIZE*0.25, y: ROOM_SIZE*0.75, r: 15});
            this.pillars.push({x: ROOM_SIZE*0.75, y: ROOM_SIZE*0.75, r: 15});
            this.pillars.push({x: ROOM_SIZE*0.5, y: ROOM_SIZE*0.16, r: 15});
            this.pillars.push({x: ROOM_SIZE*0.5, y: ROOM_SIZE*0.84, r: 15});
            this.spikes.push({x: ROOM_SIZE*0.5, y: ROOM_SIZE*0.35, r: 20});
            this.spikes.push({x: ROOM_SIZE*0.5, y: ROOM_SIZE*0.65, r: 20});
            this.spikes.push({x: ROOM_SIZE*0.35, y: ROOM_SIZE*0.5, r: 20});
            this.spikes.push({x: ROOM_SIZE*0.65, y: ROOM_SIZE*0.5, r: 20});
        } else if (this.boss instanceof AdminBoss) {
            this.walls.push({x: ROOM_SIZE*0.2, y: ROOM_SIZE*0.2, w: 100, h: 100});
            this.walls.push({x: ROOM_SIZE*0.8 - 100, y: ROOM_SIZE*0.2, w: 100, h: 100});
            this.walls.push({x: ROOM_SIZE*0.2, y: ROOM_SIZE*0.8 - 100, w: 100, h: 100});
            this.walls.push({x: ROOM_SIZE*0.8 - 100, y: ROOM_SIZE*0.8 - 100, w: 100, h: 100});
            this.dollar = { x: ROOM_SIZE - 45, y: 25, w: 18, h: 10, collected: false };
        } else if (this.boss instanceof LabCoreBoss) {
            this.pillars.push({x: 250, y: 250, r: 40});
            this.pillars.push({x: 550, y: 250, r: 40});
            this.pillars.push({x: 250, y: 550, r: 40});
            this.pillars.push({x: 550, y: 550, r: 40});
        }
    }

    draw(ctx: CanvasRenderingContext2D) {
        const ROOM_SIZE = this.ROOM_SIZE;
        const GRID_CELL_SIZE = this.GRID_CELL_SIZE;
        if (this.boss instanceof TutorialDirector) {
            ctx.fillStyle = '#333';
            ctx.fillRect(0, 0, ROOM_SIZE, ROOM_SIZE);
            ctx.fillStyle = '#2c3e50';
            ctx.fillRect(0, 0, 50, ROOM_SIZE);
            ctx.fillRect(ROOM_SIZE-50, 0, 50, ROOM_SIZE);
            ctx.strokeStyle = '#f1c40f';
            ctx.lineWidth = 4;
            ctx.setLineDash([20, 20]);
            ctx.beginPath();
            ctx.moveTo(ROOM_SIZE/2, 0);
            ctx.lineTo(ROOM_SIZE/2, ROOM_SIZE);
            ctx.stroke();
            ctx.setLineDash([]);
        } else {
            ctx.strokeStyle = '#2a2a2a';
            ctx.lineWidth = 1;
            for(let i=0; i<ROOM_SIZE; i+=GRID_CELL_SIZE) {
                ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, ROOM_SIZE); ctx.stroke();
                ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(ROOM_SIZE, i); ctx.stroke();
            }
        }

        ctx.fillStyle = '#444';
        ctx.strokeStyle = '#222';
        ctx.lineWidth = 2;
        for (const wall of this.walls) {
            ctx.fillRect(wall.x, wall.y, wall.w, wall.h);
            ctx.strokeRect(wall.x, wall.y, wall.w, wall.h);
        }

        ctx.fillStyle = '#555';
        for (const pillar of this.pillars) {
            ctx.beginPath();
            ctx.arc(pillar.x, pillar.y, pillar.r, 0, Math.PI*2);
            ctx.fill();
            ctx.stroke();
        }

        ctx.fillStyle = '#2c3e50';
        ctx.strokeStyle = '#e74c3c';
        ctx.lineWidth = 2;
        for (const spike of this.spikes) {
            ctx.beginPath();
            ctx.arc(spike.x, spike.y, spike.r, 0, Math.PI*2);
            ctx.fill();
            ctx.stroke();
            ctx.beginPath();
            for (let i = 0; i < 8; i++) {
                const angle = (i * Math.PI) / 4;
                const innerX = spike.x + Math.cos(angle) * spike.r;
                const innerY = spike.y + Math.sin(angle) * spike.r;
                const outerX = spike.x + Math.cos(angle) * (spike.r + 8);
                const outerY = spike.y + Math.sin(angle) * (spike.r + 8);
                ctx.moveTo(innerX, innerY);
                ctx.lineTo(outerX, outerY);
            }
            ctx.stroke();
        }

        if (this.cleared) {
            ctx.fillStyle = 'rgba(46, 204, 113, 0.5)';
            ctx.beginPath();
            ctx.arc(ROOM_SIZE/2, ROOM_SIZE/2, 40, 0, Math.PI*2);
            ctx.fill();
            ctx.fillStyle = '#fff';
            ctx.textAlign = 'center';
            ctx.fillText("ENTER", ROOM_SIZE/2, ROOM_SIZE/2 + 5);
        }

        if (this.dollar && !this.dollar.collected) {
            ctx.fillStyle = '#2ecc71';
            ctx.fillRect(this.dollar.x, this.dollar.y, this.dollar.w, this.dollar.h);
            ctx.fillStyle = '#000';
            ctx.font = 'bold 8px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('$', this.dollar.x + this.dollar.w/2, this.dollar.y + this.dollar.h/2);
        }
    }
}
