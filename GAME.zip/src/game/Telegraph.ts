import { MathUtils } from './MathUtils';

export class Telegraph {
    type: 'circle' | 'rect' | 'line' | 'ring';
    params: any;
    duration: number;
    timer: number;
    damage: number;
    onResolve: (() => void) | null;
    resolved: boolean;
    flashTimer: number;
    sprite: string | null;
    source: string | null;

    constructor(type: 'circle' | 'rect' | 'line' | 'ring', params: any, duration: number, damage: number, onResolve: (() => void) | null = null, sprite: string | null = null, source: string | null = null) {
        this.type = type;
        this.params = params;
        this.duration = duration;
        this.timer = 0;
        this.damage = damage;
        this.onResolve = onResolve;
        this.resolved = false;
        this.flashTimer = 0;
        this.sprite = sprite;
        this.source = source;
    }

    update(dt: number, player: any) {
        if (this.resolved) {
            this.flashTimer -= dt;
            return this.flashTimer <= 0;
        }

        this.timer += dt;
        if (this.timer >= this.duration) {
            this.resolve(player);
            return false;
        }
        return false;
    }

    resolve(player: any) {
        this.resolved = true;
        this.flashTimer = 0.15;

        let hit = false;
        const { x, y } = player;
        const r = player.radius;

        if (this.type === 'circle') {
            hit = MathUtils.dist(x, y, this.params.x, this.params.y) <= (r + this.params.r);
        } else if (this.type === 'rect') {
            hit = MathUtils.circleRectCollide(x, y, r, this.params.x, this.params.y, this.params.w, this.params.h);
        } else if (this.type === 'line') {
            hit = MathUtils.circleLineCollide(x, y, r, this.params.x1, this.params.y1, this.params.x2, this.params.y2, this.params.w);
        } else if (this.type === 'ring') {
            hit = MathUtils.circleRingCollide(x, y, r, this.params.x, this.params.y, this.params.innerR, this.params.outerR);
        }

        if (hit) {
            player.takeDamage(this.damage, this.source);
        }

        if (this.onResolve) {
            this.onResolve();
        }
    }

    draw(ctx: CanvasRenderingContext2D) {
        if (this.resolved) {
            ctx.fillStyle = 'rgba(255, 0, 0, 0.8)';
        } else {
            const alpha = 0.2 + (Math.sin(this.timer * 10) * 0.1);
            ctx.fillStyle = `rgba(255, 50, 50, ${alpha})`;
            ctx.strokeStyle = 'rgba(255, 0, 0, 0.8)';
            ctx.lineWidth = 2;
        }

        ctx.beginPath();
        let centerX = 0, centerY = 0;
        
        if (this.type === 'circle') {
            ctx.arc(this.params.x, this.params.y, this.params.r, 0, Math.PI * 2);
            ctx.fill();
            if(!this.resolved) ctx.stroke();
            centerX = this.params.x; centerY = this.params.y;
        } else if (this.type === 'rect') {
            ctx.fillRect(this.params.x, this.params.y, this.params.w, this.params.h);
            if(!this.resolved) ctx.strokeRect(this.params.x, this.params.y, this.params.w, this.params.h);
            centerX = this.params.x + this.params.w/2; centerY = this.params.y + this.params.h/2;
        } else if (this.type === 'line') {
            ctx.lineCap = 'round';
            ctx.lineWidth = this.params.w;
            ctx.strokeStyle = this.resolved ? 'rgba(255, 0, 0, 0.8)' : `rgba(255, 50, 50, ${0.3})`;
            ctx.moveTo(this.params.x1, this.params.y1);
            ctx.lineTo(this.params.x2, this.params.y2);
            ctx.stroke();
            if(!this.resolved) {
                ctx.lineWidth = 2;
                ctx.strokeStyle = 'rgba(255, 0, 0, 0.8)';
                ctx.stroke();
            }
            centerX = (this.params.x1 + this.params.x2)/2; centerY = (this.params.y1 + this.params.y2)/2;
        } else if (this.type === 'ring') {
            ctx.arc(this.params.x, this.params.y, this.params.outerR, 0, Math.PI * 2);
            ctx.arc(this.params.x, this.params.y, this.params.innerR, 0, Math.PI * 2, true);
            ctx.fill();
            if(!this.resolved) {
                ctx.beginPath(); ctx.arc(this.params.x, this.params.y, this.params.outerR, 0, Math.PI*2); ctx.stroke();
                ctx.beginPath(); ctx.arc(this.params.x, this.params.y, this.params.innerR, 0, Math.PI*2); ctx.stroke();
            }
            centerX = this.params.x; centerY = this.params.y - (this.params.innerR + this.params.outerR)/2;
        }

        if (this.sprite && !this.resolved) {
            ctx.fillStyle = '#fff';
            ctx.font = '24px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(this.sprite, centerX, centerY);
        }
    }
}
