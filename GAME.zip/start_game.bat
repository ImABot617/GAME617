@echo off
title AoE Boss Rush - Starter
echo ==========================================
echo    AoE Boss Rush - Automated Starter
echo ==========================================
echo.

node -v >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is NOT installed on this system.
    echo.
    echo 1. Please go to https://nodejs.org/
    echo 2. Download and install the "LTS" version.
    echo 3. After installing, run this script again!
    echo.
    pause
    exit /b
)

echo [INFO] Node.js detected.
echo [INFO] Installing game components (this may take a minute)...
call npm install --no-audit --no-fund

if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Something went wrong during installation.
    echo Make sure you are connected to the internet.
    pause
    exit /b
)

echo.
echo [SUCCESS] Everything is ready!
echo [INFO] Starting the game server...
echo.
npm run dev
pause
