#!/bin/bash
echo "=========================================="
echo "   AoE Boss Rush - Automated Starter"
echo "=========================================="
echo ""

if ! command -v node &> /dev/null
then
    echo "[ERROR] Node.js is NOT installed on this system."
    echo ""
    echo "1. Please go to https://nodejs.org/"
    echo "2. Download and install the 'LTS' version."
    echo "3. After installing, run this script again!"
    echo ""
    exit
fi

echo "[INFO] Node.js detected."
echo "[INFO] Installing game components (this may take a minute)..."
npm install --no-audit --no-fund

if [ $? -ne 0 ]; then
    echo ""
    echo "[ERROR] Something went wrong during installation."
    echo "Make sure you are connected to the internet."
    exit
fi

echo ""
echo "[SUCCESS] Everything is ready!"
echo "[INFO] Starting the game server..."
echo ""
npm run dev
