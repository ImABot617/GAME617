import { useState, useEffect, useRef, useCallback } from 'react';
import { Background } from './components/Background';
import { StartMenu } from './components/StartMenu';
import { StoryOverlay } from './components/StoryOverlay';
import { GameStage } from './components/GameStage';
import { BossSection } from './components/BossSection';
import { CreditsScreen } from './components/CreditsScreen';
import { ACTS, LANE_CONFIGS, LORE_ARCHIVE } from './constants';
import { GameState, QuestType, Note, Quest } from './types';
import { useAudio } from './hooks/useAudio';

export default function App() {
  const [gameState, setGameState] = useState<GameState>('menu');
  const [currentActIdx, setCurrentActIdx] = useState(0);
  const [questIndex, setQuestIndex] = useState(0);
  const [unlockedActs, setUnlockedActs] = useState<number[]>([0]);
  const [playerName, setPlayerName] = useState('Harmonizer');
  const [selectedLaneCount, setSelectedLaneCount] = useState(6);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [resonance, setResonance] = useState(0);
  const [playerHp, setPlayerHp] = useState(100);
  const [bossHp, setBossHp] = useState(0);
  const [isShaking, setIsShaking] = useState(false);
  const [deathAnimation, setDeathAnimation] = useState<'glitch' | 'shatter' | null>(null);
  const [flash, setFlash] = useState(false);
  const [questTitle, setQuestTitle] = useState('');
  const [showQuestTitle, setShowQuestTitle] = useState(false);
  const [notes, setNotes] = useState<Note[]>([]);
  const [ratings, setRatings] = useState<{ id: number; text: string; color: string }[]>([]);
  const [activeKeys, setActiveKeys] = useState<Set<string>>(new Set());
  const [loreEntries, setLoreEntries] = useState<string[]>([]);

  const { initAudio, playTone } = useAudio();

  // Refs for game loop to avoid stale closures
  const stateRef = useRef({
    gameState,
    notes: [] as Note[],
    bossHp: 0,
    playerHp: 100,
    resonance: 0,
    combo: 0,
    score: 0,
    lastTime: 0,
    spawnTimer: 0,
    currentQuest: null as Quest | null,
    damageMult: 1.0,
    isArchon: false,
    isEcho: false,
  });

  // Sync refs with state
  useEffect(() => {
    stateRef.current.gameState = gameState;
    stateRef.current.notes = notes;
    stateRef.current.bossHp = bossHp;
    stateRef.current.playerHp = playerHp;
    stateRef.current.resonance = resonance;
    stateRef.current.combo = combo;
    stateRef.current.score = score;
  }, [gameState, notes, bossHp, playerHp, resonance, combo, score]);

  const currentQuest = ACTS[currentActIdx].quests[questIndex];

  const handleStart = (name: string, laneCount: number) => {
    const lowerName = name.toLowerCase();
    const isEcho = lowerName === 'echo';
    const isArchon = lowerName === 'archon';
    
    setPlayerName(name || 'Harmonizer');
    stateRef.current.isEcho = isEcho;
    stateRef.current.isArchon = isArchon;
    stateRef.current.damageMult = isEcho ? 1.5 : (isArchon ? 0.8 : 1.0);
    
    if (isArchon) {
      setUnlockedActs(prev => Array.from(new Set([...prev, 5])));
    }
    
    setQuestIndex(0);
    processQuest(0, currentActIdx);
  };

  const processQuest = useCallback((qIdx: number, aIdx: number) => {
    const quest = ACTS[aIdx].quests[qIdx];
    stateRef.current.currentQuest = quest;

    if (quest.type === QuestType.END_ACT) {
      if (quest.unlock !== undefined && !unlockedActs.includes(quest.unlock)) {
        setUnlockedActs(prev => [...prev, quest.unlock!]);
        const lore = LORE_ARCHIVE[quest.unlock] || "Encrypted Data Pack Downloaded.";
        setLoreEntries(prev => [lore, ...prev]);
      }
      setGameState('menu');
      return;
    }

    if (quest.type === QuestType.CELEBRATION) {
      setGameState('celebration');
      return;
    }

    if (quest.type === QuestType.DIALOGUE || quest.type === QuestType.BROADCAST) {
      setGameState('story');
    } else if (quest.type === QuestType.BATTLE) {
      startBattle(quest);
    }
  }, [unlockedActs]);

  const startBattle = (quest: Quest) => {
    initAudio();
    setResonance(0);
    setCombo(0);
    setBossHp(quest.hp || 0);
    setPlayerHp(100);
    setNotes([]);
    setQuestTitle(quest.title || '');
    setShowQuestTitle(true);
    setDeathAnimation(null);
    setFlash(true);
    setTimeout(() => setFlash(false), 800);

    setTimeout(() => {
      setShowQuestTitle(false);
      setGameState('battle');
      stateRef.current.lastTime = performance.now();
      stateRef.current.spawnTimer = 0;
    }, 2000);
  };

  const spawnNote = useCallback(() => {
    const quest = stateRef.current.currentQuest;
    if (!quest) return;

    const laneCount = quest.forceLanes || selectedLaneCount;
    const create = (laneIdx: number, type: Note['type']) => {
      const newNote: Note = {
        id: Math.random().toString(36).substr(2, 9),
        lane: laneIdx,
        y: 0,
        type
      };
      setNotes(prev => [...prev, newNote]);
    };

    if (quest.isSpamming) {
      for (let i = 0; i < 3; i++) setTimeout(() => create(Math.floor(Math.random() * laneCount), 'gold'), i * 150);
    } else if (quest.isMinigun) {
      for (let i = 0; i < 3; i++) setTimeout(() => create(Math.floor(Math.random() * laneCount), 'normal'), i * 120);
    }

    if (quest.isShotgun) {
      const count = Math.floor(laneCount / 2);
      const lanes = [...Array(laneCount).keys()].sort(() => Math.random() - 0.5).slice(0, count);
      lanes.forEach(idx => create(idx, 'purple'));
    } else if (!quest.isMinigun && !quest.isSpamming) {
      create(Math.floor(Math.random() * laneCount), stateRef.current.isArchon ? 'corrupted' : 'normal');
    }
  }, [selectedLaneCount]);

  const gameLoop = useCallback((timestamp: number) => {
    if (stateRef.current.gameState !== 'battle') return;

    const dt = timestamp - stateRef.current.lastTime;
    stateRef.current.lastTime = timestamp;
    stateRef.current.spawnTimer += dt;

    const quest = stateRef.current.currentQuest;
    if (!quest) return;

    const spawnInterval = quest.interval || 1000;
    if (stateRef.current.spawnTimer > spawnInterval) {
      spawnNote();
      stateRef.current.spawnTimer = 0;
    }

    const speed = (quest.speed || 0.5) * (1 + (stateRef.current.resonance / 100) * 0.2);
    
    setNotes(prev => {
      const nextNotes = prev.map(n => ({ ...n, y: n.y + speed * dt * 0.1 }));
      const missed = nextNotes.filter(n => n.y > 115);
      
      if (missed.length > 0) {
        setCombo(0);
        setResonance(prevRes => Math.max(0, prevRes - 10 * missed.length));
        if (currentActIdx > 0 && currentActIdx !== 4) {
          setPlayerHp(prevHp => {
            const newHp = Math.max(0, prevHp - (stateRef.current.isArchon ? 15 : 10) * missed.length);
            if (newHp <= 0) {
              setGameState('menu');
            }
            return newHp;
          });
        }
      }

      return nextNotes.filter(n => n.y <= 115);
    });

    requestAnimationFrame(gameLoop);
  }, [spawnNote, currentActIdx]);

  useEffect(() => {
    if (gameState === 'battle') {
      const animId = requestAnimationFrame(gameLoop);
      return () => cancelAnimationFrame(animId);
    }
  }, [gameState, gameLoop]);

  const showRating = (text: string, color: string) => {
    const id = Date.now();
    setRatings(prev => [...prev, { id, text, color }]);
    setTimeout(() => {
      setRatings(prev => prev.filter(r => r.id !== id));
    }, 600);
  };

  const handleHit = useCallback((laneIdx: number) => {
    if (stateRef.current.gameState !== 'battle') return;

    setNotes(prev => {
      const noteIdx = prev.findIndex(n => n.lane === laneIdx && n.y > 60);
      if (noteIdx === -1) return prev;

      const note = prev[noteIdx];
      const dist = Math.abs(note.y - 88);

      if (dist < 15) {
        const damage = (note.type !== 'normal') ? 4 : (dist < 5 ? 5 : 3);
        const finalDmg = damage * stateRef.current.damageMult * (1 + stateRef.current.resonance / 100);
        
        setBossHp(prevHp => {
          const newHp = Math.max(0, prevHp - finalDmg);
          if (newHp <= 0) {
            setGameState('story'); // Temporary, will be handled by death animation
            setDeathAnimation(stateRef.current.currentQuest?.deathType || 'shatter');
            playTone(60, 'square', 1.0);
            setTimeout(() => {
              setQuestIndex(prev => prev + 1);
              processQuest(questIndex + 1, currentActIdx);
            }, 1600);
          }
          return newHp;
        });

        showRating(dist < 5 ? "PERFECT" : "GREAT", dist < 5 ? "#fff" : "#4ade80");
        setCombo(prev => prev + 1);
        setScore(prev => prev + (dist < 5 ? 100 : 50));
        setResonance(prev => Math.min(100, prev + 2));
        playTone(200 + laneIdx * 40, 'sine', 0.2);

        return prev.filter((_, i) => i !== noteIdx);
      }
      return prev;
    });
  }, [questIndex, currentActIdx, processQuest, playTone]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.repeat) return;
      const key = e.key.toUpperCase();
      
      if (key === ' ') {
        if (resonance >= 50) {
          setResonance(prev => prev - 50);
          const dmg = 200 * stateRef.current.damageMult;
          setBossHp(prev => Math.max(0, prev - dmg));
          setIsShaking(true);
          setTimeout(() => setIsShaking(false), 200);
          playTone(80, 'sawtooth', 0.5);
        }
        return;
      }

      const laneKeys = LANE_CONFIGS[currentQuest?.forceLanes || selectedLaneCount];
      const idx = laneKeys.indexOf(key);
      if (idx !== -1) {
        setActiveKeys(prev => new Set(prev).add(key));
        handleHit(idx);
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const key = e.key.toUpperCase();
      setActiveKeys(prev => {
        const next = new Set(prev);
        next.delete(key);
        return next;
      });
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [resonance, currentQuest, selectedLaneCount, handleHit, playTone]);

  const getDialogueText = () => {
    if (!currentQuest) return '';
    let text = currentQuest.text || '';
    if (stateRef.current.isEcho && currentQuest.echoText) text = currentQuest.echoText;
    if (stateRef.current.isArchon && currentQuest.archonText) text = currentQuest.archonText;
    return text.replace('{name}', playerName);
  };

  return (
    <div className="relative w-full h-screen flex flex-col items-center overflow-hidden">
      <Background />
      
      <div id="quest-title" className={`fixed top-[15%] left-1/2 -translate-x-1/2 -translate-y-1/2 text-[1.8rem] font-black text-white z-[500] pointer-events-none text-center tracking-[0.3em] transition-opacity duration-500 ${showQuestTitle ? 'opacity-100' : 'opacity-0'}`} style={{ textShadow: '0 0 20px rgba(96, 165, 250, 0.8)' }}>
        {questTitle}
      </div>

      <div id="flash-overlay" className={`fixed inset-0 bg-white z-[2000] pointer-events-none ${flash ? 'phase-flash-anim' : 'opacity-0'}`} />

      {(currentActIdx > 0 && currentActIdx !== 4) && (
        <div id="player-ui" className="fixed bottom-[13.5vh] left-1/2 -translate-x-1/2 w-[250px] flex flex-col items-center z-[100]">
          <div className={`text-[9px] uppercase font-black mb-1 tracking-widest ${playerHp < 30 ? 'text-red-400' : 'text-green-400'}`}>Harmonizer Integrity</div>
          <div className="w-full h-[6px] bg-[#111] rounded-[4px] overflow-hidden border border-white/5">
            <div className="h-full bg-[#4ade80] transition-[width] duration-300" style={{ width: `${playerHp}%` }} />
          </div>
        </div>
      )}

      <div id="resonance-container" className="absolute left-3 bottom-[15vh] w-1 h-[100px] bg-white/10 rounded-full overflow-hidden">
        <div className="w-full bg-[#60a5fa] shadow-[0_0_15px_#60a5fa] transition-[height] duration-300 ease-in-out" style={{ height: `${resonance}%`, marginTop: `${100 - resonance}%` }} />
      </div>

      <div id="lore-bar" className="fixed bottom-0 left-0 w-full h-[12vh] bg-linear-to-t from-black to-black/80 border-t border-white/5 z-[500] p-[15px_30px] overflow-y-auto text-[0.7rem] text-white/50 leading-[1.4] scrollbar-none">
        <div className="text-[9px] font-black text-blue-400 mb-2 uppercase tracking-widest border-b border-white/5 pb-1">Archive Terminal v7.0.0</div>
        <div id="lore-content" className="italic opacity-70">
          {loreEntries.length > 0 ? loreEntries.map((entry, i) => (
            <div key={i} className="mb-4 border-l-2 border-blue-500 pl-3 animate-pulse text-blue-200/60">{entry}</div>
          )) : "Awaiting data... System ready for harmonic synchronization."}
        </div>
      </div>

      {gameState === 'menu' && (
        <StartMenu 
          acts={ACTS} 
          currentActIdx={currentActIdx} 
          unlockedActs={unlockedActs}
          onChangeAct={(dir) => setCurrentActIdx(prev => Math.max(0, Math.min(ACTS.length - 1, prev + dir)))}
          onStart={handleStart}
          selectedLaneCount={selectedLaneCount}
          setLaneCount={setSelectedLaneCount}
        />
      )}

      {gameState === 'story' && currentQuest && (
        <StoryOverlay 
          speaker={currentQuest.speaker || 'SYSTEM'} 
          text={getDialogueText()} 
          onAdvance={() => {
            setQuestIndex(prev => prev + 1);
            processQuest(questIndex + 1, currentActIdx);
          }}
        />
      )}

      {(gameState === 'battle' || deathAnimation) && (
        <div id="stage" className="relative w-full h-screen flex flex-col items-center z-10" style={{ perspective: '1200px' }}>
          <BossSection 
            quest={currentQuest} 
            bossHp={bossHp} 
            isShaking={isShaking} 
            deathAnimation={deathAnimation}
          />
          <GameStage 
            laneCount={currentQuest.forceLanes || selectedLaneCount} 
            notes={notes} 
            onHit={handleHit}
            activeKeys={activeKeys}
          />

          <div className="absolute bottom-[13vh] w-full flex justify-between px-10 items-end pointer-events-none opacity-50">
            <div className="text-left">
              <div className="text-[8px] uppercase font-bold tracking-widest">Frequency</div>
              <div className="text-xl font-black">{score.toLocaleString()}</div>
            </div>
            <div className="text-right">
              <div className="text-[8px] uppercase font-bold tracking-widest">Resonance</div>
              <div className="text-xl font-black text-blue-400">{combo}</div>
            </div>
          </div>

          {ratings.map(r => (
            <div key={r.id} className="floating-rating" style={{ color: r.color, left: '50%', top: '48%' }}>
              {r.text}
            </div>
          ))}
        </div>
      )}

      {gameState === 'celebration' && (
        <CreditsScreen playerName={playerName} />
      )}
    </div>
  );
}
