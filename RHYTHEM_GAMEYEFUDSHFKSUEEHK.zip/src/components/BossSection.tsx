
import React from 'react';
import { Quest } from '../types';

interface BossSectionProps {
  quest: Quest | null;
  bossHp: number;
  isShaking: boolean;
  deathAnimation: 'glitch' | 'shatter' | null;
}

export const BossSection: React.FC<BossSectionProps> = ({ quest, bossHp, isShaking, deathAnimation }) => {
  if (!quest) return null;

  const hpPct = quest.hp ? (bossHp / quest.hp) * 100 : 0;

  return (
    <div id="boss-section" className="w-full h-[38vh] flex flex-col items-center justify-end z-20 relative pb-[5px]">
      <div id="boss-visual" className={isShaking ? 'shake' : ''}>
        <svg viewBox="0 0 100 100" className={`w-[min(480px,80vw)] h-[min(480px,80vw)] boss-svg ${deathAnimation === 'glitch' ? 'boss-death-glitch' : deathAnimation === 'shatter' ? 'boss-death-shatter' : ''}`} id="boss-svg" style={{ filter: `drop-shadow(0 0 50px ${quest.bossColor})` }}>
          {/* Abomination */}
          <g id="boss-shape-abomination" style={{ display: quest.shape === 'abomination' ? 'block' : 'none' }}>
            <polygon points="50,5 95,25 95,75 50,95 5,75 5,25" fill="none" stroke={quest.bossColor} strokeWidth="2" opacity="0.3">
              <animateTransform attributeName="transform" type="rotate" from="0 50 50" to="360 50 50" dur="20s" repeatCount="indefinite" />
            </polygon>
            <path d="M50,15 L85,50 L50,85 L15,50 Z" stroke={quest.bossColor} strokeWidth="4" fill="none">
              <animate attributeName="stroke-dasharray" values="0,1000;1000,0" dur="4s" repeatCount="indefinite"/>
            </path>
            <circle cx="50" cy="50" r="10" fill={quest.bossColor} className="animate-pulse" />
          </g>
          
          {/* Serpentine Dragon */}
          <g id="boss-shape-dragon" style={{ display: quest.shape === 'dragon' ? 'block' : 'none' }}>
            <path d="M10,50 Q25,10 45,50 T80,50 T110,50" stroke={quest.bossColor} strokeWidth="6" fill="none" strokeLinecap="round">
              <animate attributeName="d" values="M10,50 Q25,10 45,50 T80,50 T110,50; M10,50 Q25,90 45,50 T80,50 T110,50; M10,50 Q25,10 45,50 T80,50 T110,50" dur="2s" repeatCount="indefinite"/>
            </path>
            <polygon points="10,50 -5,35 -5,65" fill={quest.bossColor} />
          </g>
          
          {/* Kitsune Spirit */}
          <g id="boss-shape-kitsune" style={{ display: quest.shape === 'kitsune' ? 'block' : 'none' }}>
            <path d="M35,35 L50,5 L65,35" stroke={quest.bossColor} strokeWidth="3" fill="none" />
            <path d="M25,50 L50,90 L75,50" stroke={quest.bossColor} strokeWidth="4" fill="none" />
            <circle cx="50" cy="45" r="10" fill={quest.bossColor} />
          </g>
          
          {/* Geometrical Sun */}
          <g id="boss-shape-sun" style={{ display: quest.shape === 'sun' ? 'block' : 'none' }}>
            <circle cx="50" cy="50" r="30" fill="#fff" />
            <g>
              <rect x="48" y="0" width="4" height="100" fill="#fff" opacity="0.3" />
              <rect x="0" y="48" width="100" height="4" fill="#fff" opacity="0.3" />
              <circle cx="50" cy="50" r="45" fill="none" stroke="#fff" strokeWidth="0.8" strokeDasharray="15 10" />
              <animateTransform attributeName="transform" type="rotate" from="0 50 50" to="360 50 50" dur="4s" repeatCount="indefinite" />
            </g>
          </g>
          
          {/* Corrupted Archon */}
          <g id="boss-shape-archon" style={{ display: quest.shape === 'archon' ? 'block' : 'none' }}>
            <circle cx="50" cy="50" r="40" fill="none" stroke={quest.bossColor} strokeWidth="0.5" opacity="0.5">
              <animate attributeName="r" values="35;45;35" dur="1s" repeatCount="indefinite"/>
            </circle>
            <path d="M20,20 L80,80 M20,80 L80,20" stroke={quest.bossColor} strokeWidth="2" />
            <rect x="40" y="40" width="20" height="20" fill="#000" stroke={quest.bossColor} strokeWidth="4" transform="rotate(45 50 50)">
              <animateTransform attributeName="transform" type="rotate" from="0 50 50" to="360 50 50" dur="20s" repeatCount="indefinite" />
            </rect>
          </g>
        </svg>
      </div>
      
      <div id="boss-bar-wrapper" className="w-[340px] transition-opacity duration-300">
        <div className="flex justify-between items-center mb-1">
          <span className="text-[9px] font-black uppercase text-white/50 tracking-widest">{quest.bossName}</span>
          <span className="text-[8px] font-bold bg-white/10 px-2 rounded italic text-white/80">{quest.phase}</span>
        </div>
        <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden">
          <div 
            className="h-full bg-linear-to-r from-[#ff0055] to-[#ff4d4d] transition-[width] duration-100 linear" 
            style={{ width: `${hpPct}%` }} 
          />
        </div>
      </div>
    </div>
  );
};
