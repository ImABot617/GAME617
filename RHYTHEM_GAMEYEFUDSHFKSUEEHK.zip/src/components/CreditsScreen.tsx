
import React, { useEffect, useState } from 'react';
import { PIXEL_SPRITES } from '../constants';

interface CreditsScreenProps {
  playerName: string;
}

export const CreditsScreen: React.FC<CreditsScreenProps> = ({ playerName }) => {
  const [chars, setChars] = useState<{ id: number; type: string; x: number; y: number; vx: number }[]>([]);

  useEffect(() => {
    const charTypes = ['eto', 'kitsune', 'interface', 'seraph'];
    const newChars = Array.from({ length: 12 }).map((_, i) => {
      const startLeft = Math.random() > 0.5;
      return {
        id: i,
        type: charTypes[Math.floor(Math.random() * charTypes.length)],
        x: startLeft ? -100 - (i * 100) : window.innerWidth + 100 + (i * 100),
        y: window.innerHeight - 100 - Math.random() * 40,
        vx: (startLeft ? 1 : -1) * (2 + Math.random() * 3)
      };
    });
    setChars(newChars);

    const interval = setInterval(() => {
      setChars(prev => prev.map(c => ({ ...c, x: c.x + c.vx })));
    }, 16);

    return () => clearInterval(interval);
  }, []);

  return (
    <div id="credits-screen" className="fixed inset-0 bg-black z-[5000] flex flex-col items-center justify-center text-center text-white">
      {chars.map(c => (
        <div 
          key={c.id}
          className="fixed z-[4000] w-14 h-14 pointer-events-none walking-bounce"
          style={{ left: c.x, top: c.y, transform: c.vx > 0 ? 'scaleX(1)' : 'scaleX(-1)' }}
          dangerouslySetInnerHTML={{ __html: PIXEL_SPRITES[c.type as keyof typeof PIXEL_SPRITES] }}
        />
      ))}

      <div className="space-y-10 px-6 max-w-xl">
        <h1 className="text-5xl font-black text-blue-400 uppercase tracking-tighter italic">COSMOS HARMONIZED</h1>
        <p className="text-lg opacity-80 leading-relaxed">The Geometrical Silence has been shattered. The strings of reality vibrate freely once more.</p>
        
        <div className="grid grid-cols-2 gap-8 pt-10 text-left border-t border-white/10">
          <div>
            <div className="text-white/30 text-[9px] uppercase font-black tracking-widest mb-1">Prime Harmonizer</div>
            <div className="text-xl font-bold">{playerName}</div>
          </div>
          <div>
            <div className="text-white/30 text-[9px] uppercase font-black tracking-widest mb-1">Observation Core</div>
            <div className="text-xl font-bold text-green-400">Eto</div>
          </div>
          <div>
            <div className="text-white/30 text-[9px] uppercase font-black tracking-widest mb-1">Ancient Rhythm</div>
            <div className="text-xl font-bold text-orange-400">Kitsune</div>
          </div>
          <div>
            <div className="text-white/30 text-[9px] uppercase font-black tracking-widest mb-1">Architecture</div>
            <div className="text-xl font-bold text-blue-400">INTERFACE</div>
          </div>
        </div>

        <div className="pt-10">
          <button onClick={() => window.location.reload()} className="px-10 py-4 border border-white/20 rounded-full font-bold hover:bg-white hover:text-black transition-all uppercase tracking-widest text-xs">
            Reinitialize Core
          </button>
        </div>
      </div>
    </div>
  );
};
