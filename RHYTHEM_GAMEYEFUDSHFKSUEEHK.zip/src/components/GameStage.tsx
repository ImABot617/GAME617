
import React from 'react';
import { Note } from '../types';
import { LANE_CONFIGS } from '../constants';

interface GameStageProps {
  laneCount: number;
  notes: Note[];
  onHit: (laneIdx: number) => void;
  activeKeys: Set<string>;
}

export const GameStage: React.FC<GameStageProps> = ({ laneCount, notes, onHit, activeKeys }) => {
  const laneKeys = LANE_CONFIGS[laneCount];

  return (
    <div id="perspective-arena" className="relative w-[min(95vw,850px)] h-[42vh] origin-top flex flex-col items-center transition-[width] duration-500" style={{ transform: 'rotateX(40deg)', transformStyle: 'preserve-3d' }}>
      <div id="lanes-container" className="flex w-full h-full relative" style={{ transformStyle: 'preserve-3d' }}>
        {Array.from({ length: laneCount }).map((_, i) => (
          <div key={i} className="flex-1 relative h-full" style={{ transformStyle: 'preserve-3d' }}>
            <div 
              className="absolute left-1/2 top-0 w-[2px] h-full -translate-x-1/2 -translate-z-[5px]"
              style={{ background: 'linear-gradient(to bottom, transparent 0%, rgba(255, 255, 255, 0.05) 10%, rgba(96, 165, 250, 0.4) 40%, rgba(96, 165, 250, 0.3) 60%, transparent 85%)' }}
            />
            {notes.filter(n => n.lane === i).map(n => (
              <div 
                key={n.id} 
                className={`note ${n.type}`} 
                style={{ top: `${n.y}%` }} 
              />
            ))}
          </div>
        ))}
      </div>

      <div id="hit-zones-layer" className="absolute bottom-[5%] w-full flex justify-around pointer-events-none" style={{ transformStyle: 'preserve-3d' }}>
        {laneKeys.map((key, i) => (
          <div 
            key={i} 
            className={`w-[min(46px,8vw)] h-[min(46px,8vw)] rounded-full border-2 border-white/20 flex items-center justify-center font-black text-[min(10px,2.5vw)] bg-black/80 transition-all duration-100 cursor-pointer -rotate-x-[40deg] translate-z-[15px] ${activeKeys.has(key) ? 'scale-[0.85] border-white bg-white/20 shadow-[0_0_30px_#fff] text-white' : 'text-white/30'}`}
            onMouseDown={() => onHit(i)}
          >
            {key}
          </div>
        ))}
      </div>
    </div>
  );
};
