
import React from 'react';
import { Act } from '../types';
import { LANE_CONFIGS } from '../constants';

interface StartMenuProps {
  acts: Act[];
  currentActIdx: number;
  unlockedActs: number[];
  onChangeAct: (dir: number) => void;
  onStart: (name: string, laneCount: number) => void;
  selectedLaneCount: number;
  setLaneCount: (n: number) => void;
}

export const StartMenu: React.FC<StartMenuProps> = ({ 
  acts, currentActIdx, unlockedActs, onChangeAct, onStart, selectedLaneCount, setLaneCount 
}) => {
  const [name, setName] = React.useState('');
  const act = acts[currentActIdx];
  const isLocked = !unlockedActs.includes(currentActIdx);

  const handleBegin = () => {
    if (isLocked) return;
    onStart(name, selectedLaneCount);
  };

  const show4 = currentActIdx < 3;
  const show6 = currentActIdx < 3 || currentActIdx === 4;
  const show8 = currentActIdx === 3;
  const show10 = currentActIdx === 5;

  return (
    <div className="fixed inset-0 bg-black/98 backdrop-blur-[30px] flex items-center justify-center z-[200]">
      <div className="relative text-center p-8 md:p-10 bg-white/5 rounded-[3rem] border border-white/10 shadow-2xl w-[90%] max-w-[450px]">
        <h1 className="text-3xl md:text-4xl font-black mb-3 tracking-tighter text-blue-50 italic uppercase">GEOMETRICAL MELODY</h1>
        <p className="text-[10px] opacity-30 mb-8 uppercase tracking-[0.4em]">Harmonic Logic Core</p>
        
        <div className="mb-6 relative">
          <div className="p-5 bg-black/40 rounded-2xl border border-white/5 relative overflow-hidden h-28 flex flex-col justify-center">
            <h2 className="text-lg font-black text-blue-300 uppercase">{act.name}</h2>
            <p className="text-[10px] opacity-50 mt-1 uppercase tracking-widest">{act.desc}</p>
            {isLocked && (
              <div className="absolute inset-0 bg-black/90 flex flex-col items-center justify-center">
                <div className="font-black text-[10px] text-red-500 mb-1">ENCRYPTED</div>
                <div className="text-[8px] opacity-40">Complete Previous Logic Gate</div>
              </div>
            )}
          </div>
          <button onClick={() => onChangeAct(-1)} className="absolute top-1/2 -translate-y-1/2 -left-[60px] bg-white/5 border border-white/10 w-[50px] h-[50px] rounded-full flex items-center justify-center hover:bg-white hover:text-black transition-all">←</button>
          <button onClick={() => onChangeAct(1)} className="absolute top-1/2 -translate-y-1/2 -right-[60px] bg-white/5 border border-white/10 w-[50px] h-[50px] rounded-full flex items-center justify-center hover:bg-white hover:text-black transition-all">→</button>
        </div>

        <input 
          type="text" 
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Harmonizer ID" 
          maxLength={12} 
          className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-center mb-5 outline-none focus:border-blue-500 transition-all font-bold text-sm"
        />
        
        <div className="mb-6">
          <div className="flex justify-center gap-2">
            {show4 && (
              <button 
                onClick={() => setLaneCount(4)} 
                className={`px-4 py-2 rounded-lg text-[9px] font-black transition-all ${selectedLaneCount === 4 ? 'bg-white text-black' : 'border border-white/10 opacity-50'}`}
              >
                4 STRINGS
              </button>
            )}
            {show6 && (
              <button 
                onClick={() => setLaneCount(6)} 
                className={`px-4 py-2 rounded-lg text-[9px] font-black transition-all ${selectedLaneCount === 6 ? 'bg-white text-black' : 'border border-white/10 opacity-50'}`}
              >
                6 STRINGS
              </button>
            )}
            {show8 && (
              <button 
                onClick={() => setLaneCount(8)} 
                className={`px-4 py-2 rounded-lg text-[9px] font-black transition-all ${selectedLaneCount === 8 ? 'bg-white text-black' : 'border border-white/10 opacity-50'}`}
              >
                8 STRINGS
              </button>
            )}
            {show10 && (
              <button 
                onClick={() => setLaneCount(10)} 
                className={`px-4 py-2 rounded-lg text-[9px] font-black transition-all ${selectedLaneCount === 10 ? 'bg-white text-black' : 'border border-white/10 opacity-50'}`}
              >
                10 STRINGS
              </button>
            )}
          </div>
        </div>

        <button 
          onClick={handleBegin}
          disabled={isLocked}
          className="w-full py-4 bg-white text-black rounded-full font-black transition-all transform hover:scale-105 active:scale-95 shadow-lg uppercase tracking-widest text-lg disabled:opacity-20"
        >
          Synchronize
        </button>

        <div className="mt-6 pt-6 border-t border-white/10">
          <a 
            href="/portable.html" 
            target="_blank"
            className="text-[9px] text-blue-400 font-black uppercase tracking-widest hover:text-white transition-colors"
          >
            Download Portable Edition (Single HTML)
          </a>
          <p className="text-[8px] text-white/20 mt-1 uppercase">No Node.js or installation required</p>
        </div>
      </div>
    </div>
  );
};
