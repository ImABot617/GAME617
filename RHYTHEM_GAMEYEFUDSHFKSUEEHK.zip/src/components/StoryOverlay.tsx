
import React from 'react';

interface StoryOverlayProps {
  speaker: string;
  text: string;
  onAdvance: () => void;
}

export const StoryOverlay: React.FC<StoryOverlayProps> = ({ speaker, text, onAdvance }) => {
  return (
    <div 
      className="fixed bottom-[15vh] left-1/2 -translate-x-1/2 w-[min(90%,600px)] bg-black/95 backdrop-blur-[20px] border border-white/15 rounded-[20px] p-[25px] z-[1000] cursor-pointer"
      onClick={onAdvance}
    >
      <div className="text-blue-400 font-bold text-xs mb-1 uppercase tracking-widest">{speaker}</div>
      <div className="text-white text-base leading-relaxed">{text}</div>
      <div className="text-[9px] text-white/20 text-right mt-3 font-bold uppercase tracking-widest animate-pulse">Click to Progress</div>
    </div>
  );
};
