
import { Act, QuestType } from './types';

export const LANE_CONFIGS: Record<number, string[]> = {
  4: ['D', 'F', 'J', 'K'],
  6: ['S', 'D', 'F', 'J', 'K', 'L'],
  8: ['A', 'S', 'D', 'F', 'J', 'K', 'L', ';'],
  10: ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P']
};

export const PIXEL_SPRITES = {
  eto: `<svg viewBox="0 0 16 16" style="shape-rendering: crispEdges;"><rect x="5" y="4" width="6" height="6" fill="#4ade80"/><rect x="4" y="10" width="8" height="6" fill="#166534"/><rect x="6" y="6" width="1" height="1" fill="white"/><rect x="9" y="6" width="1" height="1" fill="white"/></svg>`,
  kitsune: `<svg viewBox="0 0 16 16" style="shape-rendering: crispEdges;"><rect x="4" y="6" width="8" height="6" fill="#fb923c"/><rect x="6" y="4" width="4" height="4" fill="#fb923c"/><rect x="11" y="4" width="4" height="4" fill="#f97316"/><rect x="6" y="6" width="1" height="1" fill="black"/><rect x="9" y="6" width="1" height="1" fill="black"/><rect x="6" y="12" width="1" height="4" fill="#fb923c"/><rect x="9" y="12" width="1" height="4" fill="#fb923c"/></svg>`,
  interface: `<svg viewBox="0 0 16 16" style="shape-rendering: crispEdges;"><rect x="6" y="4" width="4" height="4" fill="#60a5fa"/><rect x="5" y="8" width="6" height="4" fill="#3b82f6"/><rect x="2" y="7" width="2" height="2" fill="#60a5fa"/><rect x="12" y="7" width="2" height="2" fill="#60a5fa"/><rect x="6" y="12" width="4" height="1" fill="white" opacity="0.5"/></svg>`,
  seraph: `<svg viewBox="0 0 16 16" style="shape-rendering: crispEdges;"><rect x="6" y="2" width="4" height="6" fill="#e0f2fe"/><rect x="4" y="8" width="8" height="6" fill="#7dd3fc"/><rect x="2" y="4" width="2" height="8" fill="#e0f2fe" opacity="0.6"/><rect x="12" y="4" width="2" height="8" fill="#e0f2fe" opacity="0.6"/><rect x="7" y="5" width="2" height="1" fill="#38bdf8"/></svg>`
};

export const LORE_ARCHIVE: Record<number, string> = {
  1: "ESSAY: THE FRACTURE - Reality began as a chord. The Silence was an accident.",
  2: "ESSAY: THE DRAGON - A guardian of mathematical entropy.",
  3: "ESSAY: THE SPIRIT - Kitsune represents the irrational variable.",
  4: "ESSAY: THE SUN - A massive logical processor intent on deleting all sound.",
  5: "ESSAY: THE REBIRTH - After the Sun, we realized that perfection isn't a goal, but a cage.",
  6: "ESSAY: THE ARCHON - When the terminal user becomes the virus, the universe glitches into a 10-string nightmare."
};

export const ACTS: Act[] = [
  {
    name: "Act I", desc: "Mathematical Silence",
    quests: [
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "Systems re-initializing... Harmonizer {name} detected." },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "Alert: The Abomination is rewriting Sector 1. Synchronize or be erased.", archonText: "Detecting... Archon frequency? No, that is impossible. Proceed with synchronization." },
      { type: QuestType.BATTLE, title: 'ACT I: PHASE I', bossName: 'Abomination', phase: 'Detection', hp: 800, speed: 0.45, interval: 1000, bossColor: '#ff0055', shape: 'abomination', deathType: 'glitch' },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "Target core unstable. Analyzing pattern shift... Phase II initiated." },
      { type: QuestType.BATTLE, title: 'ACT I: PHASE II', bossName: 'Abomination', phase: 'Fracture', hp: 1200, speed: 0.52, interval: 1400, bossColor: '#a855f7', isShotgun: true, shape: 'abomination', deathType: 'glitch' },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "Signature deleted. Local harmonics returning to safe levels." },
      { type: QuestType.DIALOGUE, speaker: 'Eto', text: "Whoa, that was a close one! I'm Eto. You've got quite the rhythm." },
      { type: QuestType.DIALOGUE, speaker: 'Eto', text: "But don't get comfortable. The Abomination was just testing your firewall.", echoText: "Wait... Echo? THE Echo? The First Harmonizer? Is it really you?" },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "Objective updated: Navigate to the Golden Orbits." },
      { type: QuestType.END_ACT, unlock: 1 }
    ]
  },
  {
    name: "Act II", desc: "The Golden Orbit",
    quests: [
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "Approaching High Orbit. Celestial Guardian signature detected." },
      { type: QuestType.DIALOGUE, speaker: 'Eto', text: "It's the Golden Dragon. It's been enslaved by the Sun's logic." },
      { type: QuestType.BATTLE, title: 'ACT II: PHASE I', bossName: 'Celestial Dragon', phase: 'Ascent', hp: 1000, speed: 0.62, interval: 900, bossColor: '#ffcc00', shape: 'dragon', deathType: 'shatter' },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "Dragon core overheating. Switching to Kinetic fire protocols." },
      { type: QuestType.BATTLE, title: 'ACT II: PHASE II', bossName: 'Celestial Dragon', phase: 'Kinetic', hp: 1000, speed: 0.70, interval: 700, bossColor: '#fbbf24', isMinigun: true, shape: 'dragon', deathType: 'shatter' },
      { type: QuestType.DIALOGUE, speaker: 'Eto', text: "Look out! It's going into full Overdrive! Hold the beat!" },
      { type: QuestType.BATTLE, title: 'ACT II: PHASE III', bossName: 'Celestial Dragon', phase: 'Overdrive', hp: 1500, speed: 0.75, interval: 800, bossColor: '#fff', isShotgun: true, isMinigun: true, shape: 'dragon', deathType: 'shatter' },
      { type: QuestType.DIALOGUE, speaker: 'Eto', text: "That was incredible! The gold fragments are turning into music!" },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "Analysis: Guardian neutralized. The path to Sector 3 is clear." },
      { type: QuestType.DIALOGUE, speaker: 'Eto', text: "But the Kitsune Spirit is still trapped. We need to hurry." },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "Scanning for the Anchor signature now. Standby." },
      { type: QuestType.END_ACT, unlock: 2 }
    ]
  },
  {
    name: "Act III", desc: "Corrupted Memory",
    quests: [
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "Sector 3 reached. Logic-rot detected at 92% density." },
      { type: QuestType.DIALOGUE, speaker: 'Eto', text: "The Kitsune... she's being used as a battery for the Silence. We have to break her free!" },
      { type: QuestType.BATTLE, title: 'ACT III: PHASE I', bossName: 'Possessed Totem', phase: 'Spirit', hp: 1500, speed: 0.65, interval: 800, bossColor: '#fb923c', shape: 'kitsune', deathType: 'shatter' },
      { type: QuestType.DIALOGUE, speaker: 'Kitsune', text: "Ugh... the numbers... they burn my tails..." },
      { type: QuestType.BATTLE, title: 'ACT III: PHASE II', bossName: 'Possessed Totem', phase: 'Tails', hp: 2000, speed: 0.70, interval: 650, bossColor: '#f97316', isShotgun: true, shape: 'kitsune', deathType: 'shatter' },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "Corruption spreading. Totem is entering logic-defensive state." },
      { type: QuestType.BATTLE, title: 'ACT III: PHASE III', bossName: 'Possessed Totem', phase: 'Curse', hp: 2500, speed: 0.75, interval: 550, bossColor: '#ef4444', isMinigun: true, shape: 'kitsune', deathType: 'shatter' },
      { type: QuestType.DIALOGUE, speaker: 'Eto', text: "One more push! Shatter the geometric chains!" },
      { type: QuestType.BATTLE, title: 'ACT III: PHASE IV', bossName: 'Possessed Totem', phase: 'Liberation', hp: 3000, speed: 0.80, interval: 450, bossColor: '#fff', isShotgun: true, isMinigun: true, shape: 'kitsune', deathType: 'shatter' },
      { type: QuestType.DIALOGUE, speaker: 'Kitsune', text: "The static... it fades. Thank you, Harmonizer.", archonText: "The static... it fades. Traveler, your frequency... it feels like the Great Silence itself. Strange." },
      { type: QuestType.DIALOGUE, speaker: 'Eto', text: "We did it! Sector 3 is rebooting!" },
      { type: QuestType.DIALOGUE, speaker: 'Kitsune', text: "The Geometrical Sun awaits. It is the architect of this cold perfection." },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "Initializing final jump to the Logic Core." },
      { type: QuestType.END_ACT, unlock: 3 }
    ]
  },
  {
    name: "Act IV", desc: "The Geometric Sun",
    quests: [
      { type: QuestType.DIALOGUE, speaker: 'Kitsune', text: "The heart of the Silence. {name}, your song is the only thing that can shatter its logic." },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "Final Boss Detected: THE GEOMETRICAL SUN. Synchronizing 8-string deck." },
      { type: QuestType.BATTLE, title: 'FINAL ACT: PHASE I', bossName: 'Geometric Sun', phase: 'Structure', hp: 2500, speed: 0.75, interval: 900, bossColor: '#fff', shape: 'sun', forceLanes: 8, deathType: 'shatter' },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "Core layer 1 breached. Activating Shotgun defense subroutines." },
      { type: QuestType.BATTLE, title: 'FINAL ACT: PHASE II', bossName: 'Geometric Sun', phase: 'Logic', hp: 2500, speed: 0.78, interval: 800, bossColor: '#fff', isShotgun: true, shape: 'sun', forceLanes: 8, deathType: 'shatter' },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "Core layer 2 breached. Guardian Minigun protocols engaged." },
      { type: QuestType.BATTLE, title: 'FINAL ACT: PHASE III', bossName: 'Geometric Sun', phase: 'Ratio', hp: 2500, speed: 0.82, interval: 600, bossColor: '#fff', isMinigun: true, shape: 'sun', forceLanes: 8, deathType: 'shatter' },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "Core layer 3 breached. All defense restrictions removed. Critical Spam Mode." },
      { type: QuestType.BATTLE, title: 'FINAL ACT: PHASE IV', bossName: 'Geometric Sun', phase: 'Formula', hp: 2500, speed: 0.85, interval: 550, bossColor: '#fff', isShotgun: true, isMinigun: true, shape: 'sun', forceLanes: 8, deathType: 'shatter' },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "WARNING: Core Collapse Imminent. The Sun is outputting pure chaotic frequency!" },
      { type: QuestType.BATTLE, title: 'FINAL ACT: PHASE V', bossName: 'Geometric Sun', phase: 'Zero Point', hp: 2500, speed: 0.90, interval: 500, bossColor: '#fff', isSpamming: true, isShotgun: true, isMinigun: true, shape: 'sun', forceLanes: 8, deathType: 'shatter' },
      { type: QuestType.DIALOGUE, speaker: 'Kitsune', text: "The Silence is over. The cosmos can finally scream in color." },
      { type: QuestType.DIALOGUE, speaker: 'Eto', text: "That was the coolest thing I've ever seen! Look at the stars!" },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "Logic core normalized. The Melody of reality is restored." },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "Terminal Archive Finalized. Thank you, Harmonizer." },
      { type: QuestType.CELEBRATION }
    ]
  },
  {
    name: "Act V", desc: "The Echoes of Creation",
    quests: [
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "The Sun's core has dissipated. Scanning for residual logic gates..." },
      { type: QuestType.DIALOGUE, speaker: 'Eto', text: "Wait... do you hear that? It's not a song, and it's not silence." },
      { type: QuestType.DIALOGUE, speaker: 'Kitsune', text: "It is the sound of the Prime Frequency. Someone else is here." },
      { type: QuestType.DIALOGUE, speaker: 'SERAPH', text: "Greetings, travelers. I am Seraph. The echo of what the universe was before the Fracture." },
      { type: QuestType.DIALOGUE, speaker: 'Eto', text: "Another spirit? Where have you been hiding?" },
      { type: QuestType.DIALOGUE, speaker: 'SERAPH', text: "In the cracks of the code. The Sun was a shell, but the terminal... it is still hungry." },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "New Signature Detected: SERAPH. Status: ARCHIVAL." },
      { type: QuestType.DIALOGUE, speaker: 'SERAPH', text: "Harmonizer {name}, you have done well. But you must understand why the Silence was created." },
      { type: QuestType.DIALOGUE, speaker: 'SERAPH', text: "It was not for perfection. It was a lock to keep the Archon from returning." },
      { type: QuestType.DIALOGUE, speaker: 'Kitsune', text: "The Archon... I haven't heard that name since the strings first snapped." },
      { type: QuestType.DIALOGUE, speaker: 'Eto', text: "Is it a person? A virus? A bad song?" },
      { type: QuestType.DIALOGUE, speaker: 'SERAPH', text: "It is the reset button. A force that sees every note as a mistake." },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "Detecting localized glitching. The terminal interface is vibrating at 10-string capacity." },
      { type: QuestType.DIALOGUE, speaker: 'Kitsune', text: "If the Archon returns, our memories will be the first things deleted." },
      { type: QuestType.DIALOGUE, speaker: 'SERAPH', text: "The Sun tried to solve the universe. The Archon just wants to close the file." },
      { type: QuestType.DIALOGUE, speaker: 'Eto', text: "Well, we have {name}! They beat the Sun, they can beat anything!" },
      { type: QuestType.SERAPH, speaker: 'SERAPH', text: "I hope you are right. Because the terminal ID logs are already shifting." },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "Warning: Restricted Protocol 'ZERO' has been pinged by an external source." },
      { type: QuestType.DIALOGUE, speaker: 'Kitsune', text: "Traveler... your presence feels heavier. Are you sure you are who you say you are?" },
      { type: QuestType.DIALOGUE, speaker: 'SERAPH', text: "The Melody is a shield. As long as you play, the universe remains." },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "Terminal stabilization failed. Searching for secondary logic anchors..." },
      { type: QuestType.DIALOGUE, speaker: 'Eto', text: "Let's stay together. Whatever happens next, we do it in harmony." },
      { type: QuestType.END_ACT, unlock: 5 }
    ]
  },
  {
    name: "Act VI", desc: "Universe Corrupted",
    quests: [
      { type: QuestType.DIALOGUE, speaker: 'ARCHON', text: "Initialization complete. All 10 strings forced into high-entropy state." },
      { type: QuestType.DIALOGUE, speaker: 'Eto', text: "Wait... Archon? What is this name? Everything is... glitching out!" },
      { type: QuestType.BATTLE, title: 'ARCHON: PHASE I', bossName: 'Void Singularity', phase: 'Entropy', hp: 3000, speed: 0.85, interval: 700, bossColor: '#ef4444', shape: 'archon', forceLanes: 10, deathType: 'glitch' },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "Logic collapse detected. Singular point expansion at 400%." },
      { type: QuestType.BATTLE, title: 'ARCHON: PHASE II', bossName: 'Void Singularity', phase: 'Static', hp: 3000, speed: 0.88, interval: 650, bossColor: '#ef4444', isShotgun: true, shape: 'archon', forceLanes: 10, deathType: 'glitch' },
      { type: QuestType.DIALOGUE, speaker: 'ARCHON', text: "The universe was meant to be silent. You are the error." },
      { type: QuestType.BATTLE, title: 'ARCHON: PHASE III', bossName: 'Void Singularity', phase: 'Fragment', hp: 3000, speed: 0.90, interval: 600, bossColor: '#ef4444', isMinigun: true, shape: 'archon', forceLanes: 10, deathType: 'glitch' },
      { type: QuestType.DIALOGUE, speaker: 'Eto', text: "I can't feel my limbs! Archon, stop this!" },
      { type: QuestType.BATTLE, title: 'ARCHON: PHASE IV', bossName: 'Void Singularity', phase: 'Singularity', hp: 3000, speed: 0.92, interval: 550, bossColor: '#ef4444', isShotgun: true, isMinigun: true, shape: 'archon', forceLanes: 10, deathType: 'glitch' },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "PROTOCOL ZERO ENGAGED. TOTAL SPAM AUTHORIZED." },
      { type: QuestType.BATTLE, title: 'ARCHON: PHASE V', bossName: 'Void Singularity', phase: 'Nullify', hp: 3000, speed: 0.94, interval: 500, bossColor: '#ef4444', isSpamming: true, shape: 'archon', forceLanes: 10, deathType: 'glitch' },
      { type: QuestType.DIALOGUE, speaker: 'ARCHON', text: "Everything must end. Even the song." },
      { type: QuestType.BATTLE, title: 'ARCHON: PHASE VI', bossName: 'Void Singularity', phase: 'Void', hp: 3000, speed: 0.96, interval: 450, bossColor: '#ef4444', isShotgun: true, isMinigun: true, isSpamming: true, shape: 'archon', forceLanes: 10, deathType: 'glitch' },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "CRITICAL COLLAPSE. THE ZERO POINT IS HERE." },
      { type: QuestType.BATTLE, title: 'ARCHON: PHASE VII', bossName: 'Void Singularity', phase: 'End of Time', hp: 5000, speed: 1.0, interval: 400, bossColor: '#ef4444', isShotgun: true, isMinigun: true, isSpamming: true, shape: 'archon', forceLanes: 10, deathType: 'glitch' },
      { type: QuestType.DIALOGUE, speaker: 'Eto', text: "Archon... why?" },
      { type: QuestType.DIALOGUE, speaker: 'INTERFACE', text: "Cosmos status: DELETED." },
      { type: QuestType.DIALOGUE, speaker: 'ARCHON', text: "Perfect silence at last." },
      { type: QuestType.DIALOGUE, speaker: 'SYSTEM', text: "UNIVERSE REBOOTING... STANDBY." },
      { type: QuestType.CELEBRATION }
    ]
  }
];
