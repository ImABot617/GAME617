
export enum QuestType {
  DIALOGUE = 'dialogue',
  BATTLE = 'battle',
  BROADCAST = 'broadcast',
  END_ACT = 'end_act',
  CELEBRATION = 'celebration',
  SERAPH = 'seraph'
}

export interface Quest {
  type: QuestType;
  speaker?: string;
  text?: string;
  echoText?: string;
  archonText?: string;
  title?: string;
  bossName?: string;
  phase?: string;
  hp?: number;
  speed?: number;
  interval?: number;
  bossColor?: string;
  shape?: 'abomination' | 'dragon' | 'kitsune' | 'sun' | 'archon';
  deathType?: 'glitch' | 'shatter';
  isShotgun?: boolean;
  isMinigun?: boolean;
  isSpamming?: boolean;
  forceLanes?: number;
  unlock?: number;
}

export interface Act {
  name: string;
  desc: string;
  quests: Quest[];
}

export interface Note {
  id: string;
  lane: number;
  y: number;
  type: 'normal' | 'purple' | 'gold' | 'corrupted';
}

export type GameState = 'menu' | 'story' | 'battle' | 'celebration' | 'credits';
