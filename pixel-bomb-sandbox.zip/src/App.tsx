/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bomb as BombIcon, 
  Trash2, 
  RefreshCw, 
  Wind, 
  Flame, 
  Zap, 
  Settings2,
  Maximize2,
  Minimize2,
  User,
  Target,
  Sparkles,
  CircleDot,
  ArrowDown,
  Ghost,
  Skull,
  Radiation,
  Cloud,
  Atom,
  Rocket,
  Circle,
  Waves,
  PartyPopper,
  Hammer,
  ArrowDownCircle,
  Snowflake,
  LayoutGrid,
  ArrowUpCircle,
  Box,
  FlameKindling,
  Biohazard,
  Zap as ZapIcon,
  Sun as SunIcon,
  Moon as MoonIcon,
  CloudRain,
  Tornado,
  Dna,
  Clock,
  Move,
  Activity,
  CircleDashed,
  Mountain,
  Telescope,
  Shield,
  Bot,
  Bug,
  PawPrint,
  Fish,
  CloudLightning,
  ZoomIn,
  ZoomOut,
  Waves as OceanIcon,
} from 'lucide-react';

// --- Constants & Types ---

const VIEWPORT_WIDTH = 800;
const VIEWPORT_HEIGHT = 450;
const WORLD_WIDTH = 8000;
const WORLD_HEIGHT = 1200; // Added vertical space
const PIXEL_SIZE = 4;
const GRID_COLS = Math.floor(WORLD_WIDTH / PIXEL_SIZE);
const GRID_ROWS = Math.floor(WORLD_HEIGHT / PIXEL_SIZE);

type MapType = 'city' | 'bunker' | 'forest' | 'cavern' | 'sun' | 'moon' | 'mars' | 'ocean';

type BombType = {
  id: string;
  name: string;
  icon: React.ReactNode;
  color: string;
  physicalRadius: number;
  explosionRadius: number;
  power: number;
  description: string;
  specialEffect?: 'flash' | 'fire' | 'gas' | 'disease' | 'confetti' | 'firework' | 'antimatter' | 'iron' | 'build' | 'vacuum' | 'ice' | 'cluster' | 'lightning' | 'gravity' | 'laser' | 'laser-rain' | 'black-hole' | 'acid' | 'meteor' | 'solar-flare' | 'pulse' | 'nano' | 'warp' | 'time-stop' | 'tornado' | 'sundial' | 'tsar' | 'sun' | 'moon' | 'bombomb' | 'thunderstorm' | 'shield' | 'alien' | 'shockwave';
};

const BLUEPRINTS: Record<string, number[][]> = {
  banana: [
    [0, 5, 5, 0],
    [5, 5, 5, 5],
    [5, 5, 5, 5],
    [0, 5, 5, 0],
  ],
  human: [
    [0, 2, 2, 0],
    [0, 2, 2, 0],
    [2, 2, 2, 2],
    [0, 2, 2, 0],
    [0, 2, 2, 0],
    [2, 0, 0, 2],
  ],
  house: [
    [0, 1, 1, 1, 0],
    [1, 1, 1, 1, 1],
    [2, 2, 5, 2, 2],
    [2, 2, 2, 2, 2],
    [2, 2, 2, 2, 2],
  ],
  tree: [
    [0, 4, 4, 0],
    [4, 4, 4, 4],
    [0, 3, 3, 0],
    [0, 3, 3, 0],
  ],
  castle: [
    [2, 0, 2, 0, 2],
    [2, 2, 2, 2, 2],
    [2, 1, 1, 1, 2],
    [2, 1, 0, 1, 2],
    [2, 1, 1, 1, 2],
  ],
  tower: [
    [1, 1, 1],
    [1, 5, 1],
    [1, 1, 1],
    [1, 5, 1],
    [1, 1, 1],
    [1, 5, 1],
    [1, 1, 1],
  ],
  bunker: [
    [6, 6, 6, 6, 6, 6, 6],
    [6, 1, 1, 1, 1, 1, 6],
    [6, 1, 0, 0, 0, 1, 6],
    [6, 1, 1, 1, 1, 1, 6],
    [6, 6, 6, 6, 6, 6, 6],
  ],
  pyramid: [
    [0, 0, 2, 0, 0],
    [0, 2, 2, 2, 0],
    [2, 2, 2, 2, 2],
  ],
  bridge: [
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
  ]
};

const BIG_BLUEPRINTS: Record<string, number[][]> = {
  fortress: [
    [2, 0, 2, 0, 2, 0, 2, 0, 2],
    [2, 2, 2, 2, 2, 2, 2, 2, 2],
    [2, 1, 1, 1, 1, 1, 1, 1, 2],
    [2, 1, 5, 1, 5, 1, 5, 1, 2],
    [2, 1, 1, 1, 1, 1, 1, 1, 2],
    [2, 1, 5, 1, 0, 1, 5, 1, 2],
    [2, 1, 1, 1, 0, 1, 1, 1, 2],
    [2, 2, 2, 2, 0, 2, 2, 2, 2],
  ],
  skyscraper: [
    [1, 1, 1, 1, 1],
    [1, 5, 5, 5, 1],
    [1, 5, 5, 5, 1],
    [1, 1, 1, 1, 1],
    [1, 5, 5, 5, 1],
    [1, 5, 5, 5, 1],
    [1, 1, 1, 1, 1],
    [1, 5, 5, 5, 1],
    [1, 5, 5, 5, 1],
    [1, 1, 1, 1, 1],
    [1, 5, 5, 5, 1],
    [1, 5, 5, 5, 1],
    [1, 1, 1, 1, 1],
  ],
  mega_pyramid: [
    [0, 0, 0, 0, 2, 0, 0, 0, 0],
    [0, 0, 0, 2, 2, 2, 0, 0, 0],
    [0, 0, 2, 2, 2, 2, 2, 0, 0],
    [0, 2, 2, 2, 2, 2, 2, 2, 0],
    [2, 2, 2, 2, 2, 2, 2, 2, 2],
  ]
};

const BOMB_TYPES: BombType[] = [
  { id: 'smoke', name: 'Smoke', icon: <Wind className="w-4 h-4" />, color: '#94a3b8', physicalRadius: 6, explosionRadius: 40, power: 0, description: 'Creates thick smoke.', specialEffect: 'gas' },
  { id: 'dynamite', name: 'Dynamite', icon: <Flame className="w-4 h-4" />, color: '#ef4444', physicalRadius: 5, explosionRadius: 30, power: 2, description: 'Standard explosive.' },
  { id: 'tnt', name: 'TNT', icon: <Target className="w-4 h-4" />, color: '#dc2626', physicalRadius: 6, explosionRadius: 45, power: 4, description: 'Classic high explosive.' },
  { id: 'c4', name: 'C4', icon: <Target className="w-4 h-4" />, color: '#475569', physicalRadius: 4, explosionRadius: 60, power: 10, description: 'Plastic explosive.' },
  { id: 'grenade', name: 'Grenade', icon: <CircleDot className="w-4 h-4" />, color: '#166534', physicalRadius: 4, explosionRadius: 35, power: 5, description: 'Fragmentation.' },
  { id: 'flashbang', name: 'Flashbang', icon: <Sparkles className="w-4 h-4" />, color: '#f8fafc', physicalRadius: 4, explosionRadius: 80, power: 0, description: 'Blinds everyone.', specialEffect: 'flash' },
  { id: 'fireball', name: 'Fireball', icon: <Flame className="w-4 h-4" />, color: '#f97316', physicalRadius: 10, explosionRadius: 50, power: 6, description: 'Pure fire.', specialEffect: 'fire' },
  { id: 'incendiary', name: 'Incendiary', icon: <FlameKindling className="w-4 h-4" />, color: '#ea580c', physicalRadius: 6, explosionRadius: 90, power: 3, description: 'Spreads fire.', specialEffect: 'fire' },
  { id: 'gas', name: 'Gas Bomb', icon: <Cloud className="w-4 h-4" />, color: '#84cc16', physicalRadius: 7, explosionRadius: 100, power: 0, description: 'Toxic green gas.', specialEffect: 'gas' },
  { id: 'disease', name: 'Disease', icon: <Biohazard className="w-4 h-4" />, color: '#65a30d', physicalRadius: 5, explosionRadius: 60, power: 0, description: 'Spreads pathogen.', specialEffect: 'disease' },
  { id: 'nuke', name: 'Nuke', icon: <Radiation className="w-4 h-4" />, color: '#facc15', physicalRadius: 12, explosionRadius: 250, power: 50, description: 'Tactical nuclear.', specialEffect: 'flash' },
  { id: 'tsar', name: 'Tsar Bomba', icon: <Skull className="w-4 h-4" />, color: '#7f1d1d', physicalRadius: 15, explosionRadius: 500, power: 300, description: 'The ultimate weapon.', specialEffect: 'tsar' },
  { id: 'antimatter', name: 'Antimatter', icon: <Atom className="w-4 h-4" />, color: '#a855f7', physicalRadius: 2, explosionRadius: 600, power: 200, description: 'Annihilates matter.', specialEffect: 'antimatter' },
  { id: 'iron-ball', name: 'Iron Ball', icon: <Circle className="w-4 h-4" />, color: '#1e293b', physicalRadius: 15, explosionRadius: 5, power: 20, description: 'Heavy iron ball.', specialEffect: 'iron' },
  { id: 'shockwave', name: 'Shockwave', icon: <Waves className="w-4 h-4" />, color: '#60a5fa', physicalRadius: 5, explosionRadius: 200, power: 10, description: 'Zelda plunge shockwave.', specialEffect: 'shockwave' },
  { id: 'build', name: 'Build Bomb', icon: <Hammer className="w-4 h-4" />, color: '#10b981', physicalRadius: 5, explosionRadius: 40, power: 0, description: 'Constructs structures.', specialEffect: 'build' },
  { id: 'vacuum', name: 'Vacuum', icon: <ArrowDownCircle className="w-4 h-4" />, color: '#6366f1', physicalRadius: 5, explosionRadius: 120, power: 0, description: 'Pulls inward.', specialEffect: 'vacuum' },
  { id: 'ice', name: 'Ice Bomb', icon: <Snowflake className="w-4 h-4" />, color: '#0ea5e9', physicalRadius: 6, explosionRadius: 60, power: 0, description: 'Freezes pixels.', specialEffect: 'ice' },
  { id: 'cluster', name: 'Cluster', icon: <LayoutGrid className="w-4 h-4" />, color: '#7c3aed', physicalRadius: 8, explosionRadius: 40, power: 10, description: 'Splits up.', specialEffect: 'cluster' },
  { id: 'lightning', name: 'Lightning', icon: <Zap className="w-4 h-4 text-yellow-400" />, color: '#ffffff', physicalRadius: 2, explosionRadius: 20, power: 40, description: 'Energy strike.', specialEffect: 'lightning' },
  { id: 'gravity', name: 'Gravity', icon: <ArrowUpCircle className="w-4 h-4" />, color: '#f472b6', physicalRadius: 5, explosionRadius: 100, power: 0, description: 'Flips gravity.', specialEffect: 'gravity' },
  { id: 'laser', name: 'Laser', icon: <ZapIcon className="w-4 h-4 text-red-500" />, color: '#ff0000', physicalRadius: 2, explosionRadius: 10, power: 100, description: 'High-intensity beam.', specialEffect: 'laser' },
  { id: 'laser-rain', name: 'Laser Rain', icon: <CloudRain className="w-4 h-4 text-red-400" />, color: '#ff4444', physicalRadius: 4, explosionRadius: 15, power: 50, description: 'Saturates area.', specialEffect: 'laser-rain' },
  { id: 'black-hole', name: 'Black Hole', icon: <CircleDashed className="w-4 h-4 text-purple-600" />, color: '#000000', physicalRadius: 8, explosionRadius: 200, power: 500, description: 'Singularity.', specialEffect: 'black-hole' },
  { id: 'acid', name: 'Acid Rain', icon: <CloudRain className="w-4 h-4 text-green-500" />, color: '#22c55e', physicalRadius: 6, explosionRadius: 150, power: 2, description: 'Corrosive downpour.', specialEffect: 'acid' },
  { id: 'meteor', name: 'Meteor', icon: <Mountain className="w-4 h-4 text-orange-700" />, color: '#7c2d12', physicalRadius: 20, explosionRadius: 180, power: 80, description: 'Celestial impact.', specialEffect: 'meteor' },
  { id: 'solar-flare', name: 'Solar Flare', icon: <SunIcon className="w-4 h-4 text-yellow-500" />, color: '#eab308', physicalRadius: 10, explosionRadius: 300, power: 40, description: 'Heat wave.', specialEffect: 'solar-flare' },
  { id: 'pulse', name: 'Pulse', icon: <Activity className="w-4 h-4 text-blue-400" />, color: '#60a5fa', physicalRadius: 5, explosionRadius: 250, power: 5, description: 'EM surge.', specialEffect: 'pulse' },
  { id: 'nano', name: 'Nano-Swarm', icon: <Dna className="w-4 h-4 text-teal-400" />, color: '#2dd4bf', physicalRadius: 4, explosionRadius: 100, power: 1, description: 'Disassembles matter.', specialEffect: 'nano' },
  { id: 'warp', name: 'Warp', icon: <Move className="w-4 h-4 text-indigo-400" />, color: '#818cf8', physicalRadius: 6, explosionRadius: 120, power: 0, description: 'Teleports.', specialEffect: 'warp' },
  { id: 'time-stop', name: 'Time Stop', icon: <Clock className="w-4 h-4 text-cyan-400" />, color: '#22d3ee', physicalRadius: 5, explosionRadius: 300, power: 0, description: 'Freezes time.', specialEffect: 'time-stop' },
  { id: 'tornado', name: 'Tornado', icon: <Tornado className="w-4 h-4 text-slate-400" />, color: '#94a3b8', physicalRadius: 10, explosionRadius: 150, power: 5, description: 'Vortex.', specialEffect: 'tornado' },
  { id: 'sundial', name: 'Sundial', icon: <Clock className="w-4 h-4" />, color: '#fde047', physicalRadius: 5, explosionRadius: 800, power: 400, description: 'Antimatter + Hydrogen x2.', specialEffect: 'sundial' },
  { id: 'sun', name: 'Sun Bomb', icon: <SunIcon className="w-4 h-4" />, color: '#ef4444', physicalRadius: 20, explosionRadius: 500, power: 150, description: 'The power of a star.', specialEffect: 'sun' },
  { id: 'moon', name: 'Moon Bomb', icon: <MoonIcon className="w-4 h-4" />, color: '#cbd5e1', physicalRadius: 15, explosionRadius: 400, power: 80, description: 'Lunar impact + Gravity.', specialEffect: 'moon' },
  { id: 'bombomb', name: 'Bom-omb', icon: <BombIcon className="w-4 h-4 text-black" />, color: '#1e293b', physicalRadius: 8, explosionRadius: 80, power: 20, description: 'Walking explosive.', specialEffect: 'bombomb' },
  { id: 'thunderstorm', name: 'Thunderstorm', icon: <CloudLightning className="w-4 h-4" />, color: '#38bdf8', physicalRadius: 5, explosionRadius: 200, power: 10, description: 'Summons a storm.', specialEffect: 'thunderstorm' },
  { id: 'shield', name: 'Shield Bomb', icon: <Shield className="w-4 h-4" />, color: '#34d399', physicalRadius: 5, explosionRadius: 100, power: 0, description: 'Creates a barrier.', specialEffect: 'shield' },
  { id: 'alien', name: 'Alien Bomb', icon: <Telescope className="w-4 h-4" />, color: '#a855f7', physicalRadius: 5, explosionRadius: 150, power: 10, description: 'Extraterrestrial tech.', specialEffect: 'alien' },
  { id: 'big-build', name: 'Big Build Bomb', icon: <Hammer className="w-6 h-6" />, color: '#059669', physicalRadius: 8, explosionRadius: 80, power: 0, description: 'Constructs massive structures.', specialEffect: 'build' },
];

type MobType = 'human' | 'dinosaur' | 'alien' | 'robot' | 'axolotl' | 'bombomb';

type ShieldEntity = {
  id: number;
  x: number;
  y: number;
  radius: number;
  health: number;
  maxHealth: number;
  color: string;
};

type Mob = {
  id: number;
  type: MobType;
  x: number;
  y: number;
  vx: number;
  vy: number;
  isDead: boolean;
  health: number;
  maxHealth: number;
  color: string;
  size: number;
  isBoss?: boolean;
  phase?: number;
};

type Human = Mob;

type SizeMultiplier = 'small' | 'medium' | 'large';
const SIZE_FACTORS: Record<SizeMultiplier, number> = {
  small: 0.6,
  medium: 1.0,
  large: 1.6,
};

type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
  type?: 'debris' | 'gas' | 'fire' | 'blood' | 'confetti' | 'antimatter' | 'acid' | 'nano';
};

type ActiveBomb = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  type: BombType;
  sizeFactor: number;
  life?: number;
  maxLife?: number;
};

type Explosion = {
  x: number;
  y: number;
  radius: number;
  life: number;
  maxLife: number;
  color: string;
  power: number;
  type?: string;
};

// --- Main Component ---

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [selectedBomb, setSelectedBomb] = useState<BombType>(BOMB_TYPES[1]);
  const [sizeMultiplier, setSizeMultiplier] = useState<SizeMultiplier>('medium');
  const [isDragging, setIsDragging] = useState(false);
  const [cameraX, setCameraX] = useState(0);
  const [cameraY, setCameraY] = useState(WORLD_HEIGHT - VIEWPORT_HEIGHT);
  const [zoom, setZoom] = useState(1);
  const [followMode, setFollowMode] = useState(true);
  const [currentMap, setCurrentMap] = useState<MapType>('city');
  const [flashEnabled, setFlashEnabled] = useState(true);
  
  // Game State Refs
  const gridRef = useRef<Uint8Array>(new Uint8Array(GRID_COLS * GRID_ROWS));
  const bombsRef = useRef<ActiveBomb[]>([]);
  const explosionsRef = useRef<Explosion[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const humansRef = useRef<Human[]>([]);
  const shieldsRef = useRef<ShieldEntity[]>([]);
  const bossRef = useRef<Mob | null>(null);
  const lastDropTime = useRef<number>(0);
  const flashRef = useRef<number>(0);
  const cameraXRef = useRef(0);
  const cameraYRef = useRef(WORLD_HEIGHT - VIEWPORT_HEIGHT);
  const zoomRef = useRef(1);

  // Sync state to refs for use in the game loop
  useEffect(() => { cameraXRef.current = cameraX; }, [cameraX]);
  useEffect(() => { cameraYRef.current = cameraY; }, [cameraY]);
  useEffect(() => { zoomRef.current = zoom; }, [zoom]);

  // --- Arrow Key Controls ---
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const step = 20;
      if (e.key === 'ArrowLeft') {
        setCameraX(prev => Math.max(0, prev - step));
        setFollowMode(false);
      }
      if (e.key === 'ArrowRight') {
        setCameraX(prev => Math.min(WORLD_WIDTH - VIEWPORT_WIDTH, prev + step));
        setFollowMode(false);
      }
      if (e.key === 'ArrowUp') {
        setCameraY(prev => Math.max(0, prev - step));
        setFollowMode(false);
      }
      if (e.key === 'ArrowDown') {
        setCameraY(prev => Math.min(WORLD_HEIGHT - VIEWPORT_HEIGHT, prev + step));
        setFollowMode(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // --- Initialization ---

  const initCity = useCallback(() => {
    const grid = gridRef.current;
    grid.fill(0);

    // Ground level
    const groundY = GRID_ROWS - 5;
    for (let x = 0; x < GRID_COLS; x++) {
      for (let y = groundY; y < GRID_ROWS; y++) {
        grid[y * GRID_COLS + x] = currentMap === 'sun' ? 5 : 1; // Ground
      }
      // Bedrock at the very bottom
      grid[(GRID_ROWS - 1) * GRID_COLS + x] = 6;
      grid[(GRID_ROWS - 2) * GRID_COLS + x] = 6;
    }

    if (currentMap === 'city') {
      // Generate buildings across the whole world
      let x = 5;
      while (x < GRID_COLS - 10) {
        const type = Math.random();
        let bWidth, bHeight;
        
        if (type > 0.9) { // Mega Skyscraper
          bWidth = Math.floor(Math.random() * 8) + 12;
          bHeight = Math.floor(Math.random() * 80) + 60;
        } else if (type > 0.7) { // Skyscraper
          bWidth = Math.floor(Math.random() * 6) + 8;
          bHeight = Math.floor(Math.random() * 50) + 40;
        } else if (type > 0.3) { // Standard building
          bWidth = Math.floor(Math.random() * 8) + 6;
          bHeight = Math.floor(Math.random() * 30) + 20;
        } else { // Small house/shop
          bWidth = Math.floor(Math.random() * 6) + 4;
          bHeight = Math.floor(Math.random() * 15) + 8;
        }

        const bColor = Math.floor(Math.random() * 3) + 2;

        for (let bx = 0; bx < bWidth; bx++) {
          if (x + bx >= GRID_COLS) break;
          for (let by = 0; by < bHeight; by++) {
            const gy = groundY - 1 - by;
            if (gy < 0) break;
            
            const isWindow = bx > 0 && bx < bWidth - 1 && by % 5 === 3 && bx % 3 === 1;
            const isRoof = by === bHeight - 1;
            
            if (isWindow) {
              grid[gy * GRID_COLS + (x + bx)] = 5;
            } else if (isRoof) {
              grid[gy * GRID_COLS + (x + bx)] = 1;
            } else {
              grid[gy * GRID_COLS + (x + bx)] = bColor;
            }
          }
        }
        x += bWidth + Math.floor(Math.random() * 15) + 2;
      }
    } else if (currentMap === 'forest') {
      let x = 5;
      while (x < GRID_COLS - 5) {
        const treeHeight = Math.floor(Math.random() * 15) + 10;
        for (let th = 0; th < treeHeight; th++) {
          const gy = groundY - 1 - th;
          grid[gy * GRID_COLS + x] = 3; // Trunk
          if (th > treeHeight - 6) {
            const leafWidth = Math.floor((treeHeight - th) * 1.5);
            for (let tw = -leafWidth; tw <= leafWidth; tw++) {
              if (x + tw >= 0 && x + tw < GRID_COLS) {
                grid[gy * GRID_COLS + (x + tw)] = 4; // Leaves
              }
            }
          }
        }
        x += Math.floor(Math.random() * 15) + 8;
      }
    } else if (currentMap === 'bunker') {
      // Surface layer
      const surfaceY = groundY - 100;
      for (let x = 0; x < GRID_COLS; x++) {
        for (let y = surfaceY; y < surfaceY + 5; y++) {
          grid[y * GRID_COLS + x] = 1;
        }
      }
      // Underground structure
      const ceilingY = surfaceY + 20;
      for (let x = 0; x < GRID_COLS; x++) {
        for (let y = ceilingY; y < ceilingY + 10; y++) {
          grid[y * GRID_COLS + x] = 1;
        }
      }
      // Add some Lead and Obsidian patches to the bunker
      for (let i = 0; i < 10; i++) {
        const bx = Math.floor(Math.random() * GRID_COLS);
        const by = ceilingY + Math.floor(Math.random() * (groundY - ceilingY));
        const br = 5 + Math.floor(Math.random() * 5);
        for (let dx = -br; dx <= br; dx++) {
          for (let dy = -br; dy <= br; dy++) {
            if (dx*dx + dy*dy <= br*br) {
              const nx = bx + dx;
              const ny = by + dy;
              if (nx >= 0 && nx < GRID_COLS && ny >= 0 && ny < GRID_ROWS) {
                grid[ny * GRID_COLS + nx] = Math.random() < 0.5 ? 9 : 11;
              }
            }
          }
        }
      }
      // Pillars
      for (let x = 0; x < GRID_COLS; x += 60) {
        for (let y = ceilingY; y < groundY; y++) {
          for (let pw = 0; pw < 6; pw++) {
            if (x + pw < GRID_COLS) grid[y * GRID_COLS + (x + pw)] = 1;
          }
        }
      }
    } else if (currentMap === 'ocean') {
      // Water map
      for (let x = 0; x < GRID_COLS; x++) {
        for (let y = groundY - 100; y < groundY; y++) {
          grid[y * GRID_COLS + x] = 7; // Water/Ocean
        }
      }
      // Spawn Boss Axolotl
      bossRef.current = {
        id: 9999,
        type: 'axolotl',
        x: WORLD_WIDTH / 2,
        y: (GRID_ROWS - 50) * PIXEL_SIZE,
        vx: 0,
        vy: 0,
        isDead: false,
        health: 5000,
        maxHealth: 5000,
        color: '#f472b6',
        size: 50,
        isBoss: true,
        phase: 1
      };
    } else if (currentMap === 'cavern') {
      // Rocky ceiling
      for (let x = 0; x < GRID_COLS; x++) {
        const h = Math.floor(Math.random() * 10) + 5;
        for (let y = 0; y < h; y++) {
          grid[y * GRID_COLS + x] = 2;
        }
        // Stalactites
        if (Math.random() < 0.05) {
          const sLen = Math.floor(Math.random() * 15) + 5;
          for (let sy = 0; sy < sLen; sy++) {
            grid[(h + sy) * GRID_COLS + x] = 2;
          }
        }
      }
    } else if (currentMap === 'moon' || currentMap === 'mars') {
      // Craters
      for (let i = 0; i < 20; i++) {
        const cx = Math.floor(Math.random() * GRID_COLS);
        const cr = Math.floor(Math.random() * 20) + 10;
        for (let dx = -cr; dx <= cr; dx++) {
          const nx = cx + dx;
          if (nx >= 0 && nx < GRID_COLS) {
            const dy = Math.floor(Math.sqrt(cr * cr - dx * dx));
            for (let y = groundY - dy; y < groundY; y++) {
              grid[y * GRID_COLS + nx] = 0;
            }
          }
        }
      }
    }

    // Spawn Mobs
    humansRef.current = [];
    const mobCount = currentMap === 'sun' ? 0 : 200;
    const types: MobType[] = ['human', 'dinosaur', 'alien', 'robot'];
    
    for (let i = 0; i < mobCount; i++) {
      const type = currentMap === 'moon' ? 'alien' : (currentMap === 'bunker' ? 'robot' : (currentMap === 'forest' ? 'dinosaur' : types[Math.floor(Math.random() * types.length)]));
      humansRef.current.push({
        id: i,
        type: type,
        x: Math.random() * WORLD_WIDTH,
        y: (GRID_ROWS - 6) * PIXEL_SIZE,
        vx: (Math.random() - 0.5) * 1,
        vy: 0,
        isDead: false,
        health: type === 'dinosaur' ? 200 : (type === 'robot' ? 150 : 100),
        maxHealth: type === 'dinosaur' ? 200 : (type === 'robot' ? 150 : 100),
        color: type === 'alien' ? '#a855f7' : (type === 'robot' ? '#94a3b8' : (type === 'dinosaur' ? '#166534' : `hsl(${Math.random() * 360}, 70%, 60%)`)),
        size: type === 'dinosaur' ? 1.5 : 1
      });
    }
    
    setCameraX(0);
    setCameraY(WORLD_HEIGHT - VIEWPORT_HEIGHT);
  }, [currentMap]);

  useEffect(() => {
    initCity();
  }, [initCity]);

  // --- Game Logic ---

  const createExplosion = (x: number, y: number, radius: number, power: number, color: string, effect?: string) => {
    if (effect === 'flash' || effect === 'tsar' || effect === 'nuke') {
      if (flashEnabled) flashRef.current = effect === 'tsar' ? 2.0 : 1.0;
    }
    
    let maxLife = 20;
    if (effect === 'antimatter' || effect === 'sun') maxLife = 60;
    if (effect === 'time-stop') maxLife = 600; // 10 seconds
    if (effect === 'tornado') maxLife = 300; // 5 seconds
    if (effect === 'black-hole') maxLife = 200;

    explosionsRef.current.push({ x, y, radius, life: 0, maxLife, color, power, type: effect });

    if (effect === 'sun') {
      // Expanding fireball effect
      for (let i = 0; i < 20; i++) {
        const angle = (i / 20) * Math.PI * 2;
        particlesRef.current.push({
          x, y, vx: Math.cos(angle) * 5, vy: Math.sin(angle) * 5,
          life: 0, maxLife: 100, color: '#f97316', size: 10, type: 'fire'
        });
      }
    }

    if (effect === 'sundial') {
      if (flashEnabled) flashRef.current = 3.0;
      // Massive destruction logic is handled by the default grid destruction below
      // but we ensure it's powerful
    }

    if (effect === 'moon') {
      // Shoot rocks everywhere - BIGGER and MORE RANGE
      for (let i = 0; i < 100; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 5 + Math.random() * 20;
        particlesRef.current.push({
          x, y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed,
          life: 0, maxLife: 120, color: '#94a3b8', size: 6 + Math.random() * 6, type: 'debris'
        });
      }
    }

    if (effect === 'build') {
      const isBig = radius > 50; // Simple check for big build
      const source = isBig ? BIG_BLUEPRINTS : BLUEPRINTS;
      const blueprints = Object.keys(source);
      const blueprint = source[blueprints[Math.floor(Math.random() * blueprints.length)]];
      const startX = Math.floor(x / PIXEL_SIZE) - Math.floor(blueprint[0].length / 2);
      const startY = Math.floor(y / PIXEL_SIZE) - blueprint.length;
      
      for (let by = 0; by < blueprint.length; by++) {
        for (let bx = 0; bx < blueprint[by].length; bx++) {
          const nx = startX + bx;
          const ny = startY + by;
          if (nx >= 0 && nx < GRID_COLS && ny >= 0 && ny < GRID_ROWS) {
            if (blueprint[by][bx] !== 0) {
              gridRef.current[ny * GRID_COLS + nx] = blueprint[by][bx];
            }
          }
        }
      }
      return;
    }

    if (effect === 'shockwave') {
      // Zelda plunge shockwave - travels outward
      for (let i = 0; i < 48; i++) {
        const angle = (i / 48) * Math.PI * 2;
        particlesRef.current.push({
          x, y, vx: Math.cos(angle) * 18, vy: Math.sin(angle) * 3,
          life: 0, maxLife: 60, color: '#ffffff', size: 8, type: 'debris'
        });
      }
      // Add some ground cracks/dust
      for (let i = 0; i < 20; i++) {
        particlesRef.current.push({
          x: x + (Math.random() - 0.5) * radius,
          y: y + (Math.random() - 0.5) * 10,
          vx: (Math.random() - 0.5) * 5,
          vy: -Math.random() * 8,
          life: 0, maxLife: 40, color: '#94a3b8', size: 4, type: 'debris'
        });
      }
    }

    if (effect === 'lightning' || effect === 'thunderstorm') {
      const count = effect === 'thunderstorm' ? 5 : 1;
      for (let c = 0; c < count; c++) {
        const lx = x + (Math.random() - 0.5) * (effect === 'thunderstorm' ? 300 : 0);
        const lgx = Math.floor(lx / PIXEL_SIZE);
        if (lgx >= 0 && lgx < GRID_COLS) {
          for (let ny = 0; ny < GRID_ROWS; ny++) {
            gridRef.current[ny * GRID_COLS + lgx] = 0;
            if (Math.random() < 0.2) {
              particlesRef.current.push({
                x: lx, y: ny * PIXEL_SIZE, vx: (Math.random() - 0.5) * 10, vy: (Math.random() - 0.5) * 10,
                life: 0, maxLife: 10, color: '#fff', size: 4
              });
            }
          }
        }
      }
      return;
    }

    if (effect === 'laser' || effect === 'laser-rain') {
      const count = effect === 'laser-rain' ? 10 : 1;
      for (let i = 0; i < count; i++) {
        const rx = x + (Math.random() - 0.5) * (effect === 'laser-rain' ? 200 : 0);
        const rgx = Math.floor(rx / PIXEL_SIZE);
        if (rgx >= 0 && rgx < GRID_COLS) {
          for (let ny = 0; ny < GRID_ROWS; ny++) {
            gridRef.current[ny * GRID_COLS + rgx] = 0;
          }
          explosionsRef.current.push({
            x: rx, y: y, radius: 5, life: 0, maxLife: 10, color: '#ff4444', power: 50, type: 'laser'
          });
        }
      }
      return;
    }

    if (effect === 'warp') {
      const targetX = Math.max(radius, Math.min(WORLD_WIDTH - radius, Math.random() * WORLD_WIDTH));
      const targetY = Math.max(radius, Math.min(WORLD_HEIGHT - radius, Math.random() * WORLD_HEIGHT));
      
      // Teleport Survivors
      humansRef.current.forEach(h => {
        const dx = h.x - x;
        const dy = h.y - y;
        if (Math.sqrt(dx*dx + dy*dy) < radius) {
          h.x = targetX + (h.x - x);
          h.y = targetY + (h.y - y);
        }
      });

      // Teleport Blocks
      const gx = Math.floor(x / PIXEL_SIZE);
      const gy = Math.floor(y / PIXEL_SIZE);
      const gr = Math.ceil(radius / PIXEL_SIZE);
      const targetGx = Math.floor(targetX / PIXEL_SIZE);
      const targetGy = Math.floor(targetY / PIXEL_SIZE);
      
      const capturedBlocks: {dx: number, dy: number, type: number}[] = [];
      const grid = gridRef.current;
      
      for (let dx = -gr; dx <= gr; dx++) {
        for (let dy = -gr; dy <= gr; dy++) {
          if (dx * dx + dy * dy <= gr * gr) {
            const nx = gx + dx;
            const ny = gy + dy;
            if (nx >= 0 && nx < GRID_COLS && ny >= 0 && ny < GRID_ROWS) {
              const idx = ny * GRID_COLS + nx;
              if (grid[idx] !== 0 && grid[idx] !== 6) { // Don't teleport bedrock
                capturedBlocks.push({dx, dy, type: grid[idx]});
                grid[idx] = 0;
              }
            }
          }
        }
      }
      
      capturedBlocks.forEach(b => {
        const nx = targetGx + b.dx;
        const ny = targetGy + b.dy;
        if (nx >= 0 && nx < GRID_COLS && ny >= 0 && ny < GRID_ROWS) {
          grid[ny * GRID_COLS + nx] = b.type;
        }
      });
      
      return;
    }

    if (effect === 'acid') {
      for (let i = 0; i < 50; i++) {
        particlesRef.current.push({
          x: x + (Math.random() - 0.5) * radius,
          y: y + (Math.random() - 0.5) * radius,
          vx: (Math.random() - 0.5) * 2,
          vy: Math.random() * 5,
          life: 0, maxLife: 200, color: '#22c55e', size: 3, type: 'acid'
        });
      }
      return;
    }

    if (effect === 'nano') {
      for (let i = 0; i < 30; i++) {
        particlesRef.current.push({
          x: x + (Math.random() - 0.5) * radius,
          y: y + (Math.random() - 0.5) * radius,
          vx: (Math.random() - 0.5) * 4,
          vy: (Math.random() - 0.5) * 4,
          life: 0, maxLife: 300, color: '#2dd4bf', size: 2, type: 'nano'
        });
      }
      return;
    }

    if (effect === 'meteor' || effect === 'sun' || effect === 'tsar' || effect === 'sundial') {
      const pCount = effect === 'sundial' ? 500 : (effect === 'meteor' ? 100 : 300);
      for (let i = 0; i < pCount; i++) {
        const angle = Math.random() * Math.PI * 2;
        const dist = Math.random() * radius;
        particlesRef.current.push({
          x: x + Math.cos(angle) * dist,
          y: y + Math.sin(angle) * dist,
          vx: Math.cos(angle) * (effect === 'meteor' ? 15 : 25),
          vy: Math.sin(angle) * (effect === 'meteor' ? 15 : 25),
          life: 0, maxLife: 100, color: (effect === 'sun' || effect === 'sundial') ? '#ef4444' : (effect === 'meteor' ? '#f97316' : '#ffffff'), size: 4, type: 'fire'
        });
      }
    }

    if (effect === 'black-hole') {
      for (let i = 0; i < 200; i++) {
        particlesRef.current.push({
          x: x + (Math.random() - 0.5) * radius,
          y: y + (Math.random() - 0.5) * radius,
          vx: (Math.random() - 0.5) * 2,
          vy: (Math.random() - 0.5) * 2,
          life: 0, maxLife: 150, color: '#a855f7', size: 2, type: 'antimatter'
        });
      }
    }

    // Destroy grid blocks
    const gx = Math.floor(x / PIXEL_SIZE);
    const gy = Math.floor(y / PIXEL_SIZE);
    const gr = Math.ceil(radius / PIXEL_SIZE);

    const grid = gridRef.current;
    for (let dx = -gr; dx <= gr; dx++) {
      for (let dy = -gr; dy <= gr; dy++) {
        const nx = gx + dx;
        const ny = gy + dy;
        if (nx >= 0 && nx < GRID_COLS && ny >= 0 && ny < GRID_ROWS) {
          const distSq = dx * dx + dy * dy;
          if (distSq <= gr * gr) {
            const idx = ny * GRID_COLS + nx;
            if (grid[idx] !== 0 && grid[idx] !== 6) { // Skip Bedrock
              const blockType = grid[idx];
              const dist = Math.sqrt(distSq);
              const falloff = 1 - (dist / gr);
              const effectivePower = effect === 'iron' ? power * 2 : power;
              
              let resistance = 1.0;
              // Material Resistances
              if (blockType === 9) { // Lead resists radiation
                if (effect === 'nuke' || effect === 'sun' || effect === 'sundial' || effect === 'solar-flare') resistance = 0.1;
              } else if (blockType === 10) { // Rubber resists shock/impact
                if (effect === 'shockwave' || effect === 'iron' || effect === 'grenade' || effect === 'tnt') resistance = 0.2;
              } else if (blockType === 11) { // Obsidian resists fire
                if (effect === 'fire' || effect === 'sun' || effect === 'meteor' || effect === 'incendiary') resistance = 0.05;
              } else if (blockType === 12) { // Forcefield resists almost everything
                resistance = 0.01;
                if (effect === 'antimatter' || effect === 'black-hole') resistance = 1.0;
              }

              if (Math.random() < falloff * (effectivePower / 5) * resistance || effectivePower > 15 || effect === 'antimatter' || effect === 'sun' || effect === 'tsar' || effect === 'sundial') {
                if (Math.random() < 0.3 && effect !== 'antimatter') {
                  particlesRef.current.push({
                    x: nx * PIXEL_SIZE, y: ny * PIXEL_SIZE,
                    vx: (Math.random() - 0.5) * 4, vy: (Math.random() - 0.5) * 4 - 2,
                    life: 0, maxLife: 30 + Math.random() * 20, color: getBlockColor(grid[idx]), size: 2
                  });
                }
                
                // Set things on fire for sun/meteor/tsar
                if ((effect === 'sun' || effect === 'meteor' || effect === 'tsar' || effect === 'sundial') && Math.random() < 0.2) {
                  grid[idx] = 8; // Molten Metal/Fire
                } else {
                  grid[idx] = 0;
                }
              }
            }
          }
        }
      }
    }

    // Damage Mobs
    humansRef.current.forEach(h => {
      if (h.isDead) return;
      const dx = h.x - x;
      const dy = h.y - y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < radius) {
        const damage = (1 - dist / radius) * power * 10;
        h.health -= damage;
        if (h.health <= 0 || power > 50 || effect === 'antimatter' || effect === 'sun' || effect === 'tsar') {
          h.isDead = true;
          h.vx = (dx / dist) * (power / 2 + 2);
          // Blood particles
          for (let i = 0; i < 5; i++) {
            particlesRef.current.push({
              x: h.x, y: h.y, vx: (Math.random() - 0.5) * 4, vy: (Math.random() - 0.5) * 4 - 2,
              life: 0, maxLife: 30, color: h.type === 'alien' ? '#a855f7' : (h.type === 'robot' ? '#94a3b8' : '#ef4444'), size: 2
            });
          }
        }
      }
    });

    if (bossRef.current && !bossRef.current.isDead) {
      const dx = bossRef.current.x - x;
      const dy = bossRef.current.y - y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < radius + bossRef.current.size) {
        const damage = (1 - dist / (radius + bossRef.current.size)) * power * 5;
        bossRef.current.health -= damage;
        if (bossRef.current.health <= 0) bossRef.current.isDead = true;
      }
    }
  };

  const getBlockColor = (type: number): string => {
    switch (type) {
      case 1: return '#4b5563'; // Concrete
      case 2: return '#9ca3af'; // Metal
      case 3: return '#78350f'; // Wood
      case 4: return '#0ea5e9'; // Ice
      case 5: return '#fef08a'; // Glass
      case 6: return '#1e1b4b'; // Bedrock
      case 7: return '#3b82f6'; // Water
      case 8: return '#f97316'; // Molten Metal
      case 9: return '#334155'; // Lead
      case 10: return '#ec4899'; // Rubber
      case 11: return '#0f172a'; // Obsidian
      case 12: return '#22d3ee'; // Forcefield
      default: return '#000';
    }
  };

  const dropBomb = (x: number, y: number) => {
    const now = Date.now();
    if (now - lastDropTime.current < 50) return;
    lastDropTime.current = now;

    const worldX = x + cameraX;
    const worldY = y + cameraY;

    if (selectedBomb.id === 'bombomb') {
      humansRef.current.push({
        id: Date.now(),
        type: 'bombomb',
        x: worldX,
        y: worldY,
        vx: (Math.random() - 0.5) * 2,
        vy: 0,
        isDead: false,
        health: 100,
        maxHealth: 100,
        color: '#1e293b',
        size: 1,
        phase: 0 // Used for fuse timer
      });
      return;
    }

    if (selectedBomb.id === 'shield') {
      shieldsRef.current.push({
        id: Date.now(),
        x: worldX,
        y: worldY,
        radius: 100,
        health: 500,
        maxHealth: 500,
        color: '#34d399'
      });
      return;
    }

    bombsRef.current.push({
      x: worldX,
      y: worldY,
      vx: (Math.random() - 0.5) * 0.5, // Reduced randomness for accuracy
      vy: selectedBomb.id === 'missile' ? 10 : 0,
      type: selectedBomb,
      sizeFactor: SIZE_FACTORS[sizeMultiplier],
      life: 0,
      maxLife: undefined
    });

    if (followMode) {
      // Smoothly scroll to the drop point if it's far away
      // (Actually, just setting cameraX here would be jarring, 
      // but we can let the animation loop handle it if we add a targetCameraX)
    }
  };

  // --- Animation Loop ---

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;

    const render = () => {
      // 1. Update State
      if (flashRef.current > 0) flashRef.current -= 0.05;

      // Follow Mode Camera Update
      if (followMode && bombsRef.current.length > 0) {
        const latestBomb = bombsRef.current[bombsRef.current.length - 1];
        const targetX = Math.max(0, Math.min(WORLD_WIDTH - VIEWPORT_WIDTH, latestBomb.x - VIEWPORT_WIDTH / 2));
        setCameraX(prev => prev + (targetX - prev) * 0.1);
      }

      // Update Humans/Mobs AI
      humansRef.current = humansRef.current.filter(h => {
        if (h.type === 'bombomb' && h.isDead) return false;
        
        if (!h.isDead) {
          // Gravity, Vacuum, Black Hole, Tornado, Time-Stop effects from active explosions
          explosionsRef.current.forEach(e => {
            const dx = e.x - h.x;
            const dy = e.y - h.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            
            if (dist < e.radius) {
              if (e.type === 'time-stop') {
                h.vx = 0;
                h.vy = 0;
                return;
              }
              if (e.type === 'gravity') {
                h.y -= 8; // Float up
              } else if (e.type === 'vacuum' || e.type === 'black-hole' || e.type === 'moon') {
                const force = e.type === 'black-hole' ? 5 : (e.type === 'moon' ? 8 : 2);
                h.vx += (dx / dist) * force;
                h.y += (dy / dist) * force;
                if ((e.type === 'black-hole' || e.type === 'moon') && dist < 15) h.isDead = true;
              } else if (e.type === 'tornado') {
                const angle = Math.atan2(dy, dx) + 0.2;
                h.vx += Math.cos(angle) * 5;
                h.y += Math.sin(angle) * 5 - 2;
              } else if (e.type === 'pulse') {
                h.vx -= (dx / dist) * 10;
                h.y -= (dy / dist) * 10;
              } else if (e.type === 'solar-flare') {
                if (Math.random() < 0.1) h.isDead = true;
              }
            }
          });

          // Run away from falling bombs
          let fearX = 0;
          bombsRef.current.forEach(b => {
            const dx = h.x - b.x;
            const dy = h.y - b.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < 150) {
              fearX += (dx / dist) * 2;
            }
          });

          h.vx += fearX;
          h.vx *= 0.9; // Friction
          
          // Mob specific behavior
          if (h.type === 'robot' && Math.random() < 0.01) h.vy = -5; // Robots jump
          if (h.type === 'dinosaur' && Math.random() < 0.005) h.vx *= 5; // Dinos charge
          
          if (h.type === 'bombomb') {
            if (h.phase !== undefined) h.phase++;
            
            // Find nearest enemy (non-bombomb mob)
            let nearestEnemy = null;
            let minDist = 300;
            humansRef.current.forEach(other => {
              if (other.id !== h.id && !other.isDead && other.type !== 'bombomb') {
                const dx = other.x - h.x;
                const dy = other.y - h.y;
                const dist = Math.sqrt(dx*dx + dy*dy);
                if (dist < minDist) {
                  minDist = dist;
                  nearestEnemy = other;
                }
              }
            });

            if (nearestEnemy) {
              const dx = nearestEnemy.x - h.x;
              h.vx += Math.sign(dx) * 0.2;
              h.vx = Math.max(-3, Math.min(3, h.vx));
              
              if (minDist < 20) h.health = 0; // Trigger explosion
            }

            if (h.phase !== undefined && h.phase > 300) h.health = 0; // Fuse out
            
            if (h.health <= 0) {
              h.isDead = true;
              createExplosion(h.x, h.y, 80, 20, '#1e293b', 'bombomb');
            }
          }
          
          h.x += h.vx;
          h.y += h.vy;
          
          // Gravity & Collision
          h.vy += 0.2;
          const gx = Math.floor(h.x / PIXEL_SIZE);
          const gy = Math.floor(h.y / PIXEL_SIZE);
          if (gx >= 0 && gx < GRID_COLS && gy >= 0 && gy < GRID_ROWS) {
            if (gridRef.current[gy * GRID_COLS + gx] !== 0) {
              h.y = gy * PIXEL_SIZE;
              h.vy = 0;
            }
          }

          if (h.x < 0) { h.x = 0; h.vx *= -1; }
          if (h.x > WORLD_WIDTH) { h.x = WORLD_WIDTH; h.vx *= -1; }
          
          if (Math.abs(h.vx) < 0.1 && Math.random() < 0.01) {
            h.vx = (Math.random() - 0.5) * 2;
          }
        } else {
          h.y += 4; // Fall faster
          h.x += h.vx;
          h.vx *= 0.98;
          if (h.y > WORLD_HEIGHT) h.y = WORLD_HEIGHT + 10;
        }
        return true;
      });

      // Update Boss
      if (bossRef.current && !bossRef.current.isDead) {
        const b = bossRef.current;
        b.x += Math.sin(Date.now() / 1000) * 3;
        b.y += Math.cos(Date.now() / 1500) * 1;
        
        if (b.health < b.maxHealth * 0.5) b.phase = 2;
        
        if (b.phase === 2 && Math.random() < 0.03) {
          createExplosion(b.x + (Math.random() - 0.5) * 200, b.y + (Math.random() - 0.5) * 200, 30, 20, '#ec4899', 'laser');
        }
      }
      
      // Update Shields
      shieldsRef.current = shieldsRef.current.filter(s => {
        explosionsRef.current.forEach(e => {
          const dx = e.x - s.x;
          const dy = e.y - s.y;
          const dist = Math.sqrt(dx*dx + dy*dy);
          if (dist < e.radius + s.radius) {
            s.health -= e.power * 0.1;
          }
        });
        return s.health > 0;
      });

      // Update Bombs
      bombsRef.current = bombsRef.current.filter(bomb => {
        bomb.vy += bomb.type.id === 'missile' ? 0.5 : 0.25;
        
        // Bom-omb chasing logic
        if (bomb.type.id === 'bombomb' && bomb.life !== undefined) {
          bomb.life++;
          
          // Find nearest human
          let nearestHuman = null;
          let minDist = 300;
          humansRef.current.forEach(h => {
            if (!h.isDead) {
              const dx = h.x - bomb.x;
              const dy = h.y - bomb.y;
              const dist = Math.sqrt(dx*dx + dy*dy);
              if (dist < minDist) {
                minDist = dist;
                nearestHuman = h;
              }
            }
          });

          if (nearestHuman) {
            const h = nearestHuman as Human;
            const dx = h.x - bomb.x;
            bomb.vx += Math.sign(dx) * 0.1;
            bomb.vx = Math.max(-2, Math.min(2, bomb.vx));
            
            // Explode if close
            if (minDist < 20) {
              createExplosion(
                bomb.x, bomb.y, 
                bomb.type.explosionRadius * bomb.sizeFactor, 
                bomb.type.power * bomb.sizeFactor, 
                bomb.type.color,
                bomb.type.specialEffect
              );
              return false;
            }
          }

          // Explode if fuse runs out
          if (bomb.maxLife && bomb.life >= bomb.maxLife) {
            createExplosion(
              bomb.x, bomb.y, 
              bomb.type.explosionRadius * bomb.sizeFactor, 
              bomb.type.power * bomb.sizeFactor, 
              bomb.type.color,
              bomb.type.specialEffect
            );
            return false;
          }
        }

        // Cluster bomb split logic
        if (bomb.type.id === 'cluster' && bomb.vy > 5 && Math.random() < 0.05) {
          for (let i = 0; i < 3; i++) {
            bombsRef.current.push({
              x: bomb.x, y: bomb.y, vx: (Math.random() - 0.5) * 4, vy: bomb.vy,
              type: BOMB_TYPES.find(b => b.id === 'dynamite')!, sizeFactor: 0.5
            });
          }
          return false;
        }

        // Horizontal Movement & Collision
        const nextX = bomb.x + bomb.vx;
        const gx = Math.floor(nextX / PIXEL_SIZE);
        const gy = Math.floor(bomb.y / PIXEL_SIZE);
        
        let collidedX = false;
        if (gx >= 0 && gx < GRID_COLS && gy >= 0 && gy < GRID_ROWS) {
          if (gridRef.current[gy * GRID_COLS + gx] !== 0) {
            collidedX = true;
          }
        }

        if (collidedX) {
          if (bomb.type.id === 'iron-ball') {
            bomb.vx *= -0.6; // Bounce with energy loss
            // Small impact effect
            createExplosion(bomb.x, bomb.y, 10, 2, bomb.type.color, 'iron');
          } else {
            // Normal bombs explode on contact
            createExplosion(
              bomb.x, 
              bomb.y, 
              bomb.type.explosionRadius * bomb.sizeFactor, 
              bomb.type.power * bomb.sizeFactor, 
              bomb.type.color,
              bomb.type.specialEffect
            );
            return false;
          }
        } else {
          bomb.x = nextX;
        }

        // Vertical Movement & Collision
        const nextY = bomb.y + bomb.vy;
        const vgx = Math.floor(bomb.x / PIXEL_SIZE);
        const vgy = Math.floor(nextY / PIXEL_SIZE);

        let collidedY = false;
        if (vgx >= 0 && vgx < GRID_COLS && vgy >= 0 && vgy < GRID_ROWS) {
          if (gridRef.current[vgy * GRID_COLS + vgx] !== 0) {
            collidedY = true;
          }
        }

        if (collidedY) {
          if (bomb.type.id === 'iron-ball') {
            bomb.vy *= -0.5; // Bounce with energy loss
            bomb.vx *= 0.9;  // Friction on ground
            // Small impact effect
            createExplosion(bomb.x, bomb.y, 10, 2, bomb.type.color, 'iron');
            
            // If it's barely moving, just let it sit or remove it if it's too slow
            if (Math.abs(bomb.vy) < 0.5 && Math.abs(bomb.vx) < 0.2) {
              return false; 
            }
          } else {
            createExplosion(
              bomb.x, 
              bomb.y, 
              bomb.type.explosionRadius * bomb.sizeFactor, 
              bomb.type.power * bomb.sizeFactor, 
              bomb.type.color,
              bomb.type.specialEffect
            );
            return false;
          }
        } else {
          bomb.y = nextY;
        }

        // Out of bounds
        if (bomb.y > WORLD_HEIGHT || bomb.x < 0 || bomb.x > WORLD_WIDTH) return false;
        return true;
      });

      // Update Explosions
      explosionsRef.current = explosionsRef.current.filter(exp => {
        exp.life++;
        
        if (exp.type === 'black-hole') {
          let ateSomething = false;
          
          // Sucking mobs
          humansRef.current.forEach(h => {
            if (!h.isDead) {
              const dx = exp.x - h.x;
              const dy = exp.y - h.y;
              const dist = Math.sqrt(dx*dx + dy*dy);
              if (dist < exp.radius) {
                const force = 5 + (exp.radius / 100);
                h.vx += (dx / dist) * force;
                h.vy += (dy / dist) * force;
                if (dist < exp.radius * 0.1 + 5) {
                  h.isDead = true;
                  exp.radius += 2;
                  ateSomething = true;
                }
              }
            }
          });

          // Sucking blocks
          const gx = Math.floor(exp.x / PIXEL_SIZE);
          const gy = Math.floor(exp.y / PIXEL_SIZE);
          const gr = Math.ceil(exp.radius / PIXEL_SIZE);
          for (let dx = -gr; dx <= gr; dx++) {
            for (let dy = -gr; dy <= gr; dy++) {
              const nx = gx + dx;
              const ny = gy + dy;
              if (nx >= 0 && nx < GRID_COLS && ny >= 0 && ny < GRID_ROWS) {
                const distSq = dx * dx + dy * dy;
                if (distSq <= gr * gr) {
                  const idx = ny * GRID_COLS + nx;
                  if (gridRef.current[idx] !== 0 && gridRef.current[idx] !== 6) {
                    if (Math.random() < 0.1) {
                      gridRef.current[idx] = 0;
                      exp.radius += 0.05;
                      ateSomething = true;
                    }
                  }
                }
              }
            }
          }

          if (ateSomething) exp.life = 0; // Keep it alive while eating
        }

        if (exp.type === 'ice') {
          const gx = Math.floor(exp.x / PIXEL_SIZE);
          const gy = Math.floor(exp.y / PIXEL_SIZE);
          const gr = Math.ceil(exp.radius / PIXEL_SIZE);
          for (let dx = -gr; dx <= gr; dx++) {
            for (let dy = -gr; dy <= gr; dy++) {
              if (dx * dx + dy * dy <= gr * gr) {
                const nx = gx + dx;
                const ny = gy + dy;
                if (nx >= 0 && nx < GRID_COLS && ny >= 0 && ny < GRID_ROWS) {
                  const idx = ny * GRID_COLS + nx;
                  if (gridRef.current[idx] !== 0 && gridRef.current[idx] !== 6) {
                    gridRef.current[idx] = 4; // Ice color
                  }
                }
              }
            }
          }
        }
        return exp.life < exp.maxLife;
      });

      // Update Particles
      particlesRef.current = particlesRef.current.filter(p => {
        // Vacuum, Gravity, Black Hole, Tornado effects on particles
        explosionsRef.current.forEach(e => {
          const dx = e.x - p.x;
          const dy = e.y - p.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          
          if (dist < e.radius) {
            if (e.type === 'time-stop') {
              p.vx = 0; p.vy = 0;
              return;
            }
            if (e.type === 'vacuum' || e.type === 'black-hole') {
              const force = e.type === 'black-hole' ? 1.0 : 0.5;
              p.vx += (dx / dist) * force;
              p.vy += (dy / dist) * force;
            } else if (e.type === 'gravity') {
              p.vy -= 0.2; // Float up
            } else if (e.type === 'tornado') {
              const angle = Math.atan2(dy, dx) + 0.2;
              p.vx += Math.cos(angle) * 2;
              p.vy += Math.sin(angle) * 2 - 0.5;
            } else if (e.type === 'pulse') {
              p.vx -= (dx / dist) * 2;
              p.vy -= (dy / dist) * 2;
            }
          }
        });

        if (p.type === 'gas') {
          p.vx += (Math.random() - 0.5) * 0.1;
          p.vy += (Math.random() - 0.5) * 0.1 - 0.01; // Drift up slightly
        } else if (p.type === 'fire' || p.type === 'acid' || p.type === 'nano') {
          p.vx += (Math.random() - 0.5) * 0.1;
          p.vy += p.type === 'fire' ? 0.05 : 0.1;
          
          // These particles can destroy blocks
          const gx = Math.floor(p.x / PIXEL_SIZE);
          const gy = Math.floor(p.y / PIXEL_SIZE);
          if (gx >= 0 && gx < GRID_COLS && gy >= 0 && gy < GRID_ROWS) {
            const idx = gy * GRID_COLS + gx;
            const chance = p.type === 'fire' ? 0.05 : (p.type === 'acid' ? 0.2 : 0.5);
            if (gridRef.current[idx] !== 0 && gridRef.current[idx] !== 6 && Math.random() < chance) {
              gridRef.current[idx] = 0;
            }
            if (gridRef.current[idx] !== 0) {
              p.vy = 0;
              p.vx *= 0.5;
            }
          }
        } else {
          p.vy += 0.05;
        }

        p.x += p.vx;
        p.y += p.vy;
        p.life++;

        // Kill humans touching gas or fire
        if (p.type === 'gas' || p.type === 'fire') {
          humansRef.current.forEach(h => {
            if (!h.isDead) {
              const dx = h.x - p.x;
              const dy = h.y - p.y;
              if (Math.abs(dx) < 5 && Math.abs(dy) < 5) {
                if (Math.random() < 0.1) h.isDead = true;
              }
            }
          });
        }

        return p.life < p.maxLife;
      });

      // 2. Draw
      ctx.fillStyle = currentMap === 'sun' ? '#450a0a' : (currentMap === 'moon' ? '#020617' : '#0f172a');
      ctx.fillRect(0, 0, VIEWPORT_WIDTH, VIEWPORT_HEIGHT);

      // Starfield for space maps
      if (currentMap === 'moon' || currentMap === 'mars' || currentMap === 'sun') {
        ctx.fillStyle = 'white';
        for (let i = 0; i < 50; i++) {
          const sx = (Math.sin(i * 123.45) * 0.5 + 0.5) * VIEWPORT_WIDTH;
          const sy = (Math.cos(i * 678.90) * 0.5 + 0.5) * VIEWPORT_HEIGHT;
          const size = (Math.sin(Date.now() / 500 + i) * 0.5 + 0.5) * 2;
          ctx.fillRect(sx, sy, size, size);
        }
      }

      // Follow mode
      if (followMode && bombsRef.current.length > 0) {
        const lastBomb = bombsRef.current[bombsRef.current.length - 1];
        const targetX = lastBomb.x - (VIEWPORT_WIDTH / zoomRef.current) / 2;
        const targetY = lastBomb.y - (VIEWPORT_HEIGHT / zoomRef.current) / 2;
        
        cameraXRef.current += (targetX - cameraXRef.current) * 0.1;
        cameraYRef.current += (targetY - cameraYRef.current) * 0.1;
        
        // Sync back to state for UI display (throttled by requestAnimationFrame naturally)
        setCameraX(cameraXRef.current);
        setCameraY(cameraYRef.current);
      }

      // Draw Grid
      ctx.save();
      // Apply Zoom
      ctx.translate(VIEWPORT_WIDTH / 2, VIEWPORT_HEIGHT / 2);
      ctx.scale(zoomRef.current, zoomRef.current);
      ctx.translate(-VIEWPORT_WIDTH / 2, -VIEWPORT_HEIGHT / 2);
      
      ctx.translate(-cameraXRef.current, -cameraYRef.current);

      // Draw Shields
      shieldsRef.current.forEach(s => {
        ctx.fillStyle = s.color + '44';
        ctx.strokeStyle = s.color;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        
        // Health bar
        const healthPct = s.health / s.maxHealth;
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(s.x - 20, s.y - s.radius - 10, 40, 4);
        ctx.fillStyle = s.color;
        ctx.fillRect(s.x - 20, s.y - s.radius - 10, 40 * healthPct, 4);
      });

      const grid = gridRef.current;
      const startCol = Math.floor(cameraXRef.current / PIXEL_SIZE);
      const endCol = startCol + Math.floor(VIEWPORT_WIDTH / PIXEL_SIZE) + 1;
      const startRow = Math.floor(cameraYRef.current / PIXEL_SIZE);
      const endRow = startRow + Math.floor(VIEWPORT_HEIGHT / PIXEL_SIZE) + 1;

      for (let y = startRow; y < endRow; y++) {
        if (y < 0 || y >= GRID_ROWS) continue;
        for (let x = startCol; x < endCol; x++) {
          if (x < 0 || x >= GRID_COLS) continue;
          const idx = y * GRID_COLS + x;
          if (grid[idx] !== 0) {
            ctx.fillStyle = getBlockColor(grid[idx]);
            ctx.fillRect(x * PIXEL_SIZE, y * PIXEL_SIZE, PIXEL_SIZE, PIXEL_SIZE);
          }
        }
      }

      // Draw Mobs
      humansRef.current.forEach(h => {
        if (h.x + 10 < cameraXRef.current || h.x - 10 > cameraXRef.current + VIEWPORT_WIDTH || h.y + 10 < cameraYRef.current || h.y - 10 > cameraYRef.current + VIEWPORT_HEIGHT) return;
        
        ctx.fillStyle = h.isDead ? '#450a0a' : h.color;
        
        if (h.type === 'dinosaur') {
          // Simple dino shape
          const s = h.size || 1;
          ctx.fillRect(h.x - 4 * s, h.y - 8 * s, 8 * s, 8 * s); // Body
          ctx.fillRect(h.x + 2 * s, h.y - 12 * s, 4 * s, 4 * s); // Head
          ctx.fillRect(h.x - 6 * s, h.y - 4 * s, 2 * s, 4 * s); // Tail
        } else if (h.type === 'alien') {
          // Alien shape
          ctx.beginPath();
          ctx.ellipse(h.x, h.y - 4, 4, 6, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = 'black';
          ctx.fillRect(h.x - 2, h.y - 6, 1, 2);
          ctx.fillRect(h.x + 1, h.y - 6, 1, 2);
        } else if (h.type === 'robot') {
          // Robot shape
          ctx.fillRect(h.x - 3, h.y - 8, 6, 8);
          ctx.fillStyle = '#38bdf8';
          ctx.fillRect(h.x - 1, h.y - 6, 2, 2);
        } else if (h.type === 'bombomb') {
          // Draw Bom-omb entity
          ctx.fillStyle = '#1e293b';
          ctx.beginPath();
          ctx.arc(h.x, h.y - 4, 6, 0, Math.PI * 2);
          ctx.fill();
          // Eyes
          ctx.fillStyle = 'white';
          ctx.fillRect(h.x - 2, h.y - 6, 1, 2);
          ctx.fillRect(h.x + 1, h.y - 6, 1, 2);
          // Key
          ctx.fillStyle = '#fbbf24';
          ctx.fillRect(h.x - 8, h.y - 6, 2, 4);
          // Fuse
          ctx.strokeStyle = '#fde047';
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(h.x, h.y - 10);
          ctx.lineTo(h.x + Math.sin(Date.now() / 50) * 3, h.y - 14);
          ctx.stroke();
        } else {
          // Human
          ctx.fillRect(h.x - 2, h.y - 8, 4, 8); // Body
          ctx.fillStyle = h.isDead ? '#7f1d1d' : '#fecaca';
          ctx.fillRect(h.x - 2, h.y - 10, 4, 3); // Head
        }
      });

      // Draw Boss Axolotl
      if (bossRef.current) {
        const b = bossRef.current;
        if (!b.isDead) {
          ctx.fillStyle = b.color;
          // Large axolotl body
          ctx.fillRect(b.x - b.size, b.y - b.size / 2, b.size * 2, b.size);
          // Head
          ctx.fillRect(b.x + b.size * 0.8, b.y - b.size * 0.8, b.size * 0.6, b.size * 0.6);
          // Gills
          ctx.fillStyle = '#ec4899';
          ctx.fillRect(b.x + b.size * 0.7, b.y - b.size, 4, 10);
          ctx.fillRect(b.x + b.size * 0.9, b.y - b.size, 4, 10);
          // Tail
          ctx.fillStyle = b.color;
          ctx.beginPath();
          ctx.moveTo(b.x - b.size, b.y);
          ctx.lineTo(b.x - b.size * 2, b.y);
          ctx.lineTo(b.x - b.size, b.y + b.size / 2);
          ctx.fill();
        } else {
          ctx.fillStyle = '#450a0a';
          ctx.fillRect(b.x - b.size, b.y - b.size / 2, b.size * 2, b.size);
        }
      }

      // Draw Particles
      particlesRef.current.forEach(p => {
        if (p.x < cameraXRef.current || p.x > cameraXRef.current + VIEWPORT_WIDTH || p.y < cameraYRef.current || p.y > cameraYRef.current + VIEWPORT_HEIGHT) return;
        const alpha = 1 - (p.life / p.maxLife);
        ctx.globalAlpha = alpha;
        ctx.fillStyle = p.color;
        
        // Glow for certain particles
        if (p.type === 'fire' || p.type === 'antimatter') {
          ctx.shadowBlur = 5;
          ctx.shadowColor = p.color;
        }
        
        ctx.fillRect(p.x, p.y, p.size, p.size);
        ctx.shadowBlur = 0;
      });
      ctx.globalAlpha = 1.0;

      // Draw Bombs
      bombsRef.current.forEach(bomb => {
        if (bomb.x < cameraXRef.current || bomb.x > cameraXRef.current + VIEWPORT_WIDTH || bomb.y < cameraYRef.current || bomb.y > cameraYRef.current + VIEWPORT_HEIGHT) return;
        ctx.fillStyle = bomb.type.color;
        
        if (bomb.type.id === 'bombomb') {
          // Draw Bom-omb
          ctx.beginPath();
          ctx.arc(bomb.x, bomb.y, bomb.type.physicalRadius, 0, Math.PI * 2);
          ctx.fill();
          // Eyes
          ctx.fillStyle = 'white';
          ctx.fillRect(bomb.x - 3, bomb.y - 3, 2, 4);
          ctx.fillRect(bomb.x + 1, bomb.y - 3, 2, 4);
          // Key on back
          ctx.fillStyle = '#fbbf24';
          ctx.fillRect(bomb.x - 10, bomb.y - 2, 4, 4);
          // Fuse
          ctx.strokeStyle = '#fde047';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(bomb.x, bomb.y - 8);
          ctx.lineTo(bomb.x + Math.sin(Date.now() / 100) * 5, bomb.y - 15);
          ctx.stroke();
        } else {
          ctx.beginPath();
          ctx.arc(bomb.x, bomb.y, bomb.type.physicalRadius, 0, Math.PI * 2);
          ctx.fill();
        }
        
        // Bomb trail
        if (Math.random() < 0.3) {
          particlesRef.current.push({
            x: bomb.x, y: bomb.y, vx: (Math.random() - 0.5), vy: (Math.random() - 0.5),
            life: 0, maxLife: 10, color: bomb.type.color, size: 2
          });
        }
      });

      // Draw Explosions
      explosionsRef.current.forEach(exp => {
        const progress = exp.life / exp.maxLife;
        let currentRadius;
        
        if (exp.type === 'antimatter' || exp.type === 'black-hole') {
          currentRadius = exp.radius * (exp.type === 'black-hole' ? 1 : (1 - progress));
          ctx.fillStyle = '#000000';
          ctx.shadowBlur = 20;
          ctx.shadowColor = exp.type === 'black-hole' ? '#000000' : '#a855f7';
          if (exp.type === 'black-hole') {
            ctx.strokeStyle = '#a855f7';
            ctx.lineWidth = 2;
            ctx.stroke();
          }
        } else if (exp.type === 'laser' || exp.type === 'laser-rain') {
          currentRadius = exp.radius * (1 - progress);
          ctx.fillStyle = exp.color;
          ctx.shadowBlur = 15;
          ctx.shadowColor = exp.color;
          
          // Draw beam
          ctx.fillRect(exp.x - 2, 0, 4, WORLD_HEIGHT);
        } else if (exp.type === 'sun') {
          // Expanding fireball
          currentRadius = exp.radius * progress;
          const gradient = ctx.createRadialGradient(exp.x, exp.y, 0, exp.x, exp.y, currentRadius);
          gradient.addColorStop(0, '#fde047');
          gradient.addColorStop(0.3, '#f97316');
          gradient.addColorStop(0.6, '#ef4444');
          gradient.addColorStop(1, 'transparent');
          ctx.fillStyle = gradient;
          ctx.shadowBlur = 30;
          ctx.shadowColor = '#f97316';
        } else {
          currentRadius = exp.radius * Math.sin(progress * Math.PI);
          const gradient = ctx.createRadialGradient(exp.x, exp.y, 0, exp.x, exp.y, currentRadius);
          gradient.addColorStop(0, exp.color);
          gradient.addColorStop(0.5, exp.color + '88');
          gradient.addColorStop(1, 'transparent');
          ctx.fillStyle = gradient;
        }
        
        ctx.beginPath();
        ctx.arc(exp.x, exp.y, currentRadius, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      });

      ctx.restore();

      // Flash effect
      if (flashRef.current > 0 && flashEnabled) {
        ctx.fillStyle = 'white';
        ctx.globalAlpha = Math.min(1, flashRef.current);
        ctx.fillRect(0, 0, VIEWPORT_WIDTH, VIEWPORT_HEIGHT);
        ctx.globalAlpha = 1.0;
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animationFrameId);
  }, [followMode, flashEnabled, currentMap]); // Removed cameraX to prevent infinite loop

  // --- Handlers ---

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    const rect = canvasRef.current?.getBoundingClientRect();
    if (rect) {
      const x = (e.clientX - rect.left) * (VIEWPORT_WIDTH / rect.width);
      const y = (e.clientY - rect.top) * (VIEWPORT_HEIGHT / rect.height);
      dropBomb(x, y);
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      const rect = canvasRef.current?.getBoundingClientRect();
      if (rect) {
        const x = (e.clientX - rect.left) * (VIEWPORT_WIDTH / rect.width);
        const y = (e.clientY - rect.top) * (VIEWPORT_HEIGHT / rect.height);
        dropBomb(x, y);
      }
    }
  };

  const handleMouseUp = () => setIsDragging(false);

  const getBgColor = () => {
    switch (currentMap) {
      case 'city': return 'bg-slate-950';
      case 'bunker': return 'bg-zinc-900';
      case 'forest': return 'bg-emerald-950';
      case 'cavern': return 'bg-stone-950';
      case 'sun': return 'bg-orange-950';
      case 'moon': return 'bg-gray-950';
      case 'mars': return 'bg-red-950';
      case 'ocean': return 'bg-cyan-950';
      default: return 'bg-slate-950';
    }
  };

  return (
    <div className={`min-h-screen ${getBgColor()} text-slate-100 font-sans p-4 md:p-8 flex flex-col items-center gap-6 transition-colors duration-500`}>
      <header className="text-center space-y-2">
        <h1 className="text-4xl font-black tracking-tighter bg-gradient-to-r from-red-500 via-orange-500 to-yellow-500 bg-clip-text text-transparent uppercase italic">
          Pixel Bomb Sandbox Pro
        </h1>
        <div className="flex items-center justify-center gap-4 text-slate-400 text-sm font-medium">
          <span>Expanded World</span>
          <span className="w-1 h-1 bg-slate-700 rounded-full"></span>
          <span>New Arsenal</span>
          <span className="w-1 h-1 bg-slate-700 rounded-full"></span>
          <span>Human Subjects</span>
        </div>
      </header>

      {/* Map Selection */}
      <div className="w-full max-w-4xl flex gap-2 overflow-x-auto pb-2 custom-scrollbar">
        {(['city', 'bunker', 'forest', 'cavern', 'sun', 'moon', 'mars', 'ocean'] as MapType[]).map((map) => (
          <button
            key={map}
            onClick={() => setCurrentMap(map)}
            className={`px-4 py-2 rounded-lg border text-[10px] font-bold uppercase transition-all whitespace-nowrap ${
              currentMap === map
                ? 'bg-orange-500 border-orange-400 text-white shadow-[0_0_15px_rgba(249,115,22,0.3)]'
                : 'bg-slate-900 border-slate-800 text-slate-500 hover:bg-slate-800'
            }`}
          >
            {map}
          </button>
        ))}
      </div>

      <div className="relative group w-full max-w-4xl">
        <div className="absolute -inset-1 bg-gradient-to-r from-red-600 to-orange-600 rounded-xl blur opacity-25 group-hover:opacity-50 transition duration-1000"></div>
        <div className="relative bg-slate-900 rounded-lg overflow-hidden border border-slate-800 shadow-2xl">
          <canvas
            ref={canvasRef}
            width={VIEWPORT_WIDTH}
            height={VIEWPORT_HEIGHT}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            className="cursor-crosshair w-full aspect-video touch-none"
            style={{ imageRendering: 'pixelated' }}
          />
          
          <div className="absolute top-4 left-4 flex flex-col gap-2">
            <button 
              onClick={() => setZoom(prev => Math.min(4, prev + 0.2))}
              className="p-2 bg-slate-900/80 backdrop-blur rounded-lg border border-slate-700 text-slate-300 hover:bg-slate-800"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button 
              onClick={() => setZoom(prev => Math.max(0.1, prev - 0.1))}
              className="p-2 bg-slate-900/80 backdrop-blur rounded-lg border border-slate-700 text-slate-300 hover:bg-slate-800"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <div className="bg-slate-900/80 backdrop-blur rounded-lg border border-slate-700 text-slate-300 px-2 py-1 text-[10px] font-mono text-center whitespace-nowrap">
              {Math.round(1 / zoom * 10) / 10} Cities
            </div>
            <button 
              onClick={() => setFlashEnabled(!flashEnabled)}
              className={`p-2 backdrop-blur rounded-lg border text-[8px] font-bold uppercase transition-all ${
                flashEnabled ? 'bg-yellow-500/20 border-yellow-500 text-yellow-500' : 'bg-slate-900/80 border-slate-700 text-slate-500'
              }`}
              title="Toggle Flash Effects"
            >
              {flashEnabled ? 'Flash ON' : 'Flash OFF'}
            </button>
          </div>

          {bossRef.current && !bossRef.current.isDead && (
            <div className="absolute top-4 left-1/2 -translate-x-1/2 w-1/2 bg-slate-950/80 backdrop-blur p-1 rounded-full border border-slate-800">
              <div className="flex justify-between px-2 mb-1">
                <span className="text-[8px] font-bold text-pink-400 uppercase">Giant Axolotl</span>
                <span className="text-[8px] font-bold text-slate-400">{Math.ceil(bossRef.current.health)} / {bossRef.current.maxHealth}</span>
              </div>
              <div className="h-2 bg-slate-900 rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-gradient-to-r from-pink-600 to-pink-400"
                  initial={{ width: '100%' }}
                  animate={{ width: `${(bossRef.current.health / bossRef.current.maxHealth) * 100}%` }}
                />
              </div>
            </div>
          )}
          
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-3/4 bg-slate-950/80 backdrop-blur p-2 rounded-full border border-slate-800 flex items-center gap-4">
            <button 
              onClick={() => setFollowMode(!followMode)}
              className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase transition-all ${
                followMode ? 'bg-orange-500 text-white' : 'bg-slate-800 text-slate-400'
              }`}
            >
              Follow: {followMode ? 'ON' : 'OFF'}
            </button>
            <div className="flex flex-col flex-1 gap-1">
              <input 
                type="range" 
                min="0" 
                max={WORLD_WIDTH - VIEWPORT_WIDTH} 
                value={cameraX} 
                onChange={(e) => {
                  setCameraX(parseInt(e.target.value));
                  setFollowMode(false);
                }}
                className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-orange-500"
              />
              <input 
                type="range" 
                min="0" 
                max={WORLD_HEIGHT - VIEWPORT_HEIGHT} 
                value={cameraY} 
                onChange={(e) => {
                  setCameraY(parseInt(e.target.value));
                  setFollowMode(false);
                }}
                className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
              />
            </div>
            <div className="flex flex-col items-center text-[8px] font-bold text-slate-500 uppercase">
              <span>Arrows to move</span>
              <span>X: {Math.floor(cameraX)} Y: {Math.floor(cameraY)}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="w-full max-w-4xl grid grid-cols-1 md:grid-cols-4 gap-4">
        
        {/* Arsenal - Scrollable */}
        <div className="md:col-span-2 bg-slate-900/50 p-4 rounded-xl border border-slate-800 space-y-4">
          <div className="flex items-center gap-2 text-slate-400 text-xs font-bold uppercase tracking-wider">
            <BombIcon className="w-4 h-4" />
            Arsenal ({BOMB_TYPES.length})
          </div>
          <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-[240px] overflow-y-auto pr-2 custom-scrollbar">
            {BOMB_TYPES.map((bomb) => (
              <button
                key={bomb.id}
                onClick={() => setSelectedBomb(bomb)}
                className={`flex flex-col items-center gap-1 p-2 rounded-lg border transition-all ${
                  selectedBomb.id === bomb.id
                    ? 'bg-slate-800 border-orange-500 text-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.2)]'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800 hover:border-slate-700'
                }`}
              >
                {bomb.icon}
                <span className="text-[8px] font-bold uppercase text-center truncate w-full">{bomb.name}</span>
              </button>
            ))}
          </div>
          <div className="p-2 bg-slate-950/50 rounded-lg border border-slate-800/50">
            <p className="text-[10px] text-slate-500 leading-tight italic">
              {selectedBomb.description}
            </p>
          </div>
        </div>

        {/* Size & Settings */}
        <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800 space-y-4">
          <div className="flex items-center gap-2 text-slate-400 text-xs font-bold uppercase tracking-wider">
            <Settings2 className="w-4 h-4" />
            Payload
          </div>
          <div className="flex flex-col gap-2">
            {(['small', 'medium', 'large'] as SizeMultiplier[]).map((size) => (
              <button
                key={size}
                onClick={() => setSizeMultiplier(size)}
                className={`flex items-center justify-between px-3 py-2 rounded-lg border transition-all capitalize font-bold text-xs ${
                  sizeMultiplier === size
                    ? 'bg-slate-800 border-blue-500 text-blue-400'
                    : 'bg-slate-900 border-slate-800 text-slate-500 hover:bg-slate-800'
                }`}
              >
                {size}
                {size === 'small' && <Minimize2 className="w-3 h-3" />}
                {size === 'medium' && <Maximize2 className="w-3 h-3 rotate-45" />}
                {size === 'large' && <Maximize2 className="w-3 h-3" />}
              </button>
            ))}
          </div>
          <button
            onClick={() => {
              const newHumans: Human[] = [];
              const types: MobType[] = ['human', 'dinosaur', 'alien', 'robot'];
              for (let i = 0; i < 50; i++) {
                const type = types[Math.floor(Math.random() * types.length)];
                newHumans.push({
                  id: Date.now() + i,
                  type: type,
                  x: cameraX + Math.random() * VIEWPORT_WIDTH,
                  y: (GRID_ROWS - 6) * PIXEL_SIZE,
                  vx: (Math.random() - 0.5) * 1,
                  vy: 0,
                  isDead: false,
                  health: type === 'dinosaur' ? 200 : (type === 'robot' ? 150 : 100),
                  maxHealth: type === 'dinosaur' ? 200 : (type === 'robot' ? 150 : 100),
                  color: type === 'alien' ? '#a855f7' : (type === 'robot' ? '#94a3b8' : (type === 'dinosaur' ? '#166534' : `hsl(${Math.random() * 360}, 70%, 60%)`)),
                  size: type === 'dinosaur' ? 1.5 : 1
                });
              }
              humansRef.current = [...humansRef.current, ...newHumans];
            }}
            className="w-full flex items-center justify-center gap-2 bg-emerald-950/30 hover:bg-emerald-900/40 text-emerald-400 font-bold py-2 rounded-lg border border-emerald-900/50 transition-all text-xs"
          >
            <User className="w-4 h-4" />
            Spawn Mobs
          </button>
        </div>

        {/* Actions */}
        <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800 flex flex-col gap-2">
          <div className="flex items-center gap-2 text-slate-400 text-xs font-bold uppercase tracking-wider">
            <RefreshCw className="w-4 h-4" />
            World
          </div>
          <button
            onClick={initCity}
            className="flex-1 flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold py-2 rounded-lg border border-slate-700 transition-all text-xs"
          >
            <RefreshCw className="w-4 h-4" />
            Reset
          </button>
          <button
            onClick={() => {
              gridRef.current.fill(0);
              particlesRef.current = [];
              bombsRef.current = [];
              explosionsRef.current = [];
              humansRef.current = [];
            }}
            className="flex-1 flex items-center justify-center gap-2 bg-red-950/30 hover:bg-red-900/40 text-red-400 font-bold py-2 rounded-lg border border-red-900/50 transition-all text-xs"
          >
            <Trash2 className="w-4 h-4" />
            Clear
          </button>
          <div className="mt-2 text-center">
            <span className="text-[10px] text-slate-600 font-bold uppercase">
              {humansRef.current.filter(h => !h.isDead).length} Survivors
            </span>
          </div>
        </div>

      </div>

      <footer className="text-slate-500 text-[10px] font-medium uppercase tracking-[0.2em] mt-auto pb-4">
        Scroll the world to find more targets • Drag to drop multiple payloads
      </footer>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: #0f172a;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #334155;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #475569;
        }
      `}</style>
    </div>
  );
}
